import express from "express";
import path from "path";
import dns from "dns";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import { GoogleGenAI, Type } from "@google/genai";

// Fix for potentially slow DNS lookup in some sandboxed environments
try {
  dns.setDefaultResultOrder("ipv4first");
} catch (e) {
  // Ignore DNS ordering errors
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Request body parsers
  app.use(express.json({ limit: "25mb" }));
  app.use(express.urlencoded({ limit: "25mb", extended: true }));

  // ARES Local Fallback dictionary for testing in non-CZ, non-EU sandboxes/containers (like europe-west2)
  const KNOWN_COMPANIES: Record<string, { companyName: string; dic: string; street: string; city: string; zip: string }> = {
    "27074358": {
      companyName: "Alza.cz a.s.",
      dic: "CZ27074358",
      street: "Jankovcova 1522/53",
      city: "Praha 7",
      zip: "17000"
    },
    "26168685": {
      companyName: "Seznam.cz, a.s.",
      dic: "CZ26168685",
      street: "Radlická 3294/10",
      city: "Praha 5",
      zip: "15000"
    },
    "00001350": {
      companyName: "ŠKODA AUTO a.s.",
      dic: "CZ00001350",
      street: "tř. Václava Klementa 869",
      city: "Mladá Boleslav",
      zip: "29301"
    },
    "42864238": {
      companyName: "Kofola a.s.",
      dic: "CZ42864238",
      street: "Za Drahou 165/1",
      city: "Krnov - Podlesí",
      zip: "79401"
    }
  };

  // Deterministic local generator for custom test IČOs when offline/unregistered/blocked and Gemini unavailable
  function generateDeterministicCompany(ico: string) {
    const baseValue = Array.from(ico).reduce((sum, char) => sum + parseInt(char, 10), 0);
    const companySuffixes = ["s.r.o.", "a.s.", "poskytovatel služeb s.r.o.", "stavební s.r.o.", "tech s.r.o."];
    const streetNames = ["Václavské náměstí", "Národní", "Vodičkova", "Křížová", "Plzeňská", "Brněnská", "Nádražní", "Husova", "Sportovní", "Smetanova"];
    const cities = ["Praha", "Brno", "Ostrava", "Plzeň", "Liberec", "Olomouc", "Ústí nad Labem", "Hradec Králové", "České Budějovice", "Pardubice"];
    const zipCodes = ["11000", "60200", "70200", "30100", "46001", "77900", "40001", "50002", "37001", "53002"];
    
    const suffix = companySuffixes[baseValue % companySuffixes.length];
    const street = streetNames[baseValue % streetNames.length];
    const streetNum = (baseValue * 7) % 250 + 1;
    const orientationalNum = (baseValue * 3) % 19 + 1;
    const city = cities[baseValue % cities.length];
    const zip = zipCodes[baseValue % zipCodes.length];
    
    // Construct readable company name
    const czechFirstNames = ["Alfa", "Beta", "Lignum", "Praga", "Bohemia", "Intellect", "Apex", "Moravia", "Silesia", "Zet"];
    const czechSecondNames = ["Trading", "Group", "Partner", "Systems", "Design", "Logistics", "Commerce", "Služby", "Stavby", "Práce"];
    const name1 = czechFirstNames[(parseInt(ico.substring(0, 3)) || 0) % czechFirstNames.length];
    const name2 = czechSecondNames[(parseInt(ico.substring(3, 6)) || 0) % czechSecondNames.length];
    
    return {
      ico,
      dic: `CZ${ico}`,
      companyName: `${name1} ${name2} ${suffix}`,
      street: `${street} ${streetNum}/${orientationalNum}`,
      city,
      zip,
      note: "Simulovaná data (ARES API nedostupné nebo geoblokované)"
    };
  }

  // Gemini generative fallback
  async function getGeminiCompany(ico: string): Promise<any> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error("GEMINI_API_KEY is missing");
    }
    
    const ai = new GoogleGenAI({
      apiKey: apiKey,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });

    const prompt = `Generate a realistic Czech company billing profile for a company with IČO: "${ico}". Ensure details align visually and structurally with standard Czech registry records.`;

    const response = await ai.models.generateContent({
      model: "gemini-3.5-flash",
      contents: prompt,
      config: {
        systemInstruction: "You are the Czech ARES Business Registry simulator. Output details ONLY in valid, single-level compact JSON with no nested fields.",
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            companyName: { type: Type.STRING, description: "Official name of the company" },
            dic: { type: Type.STRING, description: "Czech DIČ, starting with CZ" },
            street: { type: Type.STRING, description: "Street and house number" },
            city: { type: Type.STRING, description: "City or town name" },
            zip: { type: Type.STRING, description: "5-digit postal code" }
          },
          required: ["companyName", "dic", "street", "city", "zip"]
        }
      }
    });

    if (!response.text) {
      throw new Error("Empty response text from Gemini");
    }

    const generated = JSON.parse(response.text.trim());
    return {
      ico,
      dic: generated.dic || `CZ${ico}`,
      companyName: generated.companyName || `Firma s.r.o.`,
      street: generated.street || "Vodičkova 15",
      city: generated.city || "Praha",
      zip: (generated.zip || "11000").replace(/\s/g, ""),
      note: "Data vygenerovaná pomocí Gemini AI (ARES API zablokované)"
    };
  }

  // API 1: ARES Registry Proxy - To avoid CORS issues in the web browser
  app.get("/api/ares/:ico", async (req, res) => {
    const { ico } = req.params;
    if (!ico || !/^\d{8}$/.test(ico)) {
      return res.status(400).json({ error: "Neplatný formát IČO. Musí mít 8 číslic." });
    }

    try {
      // 1. Používáme oficiální ARES REST endpoint podle IČO
      const url = `https://ares.gov.cz/ekonomicke-subjekty-v-be/rest/ekonomicke-subjekty/${ico}`;
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 5000); // 5 sekund timeout
      
      let response;
      try {
        response = await fetch(url, {
          signal: controller.signal,
          headers: {
            "Accept": "application/json",
            "User-Agent": "Faktnu PWA Client (adamsmondrk@gmail.com)"
          }
        });
      } catch (fetchErr: any) {
        clearTimeout(timeoutId);
        console.error(`[ARES Fetch Failure] IČO: ${ico}, Reason: ${fetchErr.message}`);
        throw new Error("ARES_CONNECTION_ERROR");
      }

      clearTimeout(timeoutId);

      // 3. Kontrola statusu (musí být 200) a ne-JSON odpovědí (HTML apod.)
      if (!response.ok) {
        if (response.status === 404) {
          return res.status(404).json({ error: "Subjekt s tímto IČO nebyl v registru ARES nalezen." });
        }
        
        const contentType = response.headers.get("content-type") || "";
        const bodyText = await response.text();
        console.error(`[ARES API Bad Status] Status: ${response.status}, Content-Type: ${contentType}, Body: ${bodyText.slice(0, 300)}`);
        
        return res.status(502).json({ 
          error: "Údaje z ARES se teď nepodařilo načíst. Zkuste to prosím znovu později nebo údaje vyplňte ručně." 
        });
      }

      const contentType = response.headers.get("content-type") || "";
      if (!contentType.includes("application/json")) {
        const bodyText = await response.text();
        console.error(`[ARES Non-JSON Content] Status: ${response.status}, Content-Type: ${contentType}, Body: ${bodyText.slice(0, 300)}`);
        
        return res.status(502).json({ 
          error: "Údaje z ARES se teď nepodařilo načíst. Zkuste to prosím znovu později nebo údaje vyplňte ručně." 
        });
      }

      let data;
      try {
        data = await response.json();
      } catch (jsonErr: any) {
        console.error(`[ARES JSON Parse Failed] IČO: ${ico}, Reason: ${jsonErr.message}`);
        return res.status(502).json({ 
          error: "Údaje z ARES se teď nepodařilo načíst. Zkuste to prosím znovu později nebo údaje vyplňte ručně." 
        });
      }

      // 4. Normalizace dat a ošetření prázdných hodnot
      let companyName = data.obchodniJmeno || "";
      let dic = data.dic || "";
      let sidlo = data.sidlo || {};

      // Pokus o parsování z více registrů (zaznamy) pokud chybí kořenové informace
      if ((!companyName || !sidlo.nazevObce) && data.zaznamy && Array.isArray(data.zaznamy) && data.zaznamy.length > 0) {
        const record = data.zaznamy[0];
        const sub = record.subjektEzp || 
                    record.ezp?.subjektEzp || 
                    record.vr?.subjektEzp || 
                    record.rzp?.subjektEzp || 
                    record.res?.subjektEzp ||
                    record.subjekt ||
                    record;
                    
        if (sub) {
          if (!companyName) companyName = sub.obchodniJmeno || sub.obchodniNazev || "";
          if (!dic) dic = sub.dic || "";
          if (!sidlo || !sidlo.nazevObce) sidlo = sub.sidlo || {};
        }
      }

      if (!companyName) {
        return res.status(404).json({ error: "Subjekt s tímto IČO nebyl v registru ARES nalezen." });
      }

      const city = sidlo.nazevObce || "";
      const zip = String(sidlo.psc || sidlo.pscTxt || "").replace(/\s/g, "");
      
      // Sestavení uliční adresy
      let street = "";
      if (sidlo.nazevUlice) {
        street = sidlo.nazevUlice;
        if (sidlo.cisloDomovni) {
          street += ` ${sidlo.cisloDomovni}`;
          if (sidlo.cisloOrientacni) {
            street += `/${sidlo.cisloOrientacni}`;
            if (sidlo.cisloOrientacniPismeno) {
              street += sidlo.cisloOrientacniPismeno;
            }
          }
        }
      } else if (sidlo.nazevCastObce || sidlo.nazevObce) {
        street = sidlo.nazevCastObce || sidlo.nazevObce;
        if (sidlo.cisloDomovni) {
          street += ` ${sidlo.cisloDomovni}`;
        }
      }

      return res.json({
        ico,
        dic,
        companyName,
        street,
        city,
        zip
      });
      
    } catch (error: any) {
      console.warn("ARES Proxy Live Network failed, triggering sandbox and geoblock fallbacks. Reason:", error.message);
      
      // FALLBACK SEKVENCE JAKO POSLEDNÍ MOŽNOST (např. při vývoji offline)
      if (KNOWN_COMPANIES[ico]) {
        console.log(`[ARES Fallback] Resolved known company metadata locally for IČO: ${ico}`);
        return res.json({
          ico,
          ...KNOWN_COMPANIES[ico],
          note: "Načteno z vývojářské databáze (Sandbox)"
        });
      }

      // Pro neznámá IČO vrátíme srozumitelnou chybu uživateli
      return res.status(502).json({
        error: "Údaje z ARES se teď nepodařilo načíst. Zkuste to prosím znovu později nebo údaje vyplňte ručně."
      });
    }
  });

  // API 1.5: Image Proxy - serves remote logos and paylibo QR images with same-origin headers to prevent HTMLCanvas tainting
  app.get("/api/proxy-image", async (req, res) => {
    const imageUrl = req.query.url as string;
    if (!imageUrl) {
      return res.status(400).send("Chybí url parametr pro proxy.");
    }
    try {
      const fetched = await fetch(imageUrl, {
        headers: {
          "User-Agent": "Faktnu.cz Image Proxy"
        }
      });
      if (!fetched.ok) {
        throw new Error(`Failed to fetch remote image: ${fetched.status}`);
      }
      const contentType = fetched.headers.get("content-type") || "image/png";
      res.setHeader("Content-Type", contentType);
      res.setHeader("Cache-Control", "public, max-age=86400"); // cache for 1 day
      
      const buffer = await fetched.arrayBuffer();
      return res.send(Buffer.from(buffer));
    } catch (err: any) {
      console.error("Image proxy failed for URL:", imageUrl, err.message);
      return res.status(500).send(`Chyba při stahování/proxy obrázku: ${err.message}`);
    }
  });

  // API 2: Nodemailer Email Sender with PDF attachment
  app.post("/api/send-email", async (req, res) => {
    try {
      const { 
        recipientEmail, 
        subject, 
        bodyText, 
        pdfBase64, 
        documentNumber,
        smtpSettings 
      } = req.body;

      if (!recipientEmail || !subject || !bodyText || !pdfBase64 || !documentNumber) {
        return res.status(400).json({ error: "Chybí povinné údaje pro odeslání e-mailu." });
      }

      let transporter: any;
      let senderEmail = "noreply@faktnu.cz";
      let senderName = "Faktnu.cz - Fakturační systém";

      // If user provided SMTP settings, use them
      if (
        smtpSettings && 
        smtpSettings.smtpHost && 
        smtpSettings.smtpPort && 
        smtpSettings.smtpUser && 
        smtpSettings.smtpPass
      ) {
        const portNum = Number(smtpSettings.smtpPort);
        transporter = nodemailer.createTransport({
          host: smtpSettings.smtpHost,
          port: portNum,
          secure: portNum === 465,
          auth: {
            user: smtpSettings.smtpUser,
            pass: smtpSettings.smtpPass
          },
          tls: {
            rejectUnauthorized: false // Avoid SSL failure in some custom domains
          }
        });
        senderEmail = smtpSettings.smtpUser;
        if (smtpSettings.emailSenderName) {
          senderName = smtpSettings.emailSenderName;
        }
      } else {
        // Fallback to auto-created Ethereal developer account for sandbox testing
        console.log("No SMTP settings supplied. Generating development sandbox test mail...");
        const testAccount = await nodemailer.createTestAccount();
        transporter = nodemailer.createTransport({
          host: testAccount.smtp.host,
          port: testAccount.smtp.port,
          secure: testAccount.smtp.secure,
          auth: {
            user: testAccount.user,
            pass: testAccount.pass
          }
        });
        senderEmail = testAccount.user;
        senderName = `[SANDBOX TEST] Faktnu.cz`;
      }

      // Convert base64 PDF chunk
      const pdfBuffer = Buffer.from(pdfBase64.split(",")[1] || pdfBase64, "base64");

      const mailOptions = {
        from: `"${senderName}" <${senderEmail}>`,
        to: recipientEmail,
        subject: subject,
        text: bodyText,
        attachments: [
          {
            filename: `${documentNumber}.pdf`,
            content: pdfBuffer,
            contentType: "application/pdf"
          }
        ]
      };

      const info = await transporter.sendMail(mailOptions);
      console.log("E-mail sent: %s", info.messageId);

      // If it is an Ethereal account, provide review URL to the client
      const previewUrl = nodemailer.getTestMessageUrl(info);

      return res.json({ 
        success: true, 
        messageId: info.messageId,
        previewUrl: previewUrl || null,
        isSandbox: !smtpSettings?.smtpHost
      });

    } catch (error: any) {
      console.error("Mail Sender Error:", error);
      return res.status(500).json({ 
        error: "Chyba při odesílání e-mailu přes SMTP server.", 
        details: error.message 
      });
    }
  });

  // Serve static UI assets and handle hot routing via Vite
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Serve production static build
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Faktnu server listening on http://0.0.0.0:${PORT} in ${process.env.NODE_ENV || "development"} mode`);
  });
}

startServer();
