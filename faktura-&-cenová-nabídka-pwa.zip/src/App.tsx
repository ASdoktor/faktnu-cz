import React, { useState, useEffect } from 'react';
import { db, auth, logInWithGoogle } from './lib/firebase';
import { onAuthStateChanged, User, signInWithEmailAndPassword, createUserWithEmailAndPassword } from 'firebase/auth';
import { collection, query, where, onSnapshot, orderBy, doc } from 'firebase/firestore';
import { IUserProfile, IInvoice } from './types';
import UserProfile from './components/UserProfile';
import InvoiceList from './components/InvoiceList';
import InvoiceForm from './components/InvoiceForm';
import InvoicePreview from './components/InvoicePreview';
import StatsView from './components/StatsView';
import CashFlowView from './components/CashFlowView';
import CustomersView from './components/CustomersView';
import { 
  Building2, FileText, ChevronRight, LogIn, Sparkles, Loader2, Plus, LogOut, ArrowLeft, Wallet, User as UserIcon, BarChart2, Users
} from 'lucide-react';

export default function App() {
  const [user, setUser] = useState<User | null>(null);
  const [authLoading, setAuthLoading] = useState(true);
  
  // Navigation State
  const [activeTab, setActiveTab] = useState<'invoices' | 'stats' | 'profile' | 'contacts'>('invoices');
  const [viewMode, setViewMode] = useState<'list' | 'form' | 'preview'>('list');
  
  // Selection states for Invoices Form / Preview
  const [selectedInvoice, setSelectedInvoice] = useState<IInvoice | null>(null);
  const [editingInvoice, setEditingInvoice] = useState<IInvoice | null>(null);

  // Email login form states
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [isSignUp, setIsSignUp] = useState(false);
  const [emailAuthLoading, setEmailAuthLoading] = useState(false);

  // Real-time invoices cache for stats view
  const [invoices, setInvoices] = useState<IInvoice[]>([]);

  // Cached state of current user supplier credentials
  const [supplierProfile, setSupplierProfile] = useState<IUserProfile>({
    uid: '',
    email: '',
    companyName: '',
    street: '',
    city: '',
    zip: '',
    ico: '',
    dic: '',
    bankAccount: '',
    bankCode: '0100',
    dphRate: 0,
    frequentItems: []
  });

  // Keep track of auth state and live data subscription
  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (currentUser) => {
      setUser(currentUser);
      setAuthLoading(false);
      
      // Auto register standard service worker for our PWA offline capabilities
      if ('serviceWorker' in navigator && process.env.NODE_ENV === 'production') {
        window.addEventListener('load', () => {
          navigator.serviceWorker.register('/sw.js').then((registration) => {
            console.log('SW registered successfully: ', registration.scope);
          }, (err) => {
            console.warn('SW registration failed: ', err);
          });
        });
      }
    });

    return () => unsubscribeAuth();
  }, []);

  // Listen to profile updates in real-time
  useEffect(() => {
    if (!user) {
      setSupplierProfile({
        uid: '',
        email: '',
        companyName: '',
        street: '',
        city: '',
        zip: '',
        ico: '',
        dic: '',
        bankAccount: '',
        bankCode: '0100',
        dphRate: 0,
        frequentItems: []
      });
      return;
    }

    const userDocRef = doc(db, 'users', user.uid);
    const unsubscribeProfile = onSnapshot(userDocRef, (snapshot) => {
      if (snapshot.exists()) {
        const data = snapshot.data() as IUserProfile;
        setSupplierProfile({
          ...data,
          uid: user.uid,
          email: user.email || data.email || '',
          frequentItems: data.frequentItems || []
        });
      }
    }, (error) => {
      console.warn("Could not load real-time user profile snapshot.", error);
    });

    return () => unsubscribeProfile();
  }, [user]);

  // Manage live synced collection for stats
  useEffect(() => {
    if (!user) {
      setInvoices([]);
      return;
    }

    const q = query(
      collection(db, 'invoices'),
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeInvoices = onSnapshot(q, (snapshot) => {
      const docsList: IInvoice[] = [];
      snapshot.forEach((doc) => {
        docsList.push(doc.data() as IInvoice);
      });
      setInvoices(docsList);
    }, (error) => {
      console.warn("Live query failed. Stats will be calculated from local items where possible.", error);
    });

    return () => unsubscribeInvoices();
  }, [user]);

  const handleEmailAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !password.trim()) return;
    setEmailAuthLoading(true);
    try {
      if (isSignUp) {
        await createUserWithEmailAndPassword(auth, email, password);
      } else {
        await signInWithEmailAndPassword(auth, email, password);
      }
    } catch (err: any) {
      console.error(err);
      let errMsg = "Přihlášení se nezdařilo.";
      if (err.code === 'auth/invalid-credential') {
        errMsg = "Zadali jste chybné heslo nebo e-mail.";
      } else if (err.code === 'auth/email-already-in-use') {
        errMsg = "Tento e-mail je již používán jiným uživatelem.";
      } else if (err.code === 'auth/weak-password') {
        errMsg = "Zadané heslo je slabé (musí mít alespoň 6 znaků).";
      } else if (err.code === 'auth/invalid-email') {
        errMsg = "Prosím zadejte platnou e-mailovou adresu.";
      }
      alert(errMsg);
    } finally {
      setEmailAuthLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      await logInWithGoogle();
    } catch (e) {
      alert("Přihlášení selhalo. Ujistěte se, že Váš prohlížeč neblokuje vyskakovací okna (popups).");
    }
  };

  const handleProfileSaved = (profile: IUserProfile) => {
    setSupplierProfile(profile);
  };

  const handleEditInvoice = (invoice: IInvoice) => {
    setEditingInvoice(invoice);
    setViewMode('form');
  };

  const handleSelectInvoice = (invoice: IInvoice) => {
    setSelectedInvoice(invoice);
  };

  const handleSavedInvoice = () => {
    setViewMode('list');
    setEditingInvoice(null);
  };

  if (authLoading) {
    return (
      <div className="min-h-screen bg-slate-50 flex flex-col items-center justify-center p-4">
        <Loader2 className="w-10 h-10 text-indigo-600 animate-spin mb-4" />
        <p className="text-slate-600 text-sm font-medium">Připojuji se k zabezpečenému serveru Faktnu...</p>
      </div>
    );
  }

  // GUEST LANDING PAGE (Secure, high-contrast, and visually stunning Bento design)
  if (!user) {
    return (
      <div className="min-h-screen bg-slate-100 text-slate-800 flex flex-col justify-between">
        
        {/* Decorative Top gradient lines */}
        <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-indigo-500 via-blue-500 to-amber-500"></div>

        {/* Outer Header */}
        <header className="px-6 py-6 flex items-center justify-between border-b border-slate-200 bg-white shadow-xs">
          <div className="flex items-center gap-3 select-none">
            <img src="/images/faktnulogofull.webp" alt="Faktnu.cz logo" className="w-20 h-20 sm:w-28 sm:h-28 md:w-36 md:h-36 object-contain rounded-3xl md:rounded-[2rem]" referrerPolicy="no-referrer" />
            <span className="font-bold text-xl sm:text-2xl font-display tracking-tight text-slate-900 font-display">Faktnu.cz</span>
          </div>
          <span className="text-[10px] font-mono font-medium tracking-wide text-slate-500 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-full uppercase">
            Mobilní Edice v1.0
          </span>
        </header>

        {/* Core Hero card (styled like a bento card) */}
        <main className="flex-1 flex items-center justify-center px-4 py-8 max-w-lg mx-auto w-full">
          <div className="w-full bg-white border border-slate-200 rounded-3xl p-6 sm:p-10 space-y-6 shadow-md relative overflow-hidden">
            
            {/* Background design glow */}
            <div className="absolute -top-16 -right-16 w-32 h-32 bg-indigo-500/5 rounded-full blur-3xl pointer-events-none"></div>

            <div className="text-center space-y-3.5">
              <div className="mx-auto w-12 h-12 rounded-2xl bg-indigo-50/80 text-indigo-600 flex items-center justify-center mb-1 border border-indigo-100">
                <Wallet className="w-6 h-6" />
              </div>
              <h2 className="text-2xl sm:text-2xl font-extrabold font-display leading-tight tracking-tight text-slate-900">
                Faktury v kapse.<br /><span className="text-indigo-600">Snadno a profesionálně.</span>
              </h2>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto font-sans">
                Vystavujte faktury, zálohovky a cenové nabídky přímo z mobilu nebo počítače. S automatickým vyplňováním IČO přes ARES, přehlednou evidencí příjmů i výdajů a QR kódy.
              </p>
            </div>

            {/* Bullet List details */}
            <div className="space-y-2.5 text-slate-600 text-xs py-1 border-t border-b border-slate-100 my-2">
              <div className="flex items-start gap-2">
                <span className="text-indigo-500 font-bold">•</span>
                <p>Nalezení firem v registru ARES podle IČO bez překlepů</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-indigo-500 font-bold">•</span>
                <p>Generování platebních QR kódů přímo na faktuře</p>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-indigo-500 font-bold">•</span>
                <p>Ukládání více profilů dodavatelů a rychlé přepínání</p>
              </div>
            </div>

            <div className="space-y-4">
              <button
                onClick={handleGoogleLogin}
                className="w-full inline-flex items-center justify-center gap-2.5 py-3.5 px-6 bg-slate-950 hover:bg-slate-900 text-white font-bold rounded-2xl text-xs transition shadow-md hover:scale-[1.01] active:scale-[0.99] cursor-pointer touch-manipulation"
              >
                <LogIn className="w-4 h-4 text-indigo-400" />
                <span>Přihlásit se přes Google</span>
              </button>
              
              {/* Divider */}
              <div className="relative flex items-center justify-center py-2">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200"></div>
                </div>
                <span className="relative bg-white px-3 text-[10px] uppercase font-bold tracking-wider text-slate-400">nebo e-mailem</span>
              </div>

              {/* Email auth form */}
              <form onSubmit={handleEmailAuth} className="space-y-3.5">
                <div className="space-y-1">
                  <label className="text-[10px] font-bold text-slate-500 block uppercase">E-mailová adresa</label>
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="jondoe@email.cz"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                  />
                </div>

                <div className="space-y-1">
                  <div className="flex items-center justify-between">
                    <label className="text-[10px] font-bold text-slate-500 block uppercase">Přihlašovací heslo</label>
                    <button
                      type="button"
                      onClick={() => setIsSignUp(!isSignUp)}
                      className="text-[10px] font-bold text-indigo-600 hover:text-indigo-500 transition cursor-pointer"
                    >
                      {isSignUp ? 'Chci se přihlásit' : 'Vytvořit účet (Registrace)'}
                    </button>
                  </div>
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                  />
                </div>

                <button
                  type="submit"
                  disabled={emailAuthLoading}
                  className="w-full inline-flex items-center justify-center gap-1.5 py-3 px-6 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white font-bold rounded-2xl text-xs transition cursor-pointer touch-manipulation shadow-lg shadow-indigo-100"
                >
                  {emailAuthLoading ? (
                    <Loader2 className="w-3.5 h-3.5 animate-spin" />
                  ) : (
                    <Plus className="w-3.5 h-3.5" />
                  )}
                  <span>{isSignUp ? 'Zaregistrovat a vytvořit účet' : 'Přihlásit se e-mailem'}</span>
                </button>
              </form>

              <p className="text-[9px] text-slate-400 text-center leading-relaxed">
                Údaje jsou bezpečně uloženy v databázi Cloud Firestore.
              </p>
            </div>

          </div>
        </main>

        <footer className="py-6 border-t border-slate-200 text-center text-[10px] text-slate-400 bg-white shadow-xs select-none">
          Vyvinuto s podporou registrů ČR • © 2026 Faktnu.cz
        </footer>

      </div>
    );
  }

  // AUTHENTICATED WORKSPACE
  return (
    <div className="min-h-screen bg-slate-100/70 text-slate-800 flex flex-col justify-between">
      
      {/* 1. TOP TITLE HEADER BAR (Bento styled light navigation bar) */}
      <header className="no-print bg-white border-b border-slate-200 sticky top-0 z-40 select-none shadow-xs">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3.5 flex items-center justify-between">
          
          <button
            onClick={() => {
              setActiveTab('invoices');
              setViewMode('list');
              setSelectedInvoice(null);
              setEditingInvoice(null);
            }}
            className="flex items-center gap-2.5 text-left hover:opacity-85 transition cursor-pointer font-display"
          >
            <img src="/images/faktnulogofull.webp" alt="Faktnu.cz logo" className="w-16 h-16 sm:w-22 sm:h-22 md:w-26 md:h-26 object-contain rounded-2xl sm:rounded-3xl" referrerPolicy="no-referrer" />
          </button>

          <div className="flex items-center gap-2">
            {activeTab === 'invoices' && viewMode === 'list' && (
              <button
                onClick={() => {
                  if (!supplierProfile.companyName) {
                    alert("Před vystavením dokladu prosím nejdříve vyplňte a uložte svůj profil dodavatele!");
                    setActiveTab('profile');
                    return;
                  }
                  setEditingInvoice(null);
                  setViewMode('form');
                }}
                className="inline-flex items-center gap-1 px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100 transition cursor-pointer touch-manipulation hover:scale-[1.01] active:scale-[0.99]"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Vystavit doklad</span>
              </button>
            )}
            
            {activeTab === 'profile' && (
              <span className="text-[10px] font-mono bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-xl text-slate-600 font-semibold shadow-2xs">
                Profil Dodavatele
              </span>
            )}

            {activeTab === 'contacts' && (
              <span className="text-[10px] font-mono bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-xl text-indigo-600 font-bold shadow-2xs">
                Adresář Odběratelů
              </span>
            )}

            {activeTab === 'stats' && (
              <span className="text-[10px] font-mono bg-slate-50 border border-slate-200 px-2.5 py-1 rounded-xl text-slate-600 font-semibold shadow-2xs">
                Přehled a Statistiky
              </span>
            )}

            <button
              onClick={() => auth.signOut()}
              className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-xl transition cursor-pointer"
              title="Odhlásit se"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* 2. CENTRAL ACTIVE ROUTING VIEWPORT */}
      <main className={`flex-1 py-6 bg-slate-100/70 overflow-x-hidden ${selectedInvoice ? 'no-print' : ''}`}>
        <div className={`mx-auto w-full ${viewMode === 'list' ? 'max-w-7xl px-4 sm:px-6' : 'max-w-3xl px-4'}`}>
          {activeTab === 'invoices' ? (
            <>
              {viewMode === 'list' && (
                <InvoiceList 
                  supplierProfile={supplierProfile}
                  onEditInvoice={handleEditInvoice}
                  onSelectInvoice={handleSelectInvoice}
                  onAddNewClick={() => {
                    if (!supplierProfile.companyName) {
                      alert("Před vystavením dokladu prosím nejdříve vyplňte a uložte svůj profil dodavatele!");
                      setActiveTab('profile');
                      return;
                    }
                    setEditingInvoice(null);
                    setViewMode('form');
                  }}
                  onNavigateToProfile={() => {
                    setActiveTab('profile');
                  }}
                />
              )}

              {viewMode === 'form' && (
                <InvoiceForm 
                  supplierProfile={supplierProfile}
                  editingInvoice={editingInvoice}
                  onSaved={handleSavedInvoice}
                  onCancel={() => {
                    setViewMode('list');
                    setEditingInvoice(null);
                  }}
                />
              )}
            </>
          ) : activeTab === 'stats' ? (
            <StatsView invoices={invoices} />
          ) : activeTab === 'contacts' ? (
            <CustomersView />
          ) : (
            <UserProfile onSaved={handleProfileSaved} />
          )}
        </div>
      </main>

      {/* 3. LIGHTWEIGHT INVOICE DETAIL SHEET OVERLAY (PREVIEW MODE) */}
      {selectedInvoice && (
        <InvoicePreview 
          invoice={selectedInvoice}
          supplierProfile={supplierProfile}
          onClose={() => setSelectedInvoice(null)}
        />
      )}

      {/* 4. BOTTOM NAVIGATION NAVIGATION BAR FOR PHONES (Bento card style bottom bar) */}
      <nav id="bottom-navigation-bar" className="no-print bg-white border-t border-slate-200 py-2 sticky bottom-0 z-40 select-none shadow-lg">
        <div className="max-w-xl mx-auto px-6 flex justify-around items-center">
          
          <button
            onClick={() => {
              setActiveTab('invoices');
              setViewMode('list');
            }}
            className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition cursor-pointer touch-manipulation ${
              activeTab === 'invoices' 
                ? 'text-indigo-600 font-bold' 
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <FileText className="w-5 h-5" />
            <span className="text-[10px]">Doklady</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('contacts');
            }}
            className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition cursor-pointer touch-manipulation ${
              activeTab === 'contacts' 
                ? 'text-indigo-600 font-bold' 
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <Users className="w-5 h-5" />
            <span className="text-[10px]">Odběratelé</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('stats');
            }}
            className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition cursor-pointer touch-manipulation ${
              activeTab === 'stats' 
                ? 'text-indigo-600 font-bold' 
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <BarChart2 className="w-5 h-5" />
            <span className="text-[10px]">Statistiky</span>
          </button>

          <button
            onClick={() => {
              setActiveTab('profile');
            }}
            className={`flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition cursor-pointer touch-manipulation ${
              activeTab === 'profile' 
                ? 'text-indigo-600 font-bold' 
                : 'text-slate-400 hover:text-slate-600'
            }`}
          >
            <UserIcon className="w-5 h-5" />
            <span className="text-[10px]">Profil</span>
          </button>

        </div>
      </nav>

    </div>
  );
}
