export type IDocumentType = "invoice" | "advance" | "quote";
export type IDocumentStatus = "draft" | "sent" | "paid" | "overdue";

export interface ISupplier {
  id?: string;
  companyName: string;
  street: string;
  city: string;
  zip: string;
  ico: string;
  dic?: string;
  bankAccount: string;
  bankCode: string;
  logoUrl?: string;
  phone?: string;
}

export interface ICustomer {
  companyName: string;
  email: string;
  street: string;
  city: string;
  zip: string;
  ico: string;
  dic?: string;
  phone?: string;
}

export interface IInvoiceItem {
  id: string; // generated client-side for keys/tracking
  name: string;
  unit: string;
  count: number;
  pricePerUnit: number;
  vatRate: number; // e.g. 21, 15, 0
}

export interface IFrequentItem {
  id: string;
  name: string;
  unit: string;
  price: number;
}

export interface INumberingSettings {
  prefix: string;
  includeYear: boolean;
  digitCount: number; // e.g. 4 for 0001
  startNumber: number; // e.g. 1
  resetYearly: boolean;
}

export interface ICustomerContact {
  id?: string;
  ownerId: string;
  companyName: string;
  ico: string;
  dic?: string;
  street: string;
  city: string;
  zip: string;
  country: string; // e.g. "Česká republika"
  email: string;
  phone?: string;
  note?: string;
  createdAt?: string;
}

export interface IUserProfile {
  uid: string;
  email: string;
  companyName: string;
  street: string;
  city: string;
  zip: string;
  ico: string;
  dic?: string;
  phone?: string;
  bankAccount: string;
  bankCode: string;
  dphRate: number; // default DPH rate
  logoUrl?: string; // Base64 representation of loaded file
  brandColor?: string; // hex
  invoiceLayout?: string; // "classic" | "modern" | "minimal"
  frequentItems?: IFrequentItem[];
  smtpHost?: string;
  smtpPort?: number;
  smtpUser?: string;
  smtpPass?: string;
  emailSenderName?: string;
  suppliers?: ISupplier[]; // list of additional suppliers options
  activeSupplierId?: string; // ID of currently active profile
  invoiceNumbering?: INumberingSettings;
  advanceNumbering?: INumberingSettings;
  quoteNumbering?: INumberingSettings;
}

export interface IInvoice {
  id: string; // firestore ID or local ID
  ownerId: string;
  type: IDocumentType;
  documentNumber: string;
  issuedDate: string;
  dueDate: string;
  validUntil?: string; // for quote validity field
  variableSymbol: string;
  constantSymbol?: string;
  specificSymbol?: string;
  supplier: ISupplier;
  customer: ICustomer;
  items: IInvoiceItem[];
  totalAmount: number;
  note?: string;
  status: IDocumentStatus;
  createdAt?: any;
  updatedAt?: any;
  _hasPendingWrites?: boolean;
}

export interface ICashFlowRecord {
  id: string;
  ownerId: string;
  type: 'income' | 'expense';
  amount: number;
  date: string;
  category: string;
  description: string;
  invoiceId?: string;
  createdAt: string;
}
