import React, { useState, useEffect } from 'react';
import { db, auth, handleFirestoreError, OperationType } from '../lib/firebase';
import { collection, query, where, getDocs, doc, deleteDoc, updateDoc, onSnapshot, orderBy } from 'firebase/firestore';
import { IInvoice, IDocumentType, IDocumentStatus, IUserProfile } from '../types';
import { 
  Plus, Search, Filter, Trash2, Edit, CheckCircle, Eye, Info, AlertCircle, TrendingUp, Sparkles, Wifi, WifiOff, RefreshCw, Loader2, Building2, ExternalLink, QrCode, Award,
  X, Mail, Download, Printer, Wallet, FileText, ChevronRight
} from 'lucide-react';
import CashFlowView from './CashFlowView';

interface InvoiceListProps {
  supplierProfile: IUserProfile;
  onEditInvoice: (invoice: IInvoice) => void;
  onSelectInvoice: (invoice: IInvoice) => void;
  onAddNewClick: () => void;
  onNavigateToProfile?: () => void;
}

export default function InvoiceList({ supplierProfile, onEditInvoice, onSelectInvoice, onAddNewClick, onNavigateToProfile }: InvoiceListProps) {
  const [invoices, setInvoices] = useState<IInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Tab within Doklady section: invoices or cashflow
  const [activeSubTab, setActiveSubTab] = useState<'invoices' | 'cashflow'>('invoices');
  
  // Selected invoice for dynamic QR/banking details Bento preview card inside the dashboard on desktop
  const [selectedPreviewInvoice, setSelectedPreviewInvoice] = useState<IInvoice | null>(null);

  // Quick Action popup state
  const [quickActionInvoice, setQuickActionInvoice] = useState<IInvoice | null>(null);

  // Search and filters
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [selectedStatus, setSelectedStatus] = useState<string>('all');
  const [isOnline, setIsOnline] = useState(navigator.onLine);

  // Auto-select first loaded invoice for Quick Preview on mount/load
  useEffect(() => {
    if (invoices.length > 0 && !selectedPreviewInvoice) {
      setSelectedPreviewInvoice(invoices[0]);
    }
  }, [invoices, selectedPreviewInvoice]);

  // Monitor browser network connection (for PWA offline sync diagnostics)
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  // Set up reactive firestore listener with offline cache retrieval support
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const invoicesRef = collection(db, 'invoices');
    // Read user invoices ordered by issue date/creation
    const q = query(
      invoicesRef, 
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, { includeMetadataChanges: true }, (snapshot) => {
      const docsList: IInvoice[] = [];
      snapshot.forEach((docSnap) => {
        const data = docSnap.data() as IInvoice;
        data._hasPendingWrites = docSnap.metadata.hasPendingWrites;
        docsList.push(data);
      });
      setInvoices(docsList);
      setLoading(false);
    }, (error) => {
      console.warn("Snapshot subscription failed. Reading from local cache if offline.");
      // Fallback: manual getDocs
      getDocs(q).then((snap) => {
        const docsList: IInvoice[] = [];
        snap.forEach((docSnap) => {
          const data = docSnap.data() as IInvoice;
          data._hasPendingWrites = docSnap.metadata.hasPendingWrites;
          docsList.push(data);
        });
        setInvoices(docsList);
        setLoading(false);
      }).catch(err => {
        handleFirestoreError(err, OperationType.LIST, 'invoices');
      });
    });

    return () => unsubscribe();
  }, []);

  // Calculate invoice statistics dynamically
  const getStats = () => {
    let salesTotal = 0;
    let paidTotal = 0;
    let outstandingTotal = 0;

    invoices.forEach(inv => {
      // Exclude price quotes (Cenová nabídka) from official turnover calculation
      if (inv.type === 'quote') return;

      const amt = inv.totalAmount || 0;
      salesTotal += amt;
      if (inv.status === 'paid') {
        paidTotal += amt;
      } else {
        outstandingTotal += amt;
      }
    });

    return {
      sales: Math.round(salesTotal),
      paid: Math.round(paidTotal),
      outstanding: Math.round(outstandingTotal)
    };
  };

  const stats = getStats();

  // Handle invoice delete
  const handleDelete = async (id: string, number: string) => {
    if (!confirm(`Opravdu si přejete smazat doklad č. ${number}? Akce je nevratná.`)) return;

    try {
      await deleteDoc(doc(db, 'invoices', id));
    } catch (err) {
      console.error(err);
      alert('Smazání se nezdařilo. Zkuste to prosím znovu.');
    }
  };

  // Change invoice payment status with one-tap
  const togglePaidStatus = async (id: string, currentStatus: IDocumentStatus) => {
    const nextStatus: IDocumentStatus = currentStatus === 'paid' ? 'sent' : 'paid';
    try {
      const docRef = doc(db, 'invoices', id);
      await updateDoc(docRef, { status: nextStatus, updatedAt: new Date().toISOString() });
    } catch (err) {
      console.error(err);
      alert('Chyba při změně stavu faktury.');
    }
  };

  // Filter & Search computation
  const filteredInvoices = invoices.filter(inv => {
    const matchesSearch = 
      inv.documentNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inv.customer.companyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (inv.variableSymbol || '').includes(searchTerm);

    const matchesType = selectedType === 'all' || inv.type === selectedType;
    const matchesStatus = selectedStatus === 'all' || inv.status === selectedStatus;

    return matchesSearch && matchesType && matchesStatus;
  });

  const getStatusBadge = (status: IDocumentStatus) => {
    switch (status) {
      case 'paid':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/15 text-emerald-400">Zaplaceno</span>;
      case 'sent':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-blue-500/15 text-blue-400">Odesláno</span>;
      case 'overdue':
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-red-500/15 text-red-400 font-medium">Po splatnosti</span>;
      default:
        return <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-slate-700/50 text-slate-300">Koncept</span>;
    }
  };

  const getTypeLabel = (type: IDocumentType) => {
    switch (type) {
      case 'advance': return 'Záloha';
      case 'quote': return 'Nabídka';
      default: return 'Faktura';
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-3" />
        <p className="text-slate-600 text-sm">Načítám evidované doklady...</p>
      </div>
    );
  }

  // Calculate paid total percentage for visual indicator in stats bento card
  const paidPercent = stats.sales > 0 ? Math.round((stats.paid / stats.sales) * 100) : 0;

  return (
    <div className="w-full space-y-6 pb-20 no-print">

      {/* SEGMENTED SUB-TAB SWITCHER */}
      <div className="flex bg-slate-205/50 p-1.5 rounded-2xl border border-slate-300/30 text-xs select-none max-w-sm mx-auto mb-2 shadow-3xs font-display">
        <button
          onClick={() => setActiveSubTab('invoices')}
          className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer text-center text-xs flex items-center justify-center gap-1.5 ${
            activeSubTab === 'invoices' 
              ? 'bg-indigo-600 text-white shadow-xs' 
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <FileText className="w-4 h-4" />
          <span>Faktury & Doklady</span>
        </button>
        <button
          onClick={() => setActiveSubTab('cashflow')}
          className={`flex-1 py-1.5 rounded-xl font-bold transition-all cursor-pointer text-center text-xs flex items-center justify-center gap-1.5 ${
            activeSubTab === 'cashflow' 
              ? 'bg-indigo-600 text-white shadow-xs' 
              : 'text-slate-500 hover:text-slate-700'
          }`}
        >
          <Wallet className="w-4 h-4" />
          <span>Příjmy & Výdaje</span>
        </button>
      </div>

      {activeSubTab === 'cashflow' ? (
        <CashFlowView />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start animate-fade-in">
          
          {/* LEFT COLUMN: QUICK ACTIONS, PROFILE BRIEF, INSTALL AND SYNC (md:col-span-4) */}
          <div className="col-span-1 md:col-span-4 space-y-6 flex flex-col justify-start">
            
            {/* QUICK ACTIONS BENTO CARD */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between min-h-[220px]">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-mono uppercase tracking-wider text-slate-400 font-bold">Rychlý start</span>
                  <Sparkles className="w-4 h-4 text-indigo-500 animate-pulse" />
                </div>
                <h3 className="text-lg font-black font-display text-slate-900 mt-2">Vytvořit nový...</h3>
                <p className="text-xs text-slate-500 mt-1">Stiskněte typ dokladu, který si přejete okamžitě vygenerovat a evidovat.</p>
              </div>
              
              <div className="grid grid-cols-1 gap-1.5 mt-4">
                <button
                  onClick={onAddNewClick}
                  className="w-full inline-flex items-center justify-between px-4 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold transition cursor-pointer shadow-sm shadow-indigo-100 touch-manipulation"
                >
                  <span>Faktura / Daňový doklad</span>
                  <Plus className="w-3.5 h-3.5" />
                </button>
                
                <button
                  onClick={onAddNewClick}
                  className="w-full inline-flex items-center justify-between px-4 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition cursor-pointer touch-manipulation"
                >
                  <span>Zálohová platba</span>
                  <Plus className="w-3.5 h-3.5 text-slate-400" />
                </button>

                <button
                  onClick={onAddNewClick}
                  className="w-full inline-flex items-center justify-between px-4 py-2.5 bg-slate-50 hover:bg-slate-100 text-slate-700 rounded-xl text-xs font-semibold border border-slate-200 transition cursor-pointer touch-manipulation"
                >
                  <span>Cenová nabídka</span>
                  <Plus className="w-3.5 h-3.5 text-slate-400" />
                </button>
              </div>
            </div>

          </div>

          {/* RIGHT COLUMN: STATS AND LIST TABLE (md:col-span-8) */}
          <div className="col-span-1 md:col-span-8 space-y-6 flex flex-col justify-start">
            
            {/* STATS BANNER CARD (Pridana Indigo Bento Card) */}
            <div className="bg-indigo-950 text-white rounded-3xl p-6 shadow-md relative overflow-hidden min-h-[220px] flex flex-col justify-between">
              {/* Background vector circles */}
              <div className="absolute top-0 right-0 w-44 h-44 bg-indigo-900 rounded-full blur-3xl opacity-30 pointer-events-none"></div>
              <div className="absolute bottom-0 left-12 w-32 h-32 bg-indigo-800 rounded-full blur-3xl opacity-20 pointer-events-none"></div>
              
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono uppercase tracking-widest text-indigo-300 font-bold">Přehled hospodaření • celkem</span>
              </div>

              <div className="my-3 text-left">
                <h4 className="text-[10px] uppercase tracking-wider text-indigo-300 font-bold">Celkově vyfakturováno</h4>
                <p className="text-3xl sm:text-4xl font-extrabold font-mono tracking-tight text-white mt-1">
                  {stats.sales.toLocaleString('cs-CZ')} <span className="text-lg font-sans font-medium text-indigo-300">Kč</span>
                </p>
              </div>

              {/* Micro stats and linear progress bar inside bento grid */}
              <div className="border-t border-indigo-900/80 pt-4 mt-1 grid grid-cols-2 gap-4">
                <div>
                  <p className="text-[10px] text-emerald-300 uppercase font-bold tracking-wider">Uhrazeno ({paidPercent}%)</p>
                  <p className="text-base font-bold font-mono text-emerald-400 mt-0.5">
                    {stats.paid.toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-indigo-300">Kč</span>
                  </p>
                </div>

                <div>
                  <p className="text-[10px] text-amber-400 uppercase font-bold tracking-wider">K úhradě / zbývá</p>
                  <p className="text-base font-bold font-mono text-amber-400 mt-0.5">
                    {stats.outstanding.toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-indigo-300">Kč</span>
                  </p>
                </div>
              </div>

              {/* Linear tracker */}
              <div className="w-full bg-indigo-900/50 rounded-full h-1.5 mt-3 relative overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-emerald-400 to-teal-400 h-1.5 rounded-full transition-all duration-500" 
                  style={{ width: `${paidPercent}%` }}
                ></div>
              </div>
            </div>

            {/* MAIN DOCUMENTS LIST CARD */}
            <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm space-y-4">
              
              <div className="flex items-center justify-between select-none">
                <h3 className="font-black text-slate-900 font-display text-base">Evidované doklady ({filteredInvoices.length})</h3>
                {!supplierProfile.companyName && (
                  <span className="text-[11px] text-amber-600 bg-amber-50 px-2.5 py-1 rounded-xl font-medium flex items-center gap-1 border border-amber-100">
                    <AlertCircle className="w-3.5 h-3.5" /> Chybí profil dodavatele!
                  </span>
                )}
              </div>

              {/* SEARCH AND FILTER CRITERIAS INSIDE DASHBOARD */}
              <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 bg-slate-50 border border-slate-200/60 p-4 rounded-2xl">
                {/* Search input bar */}
                <div className="col-span-1 sm:col-span-6 relative">
                  <Search className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  <input
                    type="text"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    placeholder="Hledat firmu, číslo nebo VS..."
                    className="w-full bg-white border border-slate-200 rounded-xl pl-9 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 transition shadow-2xs cursor-text"
                  />
                </div>

                {/* Filter selectors */}
                <div className="col-span-1 sm:col-span-3">
                  <select
                    value={selectedType}
                    onChange={(e) => setSelectedType(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-medium focus:outline-none focus:border-indigo-500 shadow-2xs"
                  >
                    <option value="all">Všechny doklady</option>
                    <option value="invoice">Faktury (Daňové)</option>
                    <option value="advance">Zálohové platby</option>
                    <option value="quote">Cenové nabídky</option>
                  </select>
                </div>

                <div className="col-span-1 sm:col-span-3">
                  <select
                    value={selectedStatus}
                    onChange={(e) => setSelectedStatus(e.target.value)}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-xs text-slate-700 font-medium focus:outline-none focus:border-indigo-500 shadow-2xs"
                  >
                    <option value="all">Všechny stavy</option>
                    <option value="draft">Koncepty</option>
                    <option value="sent">Odeslané</option>
                    <option value="paid">Uhrazené</option>
                  </select>
                </div>
              </div>

              {/* INVOICES LIST CONTAINER */}
              {filteredInvoices.length === 0 ? (
                <div className="p-10 rounded-2xl border border-slate-100 bg-slate-50/50 text-center space-y-3.5">
                  <p className="text-slate-400 text-xs italic">Nebyly nalezeny žádné doklady vyhovující filtrům.</p>
                  <button
                    onClick={onAddNewClick}
                    className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold cursor-pointer transition shadow-sm"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Vystavit první doklad</span>
                  </button>
                </div>
              ) : (
                <div className="space-y-2.5 font-sans">
                  {filteredInvoices.map((inv) => (
                    <div 
                      key={inv.id}
                      onClick={() => setQuickActionInvoice(inv)}
                      className="p-4 rounded-2xl border bg-white border-slate-200/80 hover:border-indigo-400 hover:bg-indigo-50/10 cursor-pointer transition flex flex-col sm:flex-row gap-3 justify-between items-start md:items-center shadow-3xs"
                    >
                      {/* Header metadata row */}
                      <div className="w-full flex-1 pr-2 space-y-1.5 select-none">
                        <div className="flex flex-wrap items-center gap-2 font-display">
                          <span className="text-xs font-mono font-bold text-slate-900">{inv.documentNumber}</span>
                          <span className="text-[10px] text-slate-500 bg-slate-100 px-2 py-0.5 rounded font-medium">
                            {getTypeLabel(inv.type)}
                          </span>
                          {getStatusBadge(inv.status)}
                          {inv._hasPendingWrites && (
                            <span className="animate-pulse text-[9px] text-amber-700 bg-amber-50 border border-amber-200/55 px-1.5 py-0.5 rounded-md font-bold flex items-center gap-0.5" title="Offline akce čeká na uložení do cloudu">
                              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
                              Čeká na sync
                            </span>
                          )}
                        </div>

                        <div>
                          <h4 className="font-bold text-slate-800 text-sm truncate">{inv.customer.companyName}</h4>
                          <div className="flex items-center gap-3 text-[10px] text-slate-400 mt-1">
                            <span>VS: <strong className="text-slate-600 font-mono font-medium">{inv.variableSymbol}</strong></span>
                            <span>Splatnost: <strong className="text-slate-600">{new Date(inv.dueDate).toLocaleDateString('cs-CZ')}</strong></span>
                          </div>
                        </div>
                      </div>

                      {/* Amount details and item triggers */}
                      <div className="w-full sm:w-auto flex sm:flex-col items-center sm:items-end justify-between sm:justify-center border-t sm:border-t-0 border-slate-100 pt-3 sm:pt-0 shrink-0">
                        <div className="text-right">
                          <p className="text-sm font-black text-slate-900 font-mono">
                            {inv.totalAmount.toLocaleString('cs-CZ')} <span className="text-[10px] font-sans font-medium text-slate-400">Kč</span>
                          </p>
                        </div>

                        {/* Actions Row */}
                        <div className="flex items-center gap-1.5 mt-2">
                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onSelectInvoice(inv);
                            }}
                            className="p-1 px-2.5 bg-slate-50 hover:bg-indigo-50 border border-slate-200 hover:border-indigo-100 text-slate-600 hover:text-indigo-700 rounded-lg transition text-[11px] font-bold flex items-center gap-1 cursor-pointer shadow-3xs"
                            title="Nahlédnout"
                          >
                            <Eye className="w-3.5 h-3.5" />
                            <span>Zobrazit</span>
                          </button>

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              onEditInvoice(inv);
                            }}
                            className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg border border-slate-100 hover:border-indigo-100 bg-white transition cursor-pointer shadow-3xs"
                            title="Upravit"
                          >
                            <Edit className="w-3.5 h-3.5" />
                          </button>

                          {inv.type !== 'quote' && (
                            <button
                              onClick={(e) => {
                                e.stopPropagation();
                                togglePaidStatus(inv.id, inv.status);
                              }}
                              className={`p-1.5 rounded-lg border bg-white transition cursor-pointer shadow-3xs ${
                                inv.status === 'paid' 
                                  ? 'text-emerald-500 border-emerald-100 hover:bg-emerald-50' 
                                  : 'text-slate-400 border-slate-100 hover:text-emerald-500 hover:border-emerald-100 hover:bg-emerald-50'
                              }`}
                              title={inv.status === 'paid' ? 'Odznačit jako uhrazené' : 'Označit jako UHRAZENÉ'}
                            >
                              <CheckCircle className="w-3.5 h-3.5" />
                            </button>
                          )}

                          <button
                            onClick={(e) => {
                              e.stopPropagation();
                              handleDelete(inv.id, inv.documentNumber);
                            }}
                            className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg border border-slate-100 hover:border-red-100 bg-white transition cursor-pointer shadow-3xs"
                            title="Smazat doklad"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </div>

                    </div>
                  ))}
                </div>
              )}
            </div>

          </div>

        </div>
      )}

      {/* QUICK ACTION & PAY QR POPUP MODAL */}
      {quickActionInvoice && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center z-50 p-4 select-none animate-fade-in no-print">
          <div className="bg-white rounded-3xl border border-slate-200 max-w-sm w-full overflow-hidden shadow-2xl transition duration-200">
            
            {/* Header of Popup */}
            <div className="p-5 border-b border-slate-100 flex items-start justify-between bg-slate-50/80">
              <div className="min-w-0 flex-1">
                <span className="text-[10px] font-mono font-bold text-slate-400 tracking-wider uppercase">Rychlá nabídka • {getTypeLabel(quickActionInvoice.type)}</span>
                <h3 className="font-extrabold text-slate-900 font-display text-base tracking-tight mt-0.5">{quickActionInvoice.documentNumber}</h3>
                <p className="text-xs font-semibold text-indigo-600 truncate mt-0.5">{quickActionInvoice.customer.companyName}</p>
              </div>
              <button 
                onClick={() => setQuickActionInvoice(null)}
                className="p-1.5 rounded-xl hover:bg-slate-200 text-slate-400 hover:text-slate-600 transition cursor-pointer shrink-0 ml-2"
                aria-label="Close"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Main Content Area */}
            <div className="p-5 space-y-4">
              
              {/* 1. Payment QR Block (Hide for Quotes) */}
              {quickActionInvoice.type !== 'quote' ? (
                <div className="bg-slate-900 text-white p-3.5 rounded-2xl flex items-center justify-between gap-3 border border-slate-800">
                  <div className="space-y-1.5 min-w-0 flex-1">
                    <div className="flex items-center gap-1.5">
                      <QrCode className="w-3.5 h-3.5 text-indigo-400 animate-pulse" />
                      <span className="text-[9px] font-mono font-bold tracking-widest text-slate-400 uppercase">Rychlá QR Platba</span>
                    </div>
                    
                    <div className="text-[11px] space-y-0.5 text-slate-300">
                      <p>Var. symbol: <span className="text-white font-mono font-semibold">{quickActionInvoice.variableSymbol}</span></p>
                      <p>K úhradě: <span className="text-emerald-400 font-mono font-semibold">{quickActionInvoice.totalAmount.toLocaleString('cs-CZ')} Kč</span></p>
                      <p className="text-[10px] text-slate-400 truncate">Splatnost: {new Date(quickActionInvoice.dueDate).toLocaleDateString('cs-CZ')}</p>
                    </div>
                  </div>

                  {/* QR Image rendering dynamically */}
                  <div className="bg-white p-1 rounded-xl shrink-0 shadow-lg flex items-center justify-center">
                    <img 
                      src={`https://api.paylibo.com/paylibo/generator/czech/image?accountNumber=${quickActionInvoice.supplier.bankAccount.replace(/\s/g, '')}&bankCode=${quickActionInvoice.supplier.bankCode.replace(/\s/g, '')}&amount=${quickActionInvoice.totalAmount.toFixed(2)}&currency=CZK&vs=${quickActionInvoice.variableSymbol.replace(/\s/g, '')}&message=${encodeURIComponent('Faktura ' + quickActionInvoice.documentNumber)}&size=100`}
                      alt="QR Platba" 
                      referrerPolicy="no-referrer"
                      className="w-[85px] h-[85px]"
                    />
                  </div>
                </div>
              ) : (
                <div className="bg-amber-50 border border-amber-100/60 p-3 rounded-xl text-center text-xs text-amber-700 font-medium">
                  Cenová nabídka nemá platební QR kód. Slouží k odsouhlasení rozpočtu.
                </div>
              )}

              {/* 2. Interactive Quick Actions list */}
              <div className="space-y-1.5">
                <span className="text-[10px] font-mono font-bold tracking-wider uppercase text-slate-400 block mb-1">Dostupné akce</span>
                
                {/* Zobrazit & Stáhnout / Odeslat PDF (Open preview) */}
                <button
                  onClick={() => {
                    onSelectInvoice(quickActionInvoice);
                    setQuickActionInvoice(null);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-indigo-50 border border-indigo-100/50 hover:bg-indigo-100 text-indigo-700 text-xs font-bold transition cursor-pointer hover:shadow-2xs"
                >
                  <div className="flex items-center gap-2">
                    <Printer className="w-4 h-4 text-indigo-600" />
                    <span>Zobrazit, stáhnout nebo odeslat</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-indigo-500" />
                </button>

                {/* Edit document */}
                <button
                  onClick={() => {
                    onEditInvoice(quickActionInvoice);
                    setQuickActionInvoice(null);
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-slate-50 hover:bg-slate-100 border border-slate-200/60 text-slate-700 text-xs font-bold transition cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Edit className="w-4 h-4 text-slate-400" />
                    <span>Upravit doklad</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-slate-400" />
                </button>

                {/* Confirm Toggle Paid status */}
                {quickActionInvoice.type !== 'quote' && (
                  <button
                    onClick={() => {
                      togglePaidStatus(quickActionInvoice.id, quickActionInvoice.status);
                      setQuickActionInvoice(prev => prev ? {
                        ...prev,
                        status: prev.status === 'paid' ? 'sent' : 'paid'
                      } : null);
                    }}
                    className={`w-full flex items-center justify-between p-2.5 rounded-xl border text-xs font-bold transition cursor-pointer ${
                      quickActionInvoice.status === 'paid'
                        ? 'bg-emerald-50 border-emerald-100 text-emerald-700 hover:bg-emerald-100'
                        : 'bg-white border-slate-200 hover:bg-slate-50 text-slate-600'
                    }`}
                  >
                    <div className="flex items-center gap-2">
                      <CheckCircle className={`w-4 h-4 ${quickActionInvoice.status === 'paid' ? 'text-emerald-600' : 'text-slate-400'}`} />
                      <span>{quickActionInvoice.status === 'paid' ? 'Označeno jako Uhrazené' : 'Označit jako zaplacené'}</span>
                    </div>
                    <ChevronRight className="w-4 h-4 text-slate-400" />
                  </button>
                )}

                {/* Delete button */}
                <button
                  onClick={async () => {
                    const number = quickActionInvoice.documentNumber;
                    if (confirm(`Opravdu si přejete smazat doklad č. ${number}? Akce je nevratná.`)) {
                      try {
                        await deleteDoc(doc(db, 'invoices', quickActionInvoice.id));
                        setQuickActionInvoice(null);
                      } catch (err) {
                        console.error(err);
                        alert('Smazání se nezdařilo.');
                      }
                    }
                  }}
                  className="w-full flex items-center justify-between p-2.5 rounded-xl bg-red-50 hover:bg-red-100 border border-red-100 text-red-650 text-xs font-bold transition cursor-pointer"
                >
                  <div className="flex items-center gap-2">
                    <Trash2 className="w-4 h-4 text-red-500" />
                    <span>Odstranit / Smazat doklad</span>
                  </div>
                  <ChevronRight className="w-4 h-4 text-red-400" />
                </button>
              </div>

            </div>

            {/* Footer of popup */}
            <div className="px-5 py-3 border-t border-slate-100 flex justify-end bg-slate-50/50">
              <button
                onClick={() => setQuickActionInvoice(null)}
                className="px-4 py-1.5 bg-slate-200 hover:bg-slate-300 transition text-slate-700 rounded-xl text-xs font-bold cursor-pointer"
              >
                Zavřít
              </button>
            </div>

          </div>
        </div>
      )}

    </div>
  );
}
