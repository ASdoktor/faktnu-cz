import React, { useState, useRef, useEffect } from 'react';
import { IInvoice, IUserProfile } from '../types';
import { 
  X, Download, Mail, ArrowLeft, Printer, Loader2, Sparkles, Building, Settings, Check, Clock, AlertTriangle, ExternalLink
} from 'lucide-react';
import jsPDF from 'jspdf';
import html2canvas from 'html2canvas-pro';

interface InvoicePreviewProps {
  invoice: IInvoice;
  supplierProfile: IUserProfile;
  onClose: () => void;
}

export default function InvoicePreview({ invoice, supplierProfile, onClose }: InvoicePreviewProps) {
  const layout = supplierProfile.invoiceLayout || 'classic';
  const [downloading, setDownloading] = useState(false);
  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const [emailLoading, setEmailLoading] = useState(false);
  const [emailSuccess, setEmailSuccess] = useState(false);

  const [isOnline, setIsOnline] = useState(navigator.onLine);
  useEffect(() => {
    const handleOnline = () => setIsOnline(true);
    const handleOffline = () => setIsOnline(false);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);
  const [sandboxMailUrl, setSandboxMailUrl] = useState<string | null>(null);

  // Email form fields state
  const [recipient, setRecipient] = useState(invoice.customer.email || '');
  const [subject, setSubject] = useState(`${invoice.type === 'quote' ? 'Cenová nabídka' : invoice.type === 'advance' ? 'Zálohová faktura' : 'Faktura'} č. ${invoice.documentNumber}`);
  const [bodyText, setBodyText] = useState(`Dobrý den,\n\nv příloze Vám zasíláme vystavený doklad č. ${invoice.documentNumber}.\n\nČástka k úhradě: ${invoice.totalAmount.toLocaleString('cs-CZ')} Kč\nSplatnost do: ${new Date(invoice.dueDate).toLocaleDateString('cs-CZ')}\n\nDěkujeme za spolupráci.\n\nS pozdravem,\n${invoice.supplier.companyName}`);

  const invoiceRef = useRef<HTMLDivElement>(null);

  // Translate types
  const getDocTypeTitle = (type: string) => {
    switch (type) {
      case 'advance': return 'ZÁLOHOVÁ FAKTURA';
      case 'quote': return 'CENOVÁ NABÍDKA';
      default: return 'FAKTURA - DAŇOVÝ DOKLAD';
    }
  };

  // Build Standard QR Platba CZ url based on Paylibo API guidelines from user request
  const getCzechQrUrl = () => {
    const account = invoice.supplier.bankAccount.replace(/\s/g, '');
    const bank = invoice.supplier.bankCode.replace(/\s/g, '');
    const vs = invoice.variableSymbol.replace(/\s/g, '');
    const amount = invoice.totalAmount.toFixed(2);
    const msg = encodeURIComponent(`Faktura ${invoice.documentNumber}`);

    const payliboUrl = `https://api.paylibo.com/paylibo/generator/czech/image?accountNumber=${account}&bankCode=${bank}&amount=${amount}&currency=CZK&vs=${vs}&message=${msg}&size=180`;
    return `/api/proxy-image?url=${encodeURIComponent(payliboUrl)}`;
  };

  // Convert remote http logo URLs to proxied identical-origin targets to prevent canvas taints
  const getSafeLogoUrl = (url?: string) => {
    if (!url) return '';
    if (url.startsWith('data:')) return url; // inline base64 asset is safe
    return `/api/proxy-image?url=${encodeURIComponent(url)}`;
  };

  // Generate PDF client-side (Vector-to-Image high contrast PDF)
  const generateAndDownloadPdf = async (toBase64 = false): Promise<string | null> => {
    const element = invoiceRef.current;
    if (!element) return null;

    setDownloading(true);
    try {
      // Temporary styling changes to ensure perfect white print context for capture
      const originalBg = element.style.background;
      const originalWidth = element.style.width;
      const originalMaxWidth = element.style.maxWidth;

      // Force pristine white bg and a fixed 800px table width to prevent mobile responsive wrapping or clipping
      element.style.background = '#ffffff';
      element.style.width = '800px';
      element.style.maxWidth = '800px';
      
      const parent = element.parentElement;
      const originalParentScroll = parent ? parent.scrollTop : 0;
      if (parent) {
        parent.scrollTop = 0; // Scroll container to prevent HTML2Canvas cropping
      }

      const opt = {
        scale: 2, // 2x resolution for printing sharp letters
        useCORS: true,
        scrollY: 0,
        scrollX: 0,
        windowWidth: 1024 // Force 1024px viewport rendering state so layout matches desktop preview perfectly
      };

      const canvas = await html2canvas(element, opt);

      // Restore original dimensions and background immediately
      element.style.background = originalBg;
      element.style.width = originalWidth;
      element.style.maxWidth = originalMaxWidth;
      
      if (parent) {
        parent.scrollTop = originalParentScroll; // Restore original scroll pos
      }

      const imgData = canvas.toDataURL('image/jpeg', 0.95);
      
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 210; // A4 dimensions in mm
      const pageHeight = 297;
      const imgHeight = (canvas.height * imgWidth) / canvas.width;
      
      let heightLeft = imgHeight;
      let position = 0;

      // Render the image onto the first page
      pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      // Multi-page page splits: Shift vertical offset upwards on subsequent pages
      while (heightLeft > 0) {
        position = heightLeft - imgHeight; // Creates negative offset corresponding to the next page slice
        pdf.addPage();
        pdf.addImage(imgData, 'JPEG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }

      if (toBase64) {
        // Output as Data URI, then strip metadata prefix
        const dataUriStr = pdf.output('datauristring');
        return dataUriStr;
      } else {
        pdf.save(`Doklad_${invoice.documentNumber}.pdf`);
        return null;
      }
    } catch (e) {
      console.error('PDF Generation Failed:', e);
      alert('Nepodařilo se vygenerovat PDF. Zkontrolujte kompatibilitu Vašeho zařízení.');
      return null;
    } finally {
      setDownloading(false);
    }
  };

  // Handle server-side email dispatch
  const handleSendEmail = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!recipient.trim()) {
      alert("Zadejte prosím e-mailovou adresu příjemce.");
      return;
    }

    setEmailLoading(true);
    setSandboxMailUrl(null);
    try {
      // 1. Generate PDF as Base64 string from canvas
      const pdfBase64 = await generateAndDownloadPdf(true);
      if (!pdfBase64) throw new Error("Chyba při přípravě PDF dokumentu.");

      // 2. Setup SMTP parameters block (if loaded in user profile)
      const smtpSettings = supplierProfile.smtpHost ? {
        smtpHost: supplierProfile.smtpHost,
        smtpPort: supplierProfile.smtpPort,
        smtpUser: supplierProfile.smtpUser,
        smtpPass: supplierProfile.smtpPass,
        emailSenderName: supplierProfile.emailSenderName
      } : null;

      // 3. Post payload to our Express server
      const res = await fetch('/api/send-email', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          recipientEmail: recipient.trim(),
          subject,
          bodyText,
          pdfBase64,
          documentNumber: invoice.documentNumber,
          smtpSettings
        })
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Server odmítl odeslat e-mail.');
      }

      setEmailSuccess(true);
      if (data.isSandbox && data.previewUrl) {
        setSandboxMailUrl(data.previewUrl);
      }
    } catch (err: any) {
      console.error(err);
      alert(err.message || "Nepodařilo se odeslat e-mail přes SMTP server.");
    } finally {
      setEmailLoading(false);
    }
  };

  // Direct mobil email client fallback (mailto:)
  const triggerMailtoFallback = () => {
    const mailSubject = encodeURIComponent(subject);
    const mailBody = encodeURIComponent(bodyText + `\n\n(Přílohu PDF naleznete ke stažení ve Vašem uživatelském rozhraní pod číslem dokladu ${invoice.documentNumber})`);
    
    window.location.href = `mailto:${recipient}?subject=${mailSubject}&body=${mailBody}`;
  };

  const hasDph = invoice.items.some(item => (item.vatRate || 0) > 0);

  return (
    <div className="fixed inset-0 bg-slate-950/90 overflow-y-auto z-50 flex flex-col md:p-6 p-0 print:absolute print:inset-0 print:bg-white print:p-0 print:overflow-visible print:z-50">
      
      {/* PREVIEW CONTAINER HEADER */}
      <div className="w-full max-w-4xl mx-auto flex items-center justify-between p-4 bg-slate-900 md:rounded-t-2xl border-b border-slate-800 text-slate-100 shrink-0 sticky top-0 z-10 select-none no-print">
        <div className="flex items-center gap-3">
          <button
            onClick={onClose}
            className="p-2 hover:bg-slate-800 rounded-xl transition text-slate-400 hover:text-slate-100 cursor-pointer touch-manipulation"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h3 className="font-bold text-sm leading-tight md:text-base">{invoice.documentNumber}</h3>
            <p className="text-[10px] text-slate-400 font-mono">{invoice.customer.companyName}</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => window.print()}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition cursor-pointer touch-manipulation"
            title="Tisk"
          >
            <Printer className="w-4.5 h-4.5" />
          </button>

          <button
            onClick={() => generateAndDownloadPdf(false)}
            disabled={downloading}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl transition cursor-pointer disabled:opacity-50 touch-manipulation"
            title="Stáhnout PDF"
          >
            {downloading ? (
              <Loader2 className="w-4.5 h-4.5 animate-spin text-blue-400" />
            ) : (
              <Download className="w-4.5 h-4.5" />
            )}
          </button>

          <button
            onClick={() => {
              if (!isOnline) {
                alert("Odesílání e-mailů vyžaduje aktivní připojení k internetu.");
                return;
              }
              setEmailModalOpen(true);
            }}
            className={`p-2.5 rounded-xl transition font-semibold flex items-center gap-1.5 px-3 ${
              isOnline 
                ? 'bg-blue-600 hover:bg-blue-500 text-white cursor-pointer' 
                : 'bg-slate-800 text-slate-500 cursor-not-allowed opacity-60'
            }`}
            title={isOnline ? "Odeslat doklad e-mailem" : "Vyžaduje připojení k internetu (Offline)"}
          >
            <Mail className="w-4 h-4" />
            <span className="hidden sm:inline text-xs">
              {isOnline ? 'Odeslat' : 'Vyžaduje online'}
            </span>
          </button>
        </div>
      </div>

      {/* PDF DOCUMENT WRAPPER (White background inside render element) */}
      <div className="flex-1 overflow-y-auto py-6 bg-slate-950/40 md:p-6 p-4 print:p-0 print:bg-white print:overflow-visible">
        
        <div 
          id="invoice-pdf-container"
          ref={invoiceRef}
          className="w-full max-w-4xl mx-auto bg-white text-slate-900 p-8 sm:p-12 shadow-2xl rounded-2xl border border-slate-200/50 print-page overflow-x-hidden print:p-0 print:border-none print:shadow-none print:rounded-none"
          style={{ fontFamily: '"Inter", sans-serif' }}
        >
          
          {/* LAYOUT 1: CLASSIC (Standard simple layout) */}
          {layout === 'classic' && (
            <div className="space-y-8">
              {/* Header section */}
              <div className="flex justify-between items-start gap-4">
                <div className="space-y-2">
                  {invoice.supplier.logoUrl ? (
                    <img src={getSafeLogoUrl(invoice.supplier.logoUrl)} alt="Logo" className="max-h-16 max-w-[200px] object-contain mb-2" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="text-xl font-bold tracking-tight text-slate-800 font-display flex items-center gap-2 flex-row">
                      <div className="w-8 h-8 rounded bg-blue-600 flex items-center justify-center text-white text-xs">F</div>
                      <span>{invoice.supplier.companyName}</span>
                    </div>
                  )}
                  <h1 className="text-xl font-bold tracking-tight text-slate-900 uppercase font-display" style={{ color: supplierProfile.brandColor }}>
                    {getDocTypeTitle(invoice.type)}
                  </h1>
                </div>

                <div className="text-right space-y-1 text-xs">
                  <p className="font-semibold text-slate-500">Číslo dokladu</p>
                  <p className="text-lg font-bold text-slate-950 font-mono">{invoice.documentNumber}</p>
                  <p className="text-slate-400 pt-1">VS: <span className="font-semibold font-mono">{invoice.variableSymbol}</span></p>
                </div>
              </div>

              {/* Supplier & Customer Info Grid */}
              <div className="grid grid-cols-2 gap-8 border-t border-b border-slate-200 py-6 text-xs">
                {/* Supplier column */}
                <div className="space-y-3 pr-2">
                  <h4 className="font-bold text-slate-400 uppercase tracking-wider text-[10px]">Dodavatel</h4>
                  <div className="space-y-1">
                    <p className="font-bold text-slate-950 text-sm">{invoice.supplier.companyName}</p>
                    <p className="text-slate-600">{invoice.supplier.street}</p>
                    <p className="text-slate-600">{invoice.supplier.zip} {invoice.supplier.city}</p>
                    {invoice.supplier.phone && <p className="text-slate-500 font-mono text-[11px]">Tel: {invoice.supplier.phone}</p>}
                    <div className="pt-2 grid grid-cols-2 gap-x-2 gap-y-0.5 text-slate-500">
                      <span>IČO:</span> <span className="font-semibold text-slate-800 font-mono">{invoice.supplier.ico}</span>
                      {invoice.supplier.dic && (
                        <>
                          <span>DIČ:</span> <span className="font-semibold text-slate-800 font-mono">{invoice.supplier.dic}</span>
                        </>
                      )}
                    </div>
                  </div>
                </div>

                {/* Customer column */}
                <div className="space-y-3 pl-2 border-l border-slate-200 col-span-1">
                  <h4 className="font-bold text-slate-400 uppercase tracking-wider text-[10px]">Odběratel</h4>
                  <div className="space-y-1">
                    <p className="font-bold text-slate-950 text-sm">{invoice.customer.companyName}</p>
                    <p className="text-slate-600">{invoice.customer.street}</p>
                    <p className="text-slate-600">{invoice.customer.zip} {invoice.customer.city}</p>
                    {invoice.customer.phone && <p className="text-slate-500 font-mono text-[11px]">Tel: {invoice.customer.phone}</p>}
                    {(invoice.customer.ico || invoice.customer.dic) && (
                      <div className="pt-2 grid grid-cols-2 gap-x-2 gap-y-0.5 text-slate-500">
                        {invoice.customer.ico && (
                          <>
                            <span>IČO:</span> <span className="font-semibold text-slate-800 font-mono">{invoice.customer.ico}</span>
                          </>
                        )}
                        {invoice.customer.dic && (
                          <>
                            <span>DIČ:</span> <span className="font-semibold text-slate-800 font-mono">{invoice.customer.dic}</span>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              {/* Payment Details Block */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-xs bg-slate-50 border border-slate-200/60 p-4 rounded-xl">
                <div>
                  <p className="text-slate-400 text-[10px] uppercase">Bankovní účet</p>
                  <p className="font-bold text-slate-900 font-mono">{invoice.supplier.bankAccount}/{invoice.supplier.bankCode}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-[10px] uppercase">
                    {invoice.type === 'quote' ? 'Platnost nabídky' : 'Splatnost (Due Date)'}
                  </p>
                  <p className="font-bold text-red-650">
                    {new Date(invoice.type === 'quote' && invoice.validUntil ? invoice.validUntil : invoice.dueDate).toLocaleDateString('cs-CZ')}
                  </p>
                </div>
                <div>
                  <p className="text-slate-400 text-[10px] uppercase">Datum vystavení</p>
                  <p className="font-semibold text-slate-800">{new Date(invoice.issuedDate).toLocaleDateString('cs-CZ')}</p>
                </div>
                <div>
                  <p className="text-slate-400 text-[10px] uppercase">Forma úhrady</p>
                  <p className="font-semibold text-slate-800 font-mono">Převodem / QR kódem</p>
                </div>
              </div>
            </div>
          )}

          {/* LAYOUT 2: MODERN (Sleek minimalist layout with background highlights) */}
          {layout === 'modern' && (
            <div className="space-y-8">
              <div className="flex flex-col sm:flex-row justify-between items-start gap-4 pb-6 border-b-2 border-slate-100">
                <div className="space-y-2">
                  {invoice.supplier.logoUrl ? (
                    <img src={getSafeLogoUrl(invoice.supplier.logoUrl)} alt="Logo" className="max-h-16 max-w-[200px] object-contain mb-2" referrerPolicy="no-referrer" />
                  ) : (
                    <div className="text-2xl font-black tracking-tight font-display text-slate-900">
                      {invoice.supplier.companyName}
                    </div>
                  )}
                  <p className="text-xs text-slate-500">{invoice.supplier.street}, {invoice.supplier.zip} {invoice.supplier.city}</p>
                  {invoice.supplier.phone && <p className="text-[11px] text-slate-500 font-mono">Tel: {invoice.supplier.phone}</p>}
                </div>

                <div className="text-left sm:text-right p-4 rounded-xl bg-slate-50 border border-slate-100 min-w-[220px]">
                  <span className="text-[10px] font-bold text-white px-2.5 py-0.5 rounded-full inline-block uppercase tracking-wider mb-1" style={{ backgroundColor: supplierProfile.brandColor || '#2563eb' }}>
                    {invoice.type === 'quote' ? 'Cenová nabídka' : invoice.type === 'advance' ? 'Zálohová platba' : 'Faktura'}
                  </span>
                  <p className="text-lg font-bold text-slate-950 font-mono">{invoice.documentNumber}</p>
                  <p className="text-[11px] text-slate-500 font-mono">VS: {invoice.variableSymbol}</p>
                </div>
              </div>

              {/* Two columns details row */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs bg-slate-50/40 p-5 rounded-2xl border border-slate-100">
                <div className="space-y-1">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2">Dodavatel</p>
                  <p className="font-bold text-slate-950 text-sm">{invoice.supplier.companyName}</p>
                  <p className="text-slate-600">IČO: {invoice.supplier.ico}</p>
                  {invoice.supplier.dic && <p className="text-slate-600">DIČ: {invoice.supplier.dic}</p>}
                  <p className="text-slate-600 pt-2 font-semibold">BÚ: {invoice.supplier.bankAccount}/{invoice.supplier.bankCode}</p>
                </div>

                <div className="space-y-1 sm:border-l border-slate-100 sm:pl-6">
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-wider mb-2">Odběratel</p>
                  <p className="font-bold text-slate-950 text-sm">{invoice.customer.companyName}</p>
                  <p className="text-slate-500">{invoice.customer.street}</p>
                  <p className="text-slate-500">{invoice.customer.zip} {invoice.customer.city}</p>
                  {invoice.customer.phone && <p className="text-slate-400 font-mono text-[11px] pt-1">Tel: {invoice.customer.phone}</p>}
                  {invoice.customer.ico && <p className="text-slate-500 pt-1 font-mono">IČO: {invoice.customer.ico}</p>}
                </div>
              </div>

              {/* Dynamic dates line */}
              <div className="flex flex-wrap items-center gap-6 justify-between bg-slate-950/5 text-slate-800 text-xs p-3.5 rounded-xl border border-slate-200/50">
                <span>Vystaveno: <strong>{new Date(invoice.issuedDate).toLocaleDateString('cs-CZ')}</strong></span>
                <span className="text-red-700 font-semibold">
                  {invoice.type === 'quote' ? 'Platnost nabídky do: ' : 'Splatnost: '}
                  <strong>{new Date(invoice.type === 'quote' && invoice.validUntil ? invoice.validUntil : invoice.dueDate).toLocaleDateString('cs-CZ')}</strong>
                </span>
                <span>Způsob úhrady: <strong>Bankovní převod</strong></span>
              </div>
            </div>
          )}

          {/* LAYOUT 3: MINIMAL (Ultra clean simple minimal layout) */}
          {layout === 'minimal' && (
            <div className="space-y-8">
              <div className="border-b border-slate-200 pb-5">
                <h1 className="text-4xl font-extrabold tracking-tight text-slate-950 uppercase font-display" style={{ color: supplierProfile.brandColor }}>
                  {invoice.type === 'quote' ? 'Nabídka' : invoice.type === 'advance' ? 'Záloha' : 'Faktura'}
                </h1>
                <p className="text-sm font-semibold font-mono text-slate-400 mt-1">č. {invoice.documentNumber} / VS {invoice.variableSymbol}</p>
              </div>

              <div className="grid grid-cols-2 gap-4 text-xs">
                <div>
                  <p className="text-slate-400 font-mono text-[9px] uppercase tracking-wider mb-1">Od</p>
                  <p className="font-bold text-slate-950">{invoice.supplier.companyName}</p>
                  <p className="text-slate-500">{invoice.supplier.street}, {invoice.supplier.city}</p>
                  {invoice.supplier.phone && <p className="text-slate-400 font-mono text-[10px]">Tel: {invoice.supplier.phone}</p>}
                  <p className="text-slate-500 font-mono">IČ {invoice.supplier.ico}</p>
                </div>

                <div>
                  <p className="text-slate-400 font-mono text-[9px] uppercase tracking-wider mb-1">Pro</p>
                  <p className="font-bold text-slate-950">{invoice.customer.companyName}</p>
                  <p className="text-slate-500">{invoice.customer.street}, {invoice.customer.city}</p>
                  {invoice.customer.phone && <p className="text-slate-400 font-mono text-[10px]">Tel: {invoice.customer.phone}</p>}
                  {invoice.customer.ico && <p className="text-slate-500 font-mono">IČ {invoice.customer.ico}</p>}
                </div>
              </div>

              <div className="pt-4 border-t border-slate-100 flex gap-12 text-[11px] text-slate-500">
                <div>
                  <p className="text-[9px] text-slate-400">Platba na účet</p>
                  <p className="font-bold text-slate-900 font-mono">{invoice.supplier.bankAccount}/{invoice.supplier.bankCode}</p>
                </div>
                <div>
                  <p className="text-[9px] text-slate-400">Vystaveno</p>
                  <p className="font-semibold text-slate-900">{new Date(invoice.issuedDate).toLocaleDateString('cs-CZ')}</p>
                </div>
                <div>
                  <p className="text-[9px] text-slate-400">
                    {invoice.type === 'quote' ? 'Platnost nabídky' : 'Termín splatnosti'}
                  </p>
                  <p className="font-semibold text-red-600 font-mono">
                    {new Date(invoice.type === 'quote' && invoice.validUntil ? invoice.validUntil : invoice.dueDate).toLocaleDateString('cs-CZ')}
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* CENTRAL ITEMS GRID (Common rendering to all layout designs for structure safety) */}
          <div className="mt-10 overflow-x-hidden text-xs">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-200 text-slate-400 uppercase text-[9px] font-bold tracking-wider">
                  <th className="py-3 px-1">Popis položky</th>
                  <th className="py-3 px-2 text-right">Množství</th>
                  <th className="py-3 px-2 text-right">Cena/Jedn.</th>
                  {hasDph && <th className="py-3 px-2 text-right">DPH</th>}
                  <th className="py-3 px-1 text-right">Celkem</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {invoice.items.map((item) => {
                  const itemRaw = item.count * item.pricePerUnit;
                  const itemTax = itemRaw * (item.vatRate / 100);
                  const itemTot = itemRaw + (hasDph ? itemTax : 0);

                  return (
                    <tr key={item.id} className="text-slate-800 align-top">
                      <td className="py-3.5 px-1 font-medium text-slate-950 pr-4 break-words max-w-[280px]">
                        {item.name}
                      </td>
                      <td className="py-3.5 px-2 text-right font-mono text-slate-600 whitespace-nowrap">
                        {item.count} {item.unit}
                      </td>
                      <td className="py-3.5 px-2 text-right font-mono text-slate-600 whitespace-nowrap">
                        {item.pricePerUnit.toLocaleString('cs-CZ')} Kč
                      </td>
                      {hasDph && (
                        <td className="py-3.5 px-2 text-right text-slate-500 whitespace-nowrap">
                          {item.vatRate}%
                        </td>
                      )}
                      <td className="py-3.5 px-1 text-right font-bold text-slate-950 font-mono whitespace-nowrap">
                        {itemTot.toLocaleString('cs-CZ')} Kč
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* DPH SUMMARY TABLE - Only display if DPH has real positive rates */}
          {hasDph && (
            <div className="mt-6 flex justify-end text-xs">
              <div className="w-64 border border-slate-150 rounded-xl p-3 bg-slate-50/40 space-y-1.5">
                <p className="text-[9px] text-slate-400 uppercase font-mono border-b border-slate-200 pb-1">Sazby DPH rekapitulace</p>
                {Array.from(new Set(invoice.items.map(it => it.vatRate))).map((rate) => {
                  const filtered = invoice.items.filter(it => it.vatRate === rate);
                  const sub = filtered.reduce((acc, current) => acc + (current.count * current.pricePerUnit), 0);
                  const taxValue = sub * (rate / 100);

                  return (
                    <div key={rate} className="flex justify-between items-center text-[11px] font-mono text-slate-600">
                      <span>DPH {rate}%</span>
                      <span>Základ: {Math.round(sub).toLocaleString('cs-CZ')} Kč</span>
                      <span>DPH: {Math.round(taxValue).toLocaleString('cs-CZ')} Kč</span>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* FINAL TOTAL AMOUNT ZONE WITH INTEGRATED QR CODE BILLING */}
          <div className="mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-6">

            {/* Left side standard QR Czech generator code API */}
            {invoice.supplier.bankAccount && invoice.supplier.bankCode && (
              <div className="flex flex-col items-center sm:items-start text-center sm:text-left gap-1.5">
                <p className="text-[10px] text-slate-400 uppercase font-bold tracking-wider">Okamžitá platba přes QR kód</p>
                <div className="relative w-36 h-36 bg-white p-2 border border-slate-200 rounded-xl overflow-hidden shadow-md flex items-center justify-center">
                  <img 
                    src={getCzechQrUrl()} 
                    alt="Standardní QR Platba" 
                    className="w-full h-full object-contain"
                    referrerPolicy="no-referrer"
                  />
                </div>
                <p className="text-[9px] text-slate-500 max-w-[200px] leading-snug">
                  Naskenujte v jakékoliv české bankovní aplikaci v telefonu.
                </p>
              </div>
            )}

            {/* Right side overall totals */}
            <div className="text-right flex flex-col items-center sm:items-end justify-center">
              <span className="text-slate-400 text-[10px] uppercase font-bold tracking-wider">Cena úhrady celkem</span>
              <p className="text-3xl font-black text-slate-900 tracking-tight font-display pt-1">
                {invoice.totalAmount.toLocaleString('cs-CZ')} <span className="text-xl">Kč</span>
              </p>
              
              <div className="pt-4 space-y-0.5 text-slate-500 text-[10px] sm:text-right text-center">
                <p>Variabilní symbol: <span className="font-semibold text-slate-950 font-mono">{invoice.variableSymbol}</span></p>
                <p>Bankovní spojení: <span className="font-semibold text-slate-950 font-mono">{invoice.supplier.bankAccount}/{invoice.supplier.bankCode}</span></p>
              </div>
            </div>

          </div>

          {/* FOOTER FOOTNOTE */}
          {invoice.note && (
            <div className="mt-12 text-center text-[11px] text-slate-400 italic font-medium pt-4 border-t border-slate-150">
              {invoice.note}
            </div>
          )}

        </div>
      </div>

      {/* EMAIL MODAL WINDOW */}
      {emailModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 w-full max-w-md shadow-2xl space-y-4">
            
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <Mail className="w-5 h-5 text-blue-400" />
                <h3 className="font-bold text-slate-100 font-display text-sm md:text-base">Zaslat dokládek e-mailem</h3>
              </div>
              <button 
                onClick={() => setEmailModalOpen(false)}
                className="p-1.5 hover:bg-slate-800 text-slate-500 hover:text-slate-300 rounded-lg cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {emailSuccess ? (
              <div className="text-center py-6 space-y-4">
                <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 rounded-full flex items-center justify-center mx-auto text-xl font-bold">✓</div>
                <div>
                  <h4 className="font-bold text-slate-100 text-sm">Doklad byl úspěšně připraven k odeslání</h4>
                  <p className="text-xs text-slate-400 mt-1">E-mail byl bezpečně zapracován a odeslán přes SMTP server.</p>
                </div>
                
                {/* Sandbox test review link (Nodemailer ethereal account) */}
                {sandboxMailUrl && (
                  <div className="p-4 bg-amber-500/10 border border-amber-500/25 rounded-xl text-left space-y-2">
                    <p className="text-[11px] text-amber-400 font-medium">Je aktivní bezplatný sandbox testovací režim:</p>
                    <p className="text-xs text-slate-300 leading-relaxed">
                      Protože jste v profilu nenastavili vlastní odchozí SMTP server, e-mail jsme zachytili v testovacím portu. Kliknutím na tlačítko níže si můžete otevřít doručenou schránku a zkontrolovat vzhled zprávy a PDF přílohu!
                    </p>
                    <a 
                      href={sandboxMailUrl} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs font-bold text-blue-400 hover:text-blue-300 transition underline pt-1"
                    >
                      <span>Otevřít testovací schránku</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                  </div>
                )}

                <div className="pt-2">
                  <button
                    onClick={() => {
                      setEmailSuccess(false);
                      setSandboxMailUrl(null);
                      setEmailModalOpen(false);
                    }}
                    className="w-full py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Dokončit
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSendEmail} className="space-y-3.5 text-xs text-slate-300">
                <div className="space-y-1">
                  <label className="text-slate-400 block font-medium">E-mail příjemce (klient)</label>
                  <input
                    type="email"
                    required
                    value={recipient}
                    onChange={(e) => setRecipient(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none"
                    placeholder="klient@email.cz"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 block font-medium">Předmět e-mailu</label>
                  <input
                    type="text"
                    required
                    value={subject}
                    onChange={(e) => setSubject(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-slate-400 block font-medium">Průvodní text e-mailu</label>
                  <textarea
                    rows={5}
                    required
                    value={bodyText}
                    onChange={(e) => setBodyText(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-slate-100 focus:outline-none resize-none"
                  />
                </div>

                <div className="pt-2 flex gap-2">
                  <button
                    type="submit"
                    disabled={emailLoading}
                    className="flex-1 inline-flex items-center justify-center gap-1.5 py-2.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold cursor-pointer disabled:opacity-50"
                  >
                    {emailLoading ? (
                      <Loader2 className="w-4 h-4 animate-spin" />
                    ) : (
                      <Mail className="w-4 h-4" />
                    )}
                    <span>Zaslat přes SMTP server</span>
                  </button>
                  
                  <button
                    type="button"
                    onClick={triggerMailtoFallback}
                    className="inline-flex items-center justify-center gap-1.5 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-xs font-bold cursor-pointer"
                    title="Otevře Váš výchozí e-mailový program v telefonu"
                  >
                    <span>Otevřít v mobilu (mailto:)</span>
                  </button>
                </div>

                {/* Mailto Attachments warning notice */}
                <div className="p-3 bg-slate-950/50 rounded-xl text-slate-400 leading-normal font-sans">
                  <p className="font-bold text-amber-500 flex items-center gap-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-amber-500 shrink-0" />
                    <span>Upozornění pro mobilní odesílání</span>
                  </p>
                  <p className="mt-1 leading-normal text-[10.5px]">
                    Standardní mobilní protokol pro poštu (mailto:) nepovoluje připojování fyzických souborů z prohlížeče z bezpečnostních důvodů. Příjemce v těle mailu obdrží text s údaji. Přejete-li si, aby e-mail nesl <strong>skutečnou PDF fakturu v příloze</strong>, odešlete jej kliknutím na tlačítko <strong>„Zaslat přes SMTP server“</strong> (nastavte si SMTP v sekci Profil pro vlastní adresu).
                  </p>
                </div>
              </form>
            )}

          </div>
        </div>
      )}

    </div>
  );
}
