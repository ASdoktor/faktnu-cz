import React, { useState, useEffect } from 'react';
import { db, auth } from '../lib/firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { IInvoice, ICashFlowRecord } from '../types';
import { 
  TrendingUp, Calendar, CheckCircle, AlertTriangle, Users, DollarSign, Wallet, FileText, ArrowRight, BarChart2, ArrowUpRight, ArrowDownLeft, Loader2
} from 'lucide-react';

interface StatsViewProps {
  invoices: IInvoice[];
}

type Period = '30days' | '3months' | 'thisyear' | 'all';

export default function StatsView({ invoices }: StatsViewProps) {
  const [selectedPeriod, setSelectedPeriod] = useState<Period>('thisyear');
  const [selectedCustomerName, setSelectedCustomerName] = useState<string>('all');
  const [cashflow, setCashflow] = useState<ICashFlowRecord[]>([]);
  const [loadingCf, setLoadingCf] = useState(true);

  // Dynamic set of customer company names for filtering
  const uniqueCustomerNames = Array.from(
    new Set(invoices.map(inv => inv.customer.companyName || 'Neznámý odběratel').filter(Boolean))
  ).sort();

  // Load cashflow records reactively from Firestore
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const q = query(
      collection(db, 'cashflow'),
      where('ownerId', '==', user.uid)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: ICashFlowRecord[] = [];
      snapshot.forEach((doc) => {
        list.push(doc.data() as ICashFlowRecord);
      });
      setCashflow(list);
      setLoadingCf(false);
    }, (error) => {
      console.warn("StatsView subscription error on cashflow collection:", error);
      setLoadingCf(false);
    });

    return () => unsubscribe();
  }, []);

  const getFilteredInvoices = () => {
    const today = new Date();
    return invoices.filter(inv => {
      if (inv.type === 'quote') return false; // exclude quotes from revenue calculations
      
      // Filter by customer first
      if (selectedCustomerName !== 'all') {
        const cName = inv.customer.companyName || 'Neznámý odběratel';
        if (cName !== selectedCustomerName) return false;
      }

      const invDate = new Date(inv.issuedDate);
      if (isNaN(invDate.getTime())) return true;

      switch (selectedPeriod) {
        case '30days': {
          const diff = (today.getTime() - invDate.getTime()) / (1000 * 60 * 60 * 24);
          return diff <= 30;
        }
        case '3months': {
          const diff = (today.getTime() - invDate.getTime()) / (1000 * 60 * 60 * 24);
          return diff <= 90;
        }
        case 'thisyear': {
          return invDate.getFullYear() === today.getFullYear();
        }
        default:
          return true; // 'all'
      }
    });
  };

  const getFilteredCashflow = () => {
    const today = new Date();
    return cashflow.filter(cf => {
      const cfDate = new Date(cf.date);
      if (isNaN(cfDate.getTime())) return true;

      switch (selectedPeriod) {
        case '30days': {
          const diff = (today.getTime() - cfDate.getTime()) / (1000 * 60 * 60 * 24);
          return diff <= 30;
        }
        case '3months': {
          const diff = (today.getTime() - cfDate.getTime()) / (1000 * 60 * 60 * 24);
          return diff <= 90;
        }
        case 'thisyear': {
          return cfDate.getFullYear() === today.getFullYear();
        }
        default:
          return true; // 'all'
      }
    });
  };

  const filteredInvoices = getFilteredInvoices();
  const filteredCashflow = getFilteredCashflow();

  // 1. Invoice tracking metrics calculations
  const totalInvoiced = filteredInvoices.reduce((acc, current) => acc + (current.totalAmount || 0), 0);
  const totalPaidInvoices = filteredInvoices
    .filter(inv => inv.status === 'paid')
    .reduce((acc, current) => acc + (current.totalAmount || 0), 0);
  const totalOutstandingInvoices = filteredInvoices
    .filter(inv => inv.status !== 'paid' && inv.status !== 'draft')
    .reduce((acc, current) => acc + (current.totalAmount || 0), 0);

  const totalPaidCount = filteredInvoices.filter(inv => inv.status === 'paid').length;
  const totalUnpaidCount = filteredInvoices.filter(inv => inv.status !== 'paid' && inv.status !== 'draft').length;

  const paidRatio = totalInvoiced > 0 ? (totalPaidInvoices / totalInvoiced) * 100 : 0;
  const unpaidRatio = totalInvoiced > 0 ? (totalOutstandingInvoices / totalInvoiced) * 100 : 0;

  // 2. Cashflow metrics aggregate
  const manualIncomes = filteredCashflow
    .filter(cf => cf.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpenses = filteredCashflow
    .filter(cf => cf.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);

  // Total Realized Incomes = Paid Invoices + Manual Incomes (manual is filtered out if customer filter chosen)
  const totalRealIncomes = totalPaidInvoices + (selectedCustomerName === 'all' ? manualIncomes : 0);
  const totalNetProfit = totalRealIncomes - (selectedCustomerName === 'all' ? totalExpenses : 0);

  // Aggregate monthly data for the bar chart
  const getMonthlyAggregate = () => {
    const monthsCZ = ['Led', 'Ún', 'Bře', 'Dub', 'Kvě', 'Čer', 'Čvc', 'Srp', 'Zář', 'Říj', 'Lis', 'Pro'];
    const monthlyData: Record<number, { invoiced: number; paid: number; name: string }> = {};

    // Initialize months
    for (let i = 0; i < 12; i++) {
      monthlyData[i] = { invoiced: 0, paid: 0, name: monthsCZ[i] };
    }

    filteredInvoices.forEach(inv => {
      const d = new Date(inv.issuedDate);
      if (!isNaN(d.getTime())) {
        const m = d.getMonth();
        monthlyData[m].invoiced += inv.totalAmount || 0;
        if (inv.status === 'paid') {
          monthlyData[m].paid += inv.totalAmount || 0;
        }
      }
    });

    return Object.values(monthlyData);
  };

  const monthlyAggregate = getMonthlyAggregate();
  const maxMonthlyAmount = Math.max(...monthlyAggregate.map(m => m.invoiced), 10000);

  // Top Customer breakdown
  const getTopCustomers = () => {
    const customerMap: Record<string, { companyName: string; count: number; total: number }> = {};
    filteredInvoices.forEach(inv => {
      const name = inv.customer.companyName || 'Neznámý odběratel';
      if (!customerMap[name]) {
        customerMap[name] = { companyName: name, count: 0, total: 0 };
      }
      customerMap[name].count += 1;
      customerMap[name].total += inv.totalAmount || 0;
    });

    return Object.values(customerMap)
      .sort((a, b) => b.total - a.total)
      .slice(0, 5);
  };

  const topCustomers = getTopCustomers();

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20 px-1">
      
      {/* Filters and banner */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 bg-white p-5 rounded-3xl border border-slate-200 shadow-3xs">
        <div>
          <h2 className="text-xl font-black font-display text-slate-950 flex items-center gap-2">
            <BarChart2 className="w-5 h-5 text-indigo-600" />
            <span>Statistiky a Přehledy</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">Kompletní finanční analýza, příjmy, provozní výdaje a ziskovost podnikání.</p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center w-full lg:w-auto">
          {/* Odběratel filter selector */}
          <div className="flex items-center gap-1.5 bg-slate-100 px-3 py-1.5 rounded-xl border border-slate-200 text-xs">
            <Users className="w-3.5 h-3.5 text-slate-400 shrink-0" />
            <select
              value={selectedCustomerName}
              onChange={(e) => setSelectedCustomerName(e.target.value)}
              className="bg-transparent border-none text-[11px] text-slate-700 font-bold focus:outline-none cursor-pointer w-full sm:w-auto"
            >
              <option value="all">Všichni odběratelé</option>
              {uniqueCustomerNames.map((name) => (
                <option key={name} value={name}>
                  {name}
                </option>
              ))}
            </select>
          </div>

          <div className="flex bg-slate-100 p-1 rounded-xl border border-slate-250 text-xs select-none justify-between">
            {[
              { id: '30days', label: '30 dní' },
              { id: '3months', label: '3 měsíce' },
              { id: 'thisyear', label: 'Tento rok' },
              { id: 'all', label: 'Vše' }
            ].map((btn) => (
              <button
                key={btn.id}
                onClick={() => setSelectedPeriod(btn.id as Period)}
                className={`px-3 py-1.5 rounded-lg font-bold transition cursor-pointer text-xs flex-1 sm:flex-initial ${
                  selectedPeriod === btn.id 
                    ? 'bg-white text-indigo-600 shadow-2xs' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                {btn.label}
              </button>
            ))}
          </div>
        </div>
      </div>

      {loadingCf && (
        <div className="bg-white rounded-3xl border border-slate-200 p-4 text-center text-xs text-slate-500 flex items-center justify-center gap-1.5 shadow-3xs">
          <Loader2 className="w-4 h-4 animate-spin text-indigo-600" />
          <span>Synchronizuji provozní příjmy a výdaje...</span>
        </div>
      )}

      {/* KPI SECTION 1: PROVOZNÍ CASHFLOW (Příjmy, Výdaje, Čistý Zisk) */}
      <div className="space-y-2.5">
        <h3 className="text-xs font-bold text-slate-400 font-mono uppercase tracking-wider pl-1">
          Hospodářský výsledek (Cashflow) v období
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {/* CF 1: Real Incomes */}
          <div className="bg-white rounded-3xl border border-slate-250 p-6 shadow-3xs flex flex-col justify-between hover:border-emerald-300 transition">
            <div>
              <div className="flex justify-between items-center text-slate-400">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider">Celkové reálné příjmy</span>
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
                  <ArrowUpRight className="w-4 h-4" />
                </div>
              </div>
              <p className="text-2xl font-extrabold font-mono text-emerald-600 mt-3">
                {Math.round(totalRealIncomes).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-400">Kč</span>
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11px] text-slate-500 flex items-center justify-between">
              <span>Z placených faktur:</span>
              <strong className="text-slate-800 font-mono font-bold">{Math.round(totalPaidInvoices).toLocaleString('cs-CZ')} Kč</strong>
            </div>
          </div>

          {/* CF 2: Expenses */}
          <div className="bg-white rounded-3xl border border-slate-250 p-6 shadow-3xs flex flex-col justify-between hover:border-rose-300 transition">
            <div>
              <div className="flex justify-between items-center text-slate-400">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider">Provozní výdaje a náklady</span>
                <div className="w-8 h-8 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-100">
                  <ArrowDownLeft className="w-4 h-4" />
                </div>
              </div>
              <p className="text-2xl font-extrabold font-mono text-rose-600 mt-3">
                {Math.round(totalExpenses).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-400">Kč</span>
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Zapsané náklady:</span>
              <strong className="text-slate-700 font-mono font-bold">{filteredCashflow.filter(cf => cf.type === 'expense').length} ks</strong>
            </div>
          </div>

          {/* CF 3: Net profit */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 shadow-md flex flex-col justify-between text-white">
            <div>
              <div className="flex justify-between items-center text-slate-400">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-slate-300">Čistý provozní zisk</span>
                <div className="w-8 h-8 rounded-xl bg-indigo-900/40 text-indigo-300 flex items-center justify-center border border-indigo-800/50">
                  <TrendingUp className="w-4 h-4" />
                </div>
              </div>
              <p className={`text-2xl font-black font-mono mt-3 ${totalNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {Math.round(totalNetProfit).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-300">Kč</span>
              </p>
            </div>
            <div className="mt-4 border-t border-slate-800 pt-3 text-[11px] text-slate-400 flex items-center justify-between">
              <span>Ziskovost provozu:</span>
              <strong className={`font-mono font-bold ${totalNetProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
                {totalRealIncomes > 0 ? `${Math.round((totalNetProfit / totalRealIncomes) * 100)} %` : 'N/A'}
              </strong>
            </div>
          </div>
        </div>
      </div>

      {/* KPI SECTION 2: STATISTIKY FAKTURACE */}
      <div className="space-y-2.5">
        <h3 className="text-xs font-bold text-slate-400 font-mono uppercase tracking-wider pl-1">
          Přehled vystavených faktur a splatnosti
        </h3>
        
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
          {/* KPI 1: Total billed */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-3xs flex flex-col justify-between hover:border-slate-300 transition">
            <div>
              <div className="flex justify-between items-center text-slate-400">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider">Celkově fakturováno</span>
                <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-600 flex items-center justify-center border border-indigo-100">
                  <FileText className="w-4 h-4" />
                </div>
              </div>
              <p className="text-2xl font-extrabold font-mono text-slate-900 mt-3">
                {Math.round(totalInvoiced).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-400">Kč</span>
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11px] text-slate-500 flex items-center gap-1">
              <span>Dokladů celkem: </span>
              <strong className="text-slate-800 font-mono font-bold">{filteredInvoices.length} ks</strong>
            </div>
          </div>

          {/* KPI 2: Paid */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-3xs flex flex-col justify-between hover:border-slate-300 transition">
            <div>
              <div className="flex justify-between items-center text-slate-400">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider">Uhrazené faktury</span>
                <div className="w-8 h-8 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
                  <CheckCircle className="w-4 h-4" />
                </div>
              </div>
              <p className="text-2xl font-extrabold font-mono text-emerald-600 mt-3">
                {Math.round(totalPaidInvoices).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-400">Kč</span>
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11px] text-slate-500 flex justify-between items-center">
              <span>Uhrazenost dokladů: {Math.round(paidRatio)}%</span>
              <span className="text-slate-800 font-mono font-bold text-xs">{totalPaidCount} ks</span>
            </div>
          </div>

          {/* KPI 3: Outstanding */}
          <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-3xs flex flex-col justify-between hover:border-slate-300 transition">
            <div>
              <div className="flex justify-between items-center text-slate-400">
                <span className="text-[10px] font-mono font-bold uppercase tracking-wider">Splatné pohledávky</span>
                <div className="w-8 h-8 rounded-xl bg-amber-50 text-amber-600 flex items-center justify-center border border-amber-100">
                  <AlertTriangle className="w-4 h-4" />
                </div>
              </div>
              <p className="text-2xl font-extrabold font-mono text-amber-600 mt-3">
                {Math.round(totalOutstandingInvoices).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-400">Kč</span>
              </p>
            </div>
            <div className="mt-4 border-t border-slate-100 pt-3 text-[11px] text-slate-500 flex justify-between items-center">
              <span>Dlužná rozpracovanost: {Math.round(unpaidRatio)}%</span>
              <span className="text-slate-800 font-mono font-bold text-xs">{totalUnpaidCount} ks</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Charts & Breakdown Section (Bento Grid layout) */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        
        {/* Monthly Trend Chart - md:col-span-8 */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-3xs md:col-span-8 space-y-4">
          <div className="flex justify-between items-center select-none">
            <h3 className="font-bold text-slate-900 font-display text-sm uppercase tracking-wide">Vývoj obratu za měsíce (Kč)</h3>
            <span className="text-[10px] font-mono font-medium text-slate-400">Graf vyfakturovaného příjmu</span>
          </div>

          {/* SVG Custom Responsive Bar Chart */}
          <div className="pt-4">
            <div className="w-full h-64 flex items-end justify-between gap-1 border-b border-l border-slate-150 pb-2 pl-2">
              {monthlyAggregate.map((month, index) => {
                const totalHeightPct = (month.invoiced / maxMonthlyAmount) * 100;
                const paidHeightPct = (month.paid / maxMonthlyAmount) * 100;

                return (
                  <div key={index} className="flex-1 flex flex-col items-center group relative h-full justify-end cursor-pointer">
                    
                    {/* Hover detail tooltip card */}
                    <div className="absolute bottom-full mb-2 bg-slate-950 text-white rounded-xl p-2.5 text-[10px] shadow-xl border border-slate-800 pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity z-10 w-32 font-medium">
                      <p className="font-bold border-b border-slate-800 pb-1 mb-1 text-indigo-400">{month.name}</p>
                      <p className="text-slate-300">Faktury: {Math.round(month.invoiced).toLocaleString('cs-CZ')} Kč</p>
                      <p className="text-emerald-400">Zaplaceno: {Math.round(month.paid).toLocaleString('cs-CZ')} Kč</p>
                    </div>

                    {/* Bar container */}
                    <div className="w-full sm:w-2/3 bg-slate-50 rounded-t-md relative overflow-hidden flex flex-col justify-end h-full max-h-[90%] transition-transform group-hover:scale-103 duration-200">
                      
                      {/* Billed volume bar */}
                      <div 
                        style={{ height: `${totalHeightPct}%` }}
                        className="bg-indigo-100 absolute bottom-0 left-0 right-0 rounded-t-sm z-0"
                      />

                      {/* Paid volume bar overlay */}
                      <div 
                        style={{ height: `${paidHeightPct}%` }}
                        className="bg-indigo-600 absolute bottom-0 left-0 right-0 rounded-t-sm z-1"
                      />
                      
                    </div>

                    {/* Label */}
                    <span className="text-[9px] font-mono font-bold text-slate-400 mt-2">{month.name}</span>
                  </div>
                );
              })}
            </div>
            
            {/* Chart Legends */}
            <div className="flex items-center gap-4 mt-4 text-[10px] text-slate-500 font-medium justify-center border-t border-slate-50 pt-3">
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-indigo-600"></span>
                <span>Uhrazené fakturované příjmy</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-3 h-3 rounded bg-indigo-150"></span>
                <span>Vystavené neuhrazené (koncepty, odeslané)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Top Clients list - md:col-span-4 */}
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-3xs md:col-span-4 space-y-4">
          <div className="flex justify-between items-center select-none border-b border-slate-100 pb-3">
            <h3 className="font-bold text-slate-900 font-display text-sm uppercase tracking-wide">Největší odběratelé</h3>
            <Users className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3.5 pt-1">
            {topCustomers.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-8 italic font-sans">
                Zatím nezaznamenány žádné příjmy.
              </p>
            ) : (
              topCustomers.map((cust, idx) => (
                <div key={idx} className="flex justify-between items-center text-xs">
                  <div className="min-w-0 flex-1 pr-2">
                    <p className="font-bold text-slate-800 truncate">{cust.companyName}</p>
                    <p className="text-[10px] text-slate-400 font-medium mt-0.5">{cust.count} vyfakturovaných dokladů</p>
                  </div>
                  <div className="text-right shrink-0">
                    <span className="font-bold font-mono text-slate-950">{Math.round(cust.total).toLocaleString('cs-CZ')} Kč</span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
