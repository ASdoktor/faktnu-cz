import React, { useState, useEffect } from 'react';
import { db, auth, handleFirestoreError, OperationType, sanitizeFirestoreData } from '../lib/firebase';
import { collection, query, where, onSnapshot, doc, setDoc, deleteDoc, orderBy } from 'firebase/firestore';
import { ICustomerContact } from '../types';
import { 
  Users, Plus, Trash2, Edit2, Search, Mail, Phone, MapPin, FileText, Loader2, Save, X, Building2, AlertCircle
} from 'lucide-react';

export default function CustomersView() {
  const [contacts, setContacts] = useState<ICustomerContact[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [aresLoading, setAresLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // Form State
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  
  const [companyName, setCompanyName] = useState('');
  const [ico, setIco] = useState('');
  const [dic, setDic] = useState('');
  const [street, setStreet] = useState('');
  const [city, setCity] = useState('');
  const [zip, setZip] = useState('');
  const [country, setCountry] = useState('Česká republika');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [note, setNote] = useState('');

  // Sync / Real-time Load
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const q = query(
      collection(db, 'customers'),
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const list: ICustomerContact[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as ICustomerContact);
      });
      setContacts(list);
      setLoading(false);
    }, (error) => {
      console.error("Failed to load customer contacts:", error);
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  const openAddForm = () => {
    setEditingId(null);
    setCompanyName('');
    setIco('');
    setDic('');
    setStreet('');
    setCity('');
    setZip('');
    setCountry('Česká republika');
    setEmail('');
    setPhone('');
    setNote('');
    setIsFormOpen(true);
  };

  const openEditForm = (contact: ICustomerContact) => {
    setEditingId(contact.id || null);
    setCompanyName(contact.companyName);
    setIco(contact.ico);
    setDic(contact.dic || '');
    setStreet(contact.street);
    setCity(contact.city);
    setZip(contact.zip);
    setCountry(contact.country || 'Česká republika');
    setEmail(contact.email);
    setPhone(contact.phone || '');
    setNote(contact.note || '');
    setIsFormOpen(true);
  };

  const loadFromAres = async () => {
    const cleanIco = ico.replace(/\s/g, '').replace(/^[A-Z]{2}/i, '');
    if (!cleanIco || !/^\d{8}$/.test(cleanIco)) {
      alert('Zadejte prosím platné 8-místné IČO (např. 27074358).');
      return;
    }

    setAresLoading(true);
    try {
      const res = await fetch(`/api/ares/${cleanIco}`);
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'IČO nebylo v registru ARES nalezeno.');
      }
      const data = await res.json();
      setCompanyName(data.companyName || '');
      setStreet(data.street || '');
      setCity(data.city || '');
      setZip(data.zip || '');
      setDic(data.dic || '');
    } catch (e: any) {
      alert(e.message || 'Chyba při stahování dat z registru ARES.');
    } finally {
      setAresLoading(false);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!companyName.trim()) {
      alert('Název firmy / Jméno je povinné.');
      return;
    }

    const user = auth.currentUser;
    if (!user) return;

    setSaving(true);
    try {
      const customerId = editingId || crypto.randomUUID().replace(/-/g, '');
      const newContact: ICustomerContact = {
        id: customerId,
        ownerId: user.uid,
        companyName: companyName.trim(),
        ico: ico.trim(),
        dic: dic.trim(),
        street: street.trim(),
        city: city.trim(),
        zip: zip.trim(),
        country: country.trim(),
        email: email.trim(),
        phone: phone.trim(),
        note: note.trim(),
        createdAt: editingId ? contacts.find(c => c.id === editingId)?.createdAt : new Date().toISOString()
      };

      const docRef = doc(db, 'customers', customerId);
      await setDoc(docRef, sanitizeFirestoreData(newContact));
      
      setIsFormOpen(false);
    } catch (error) {
      console.error(error);
      alert('Nepodařilo se uložit odběratele do databáze.');
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (contact: ICustomerContact) => {
    if (!window.confirm(`Opravdu si přejete smazat odběratele "${contact.companyName}"?`)) return;
    try {
      const docRef = doc(db, 'customers', contact.id!);
      await deleteDoc(docRef);
    } catch (error) {
      console.error(error);
      alert('Smazání kontaktu selhalo.');
    }
  };

  // Filter contacts by search
  const filteredContacts = contacts.filter(c => {
    const term = searchTerm.toLowerCase();
    return (
      c.companyName.toLowerCase().includes(term) ||
      (c.ico && c.ico.includes(term)) ||
      (c.email && c.email.toLowerCase().includes(term)) ||
      (c.city && c.city.toLowerCase().includes(term))
    );
  });

  return (
    <div className="space-y-6">
      {/* HEADER ROW */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold font-display text-slate-900 flex items-center gap-2">
            <Users className="w-5 h-5 text-indigo-600" />
            <span>Adresář Odběratelů</span>
          </h2>
          <p className="text-xs text-slate-400 mt-1 leading-relaxed">
            Rychlá správa a ukládání stálých klientů pro okamžité vyplnění faktury.
          </p>
        </div>
        
        {!isFormOpen && (
          <button
            onClick={openAddForm}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold shadow-md shadow-indigo-100 transition cursor-pointer self-start sm:self-auto"
          >
            <Plus className="w-4 h-4" />
            <span>Nový odběratel</span>
          </button>
        )}
      </div>

      {/* FORM MODAL SHEET */}
      {isFormOpen && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm animate-fade-in-down duration-200">
          <div className="flex items-center justify-between border-b border-slate-100 pb-3 mb-5">
            <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">
              {editingId ? 'Upravit údaje odběratele' : 'Přidat nového odběratele'}
            </h3>
            <button 
              onClick={() => setIsFormOpen(false)}
              className="p-1.5 hover:bg-slate-100 rounded-xl text-slate-400 hover:text-slate-600 transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSave} className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              
              <div className="sm:col-span-2 space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">IČO firmy (ARES vyhledání)</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={ico}
                    onChange={(e) => setIco(e.target.value)}
                    placeholder="Zadejte IČO pro automatické načtení"
                    className="flex-1 bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                  />
                  <button
                    type="button"
                    onClick={loadFromAres}
                    disabled={aresLoading}
                    className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer disabled:opacity-50 shrink-0"
                  >
                    {aresLoading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-500" />
                    ) : (
                      <Search className="w-3.5 h-3.5 text-indigo-500" />
                    )}
                    <span>Načíst z ARES</span>
                  </button>
                </div>
              </div>

              <div className="sm:col-span-2 space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">Jméno odběratele / Název firmy *</label>
                <input
                  type="text"
                  required
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                  placeholder="Např. ACME Corp s.r.o."
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">DIČ (nepovinné)</label>
                <input
                  type="text"
                  value={dic}
                  onChange={(e) => setDic(e.target.value)}
                  placeholder="Např. CZ12345678"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">E-mail</label>
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="faktury@klient.cz"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">Telefonní číslo</label>
                <input
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="+420 777 555 444"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">Ulice a číslo popisné</label>
                <input
                  type="text"
                  value={street}
                  onChange={(e) => setStreet(e.target.value)}
                  placeholder="Např. Průmyslová 124"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">Město</label>
                <input
                  type="text"
                  value={city}
                  onChange={(e) => setCity(e.target.value)}
                  placeholder="Např. Praha"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">PSČ</label>
                <input
                  type="text"
                  value={zip}
                  onChange={(e) => setZip(e.target.value)}
                  placeholder="Např. 110 00"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">Země</label>
                <input
                  type="text"
                  value={country}
                  onChange={(e) => setCountry(e.target.value)}
                  placeholder="Např. Česká republika"
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition"
                />
              </div>

              <div className="space-y-1 sm:col-span-2">
                <label className="text-[10px] font-bold text-slate-500 block uppercase">Interní poznámka</label>
                <textarea
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="Např. stálý klient, fakturace 14 dnů splatnosti"
                  rows={2}
                  className="w-full bg-slate-50 border border-slate-200 focus:border-indigo-500 rounded-xl px-3 py-2 text-xs text-slate-800 outline-none transition font-sans resize-none"
                />
              </div>

            </div>

            <div className="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsFormOpen(false)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs transition cursor-pointer"
              >
                Storno
              </button>
              <button
                type="submit"
                disabled={saving}
                className="inline-flex items-center gap-1.5 px-5 py-2 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-60 text-white font-bold rounded-xl text-xs transition cursor-pointer shadow-md shadow-indigo-100"
              >
                {saving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <Save className="w-3.5 h-3.5" />
                <span>Uložit odběratele</span>
              </button>
            </div>
          </form>
        </div>
      )}

      {/* FILTER SEARCH INPUT BAR */}
      {!isFormOpen && (
        <div className="relative">
          <div className="absolute inset-y-0 left-0 pl-3.5 flex items-center pointer-events-none text-slate-400">
            <Search className="w-4 h-4" />
          </div>
          <input
            type="text"
            placeholder="Vyhledat v adresáři podle názvu, IČO, města nebo e-mailu..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full pl-10 pr-4 py-3 bg-white border border-slate-200 focus:border-indigo-500 rounded-2xl text-xs text-slate-800 outline-none transition shadow-2xs"
          />
        </div>
      )}

      {/* LIST OF CURRENT CLIENT CONTACTS */}
      {!isFormOpen && (
        <>
          {loading ? (
            <div className="flex flex-col items-center justify-center py-16">
              <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-3" />
              <p className="text-xs text-slate-500">Načítám Vaše uložené odběratele...</p>
            </div>
          ) : filteredContacts.length === 0 ? (
            <div className="bg-white border border-slate-200 rounded-3xl p-10 text-center space-y-4">
              <div className="w-12 h-12 bg-slate-50 text-slate-400 flex items-center justify-center rounded-2xl mx-auto border border-slate-100">
                <Users className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="font-extrabold text-slate-800 font-display text-sm">Žádní odběratelé k zobrazení</h4>
                <p className="text-xs text-slate-400 leading-relaxed max-w-sm mx-auto">
                  {searchTerm ? 'Nenašli jsme žádný kontakt odpovídající vyhledávanému výrazu.' : 'Zatím nemáte uložené žádné odběratele. Přidejte si stálé klienty pro bleskové vyplňování.'}
                </p>
              </div>
              {!searchTerm && (
                <button
                  onClick={openAddForm}
                  className="inline-flex items-center gap-1.5 px-4 py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-700 rounded-xl text-xs font-bold border border-indigo-100 transition cursor-pointer"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>Vytvořit prvního odběratele</span>
                </button>
              )}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {filteredContacts.map((contact) => (
                <div 
                  key={contact.id} 
                  className="bg-white border border-slate-200 rounded-3xl p-5 shadow-2xs hover:shadow-xs transition duration-200 flex flex-col justify-between"
                >
                  <div>
                    {/* Header Card line */}
                    <div className="flex items-start justify-between gap-3 border-b border-slate-100 pb-3 mb-3">
                      <div className="min-w-0">
                        <h4 className="font-bold text-slate-800 text-sm truncate font-display" title={contact.companyName}>
                          {contact.companyName}
                        </h4>
                        {contact.ico && (
                          <span className="text-[10px] font-mono text-slate-500 font-medium">
                            IČO: <strong className="text-slate-700 font-semibold">{contact.ico}</strong>
                          </span>
                        )}
                        {contact.dic && (
                          <span className="text-[10px] font-mono text-slate-500 font-medium ml-2.5">
                            DIČ: {contact.dic}
                          </span>
                        )}
                      </div>
                      
                      <div className="flex gap-1 shrink-0">
                        <button
                          onClick={() => openEditForm(contact)}
                          className="p-1.5 hover:bg-slate-100 text-slate-500 hover:text-indigo-600 rounded-lg transition"
                          title="Upravit profil klienta"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleDelete(contact)}
                          className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg transition"
                          title="Smazat kontakt"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    {/* Standard details block */}
                    <div className="space-y-1.5 text-xs text-slate-500 font-sans">
                      <div className="flex items-center gap-2 truncate">
                        <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                        <span>{contact.street}, {contact.zip} {contact.city}</span>
                      </div>
                      
                      {contact.email && (
                        <div className="flex items-center gap-2 truncate">
                          <Mail className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <a href={`mailto:${contact.email}`} className="hover:underline hover:text-indigo-600 truncate">
                            {contact.email}
                          </a>
                        </div>
                      )}

                      {contact.phone && (
                        <div className="flex items-center gap-2">
                          <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                          <span>{contact.phone}</span>
                        </div>
                      )}
                    </div>
                  </div>

                  {contact.note && (
                    <div className="mt-4 p-2.5 bg-slate-50/70 border border-slate-100 rounded-xl text-[11px] text-slate-400 flex items-start gap-1.5 font-sans">
                      <FileText className="w-3.5 h-3.5 text-slate-300 shrink-0 mt-0.5" />
                      <p className="line-clamp-2 leading-relaxed italic">{contact.note}</p>
                    </div>
                  )}

                </div>
              ))}
            </div>
          )}
        </>
      )}

    </div>
  );
}
