import React, { useState, useEffect } from 'react';
import { db, auth, logOut, handleFirestoreError, OperationType, sanitizeFirestoreData } from '../lib/firebase';
import { doc, getDoc, setDoc } from 'firebase/firestore';
import { IUserProfile, IFrequentItem } from '../types';
import { 
  Building2, Search, Loader2, Save, LogOut, Plus, Trash2, 
  Palette, RefreshCw, Server, Check, Upload, Laptop, Smartphone, Phone,
  ChevronDown, ChevronUp, CreditCard
} from 'lucide-react';

interface UserProfileProps {
  onSaved: (profile: IUserProfile) => void;
}

export default function UserProfile({ onSaved }: UserProfileProps) {
  const [profile, setProfile] = useState<IUserProfile>({
    uid: auth.currentUser?.uid || '',
    email: auth.currentUser?.email || '',
    companyName: '',
    street: '',
    city: '',
    zip: '',
    ico: '',
    dic: '',
    phone: '',
    bankAccount: '',
    bankCode: '0100',
    dphRate: 21,
    brandColor: '#2563eb', // safe blue default
    invoiceLayout: 'classic',
    frequentItems: [],
    smtpHost: '',
    smtpPort: 587,
    smtpUser: '',
    smtpPass: '',
    emailSenderName: '',
    suppliers: [],
    activeSupplierId: '',
    invoiceNumbering: { prefix: 'F', includeYear: true, digitCount: 4, startNumber: 1, resetYearly: true },
    advanceNumbering: { prefix: 'Z', includeYear: true, digitCount: 4, startNumber: 1, resetYearly: true },
    quoteNumbering: { prefix: 'N', includeYear: true, digitCount: 4, startNumber: 1, resetYearly: true }
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [aresLoading, setAresLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const [expandedSections, setExpandedSections] = useState<Record<string, boolean>>({
    profiles: false,
    supplier: false,
    bankAccount: false,
    invoiceDesign: false,
    numbering: false,
    smtp: false,
    frequentItems: false
  });

  const toggleSection = (section: string) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  // Load profile from Firestore on mount
  useEffect(() => {
    async function loadProfile() {
      const user = auth.currentUser;
      if (!user) return;

      try {
        const userDocRef = doc(db, 'users', user.uid);
        const snapshot = await getDoc(userDocRef);
        
        if (snapshot.exists()) {
          const data = snapshot.data() as IUserProfile;
          setProfile({
            ...profile,
            ...data,
            uid: user.uid,
            email: user.email || data.email,
            frequentItems: data.frequentItems || [],
            invoiceNumbering: data.invoiceNumbering || { prefix: 'F', includeYear: true, digitCount: 4, startNumber: 1, resetYearly: true },
            advanceNumbering: data.advanceNumbering || { prefix: 'Z', includeYear: true, digitCount: 4, startNumber: 1, resetYearly: true },
            quoteNumbering: data.quoteNumbering || { prefix: 'N', includeYear: true, digitCount: 4, startNumber: 1, resetYearly: true }
          });
          onSaved(data);
        } else {
          // Initialize fresh default profile for new user
          const initialProfile: IUserProfile = {
            ...profile,
            uid: user.uid,
            email: user.email || '',
            companyName: user.displayName || ''
          };
          setProfile(initialProfile);
          onSaved(initialProfile);
        }
      } catch (err) {
        console.error('Failed to load profile from firestore:', err);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, []);

  // Handler for custom logo upload and resizing to keep firestore payloads small
  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 1.5 * 1024 * 1024) {
      alert("Vyberte prosím menší logo (max. 1.5 MB).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.src = event.target?.result as string;
      img.onload = () => {
        // Create canvas to downscale logo
        const canvas = document.createElement('canvas');
        const MAX_WIDTH = 250;
        const scale = MAX_WIDTH / img.width;
        
        canvas.width = MAX_WIDTH;
        canvas.height = img.height * scale;
        
        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
          const compressedBase64 = canvas.toDataURL('image/png', 0.85);
          setProfile(prev => ({ ...prev, logoUrl: compressedBase64 }));
        }
      };
    };
    reader.readAsDataURL(file);
  };

  // Profile fields manual change handler
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: name === 'dphRate' || name === 'smtpPort' ? Number(value) : value
    }));
  };

  const handleNumberingChange = (
    type: 'invoiceNumbering' | 'advanceNumbering' | 'quoteNumbering',
    field: 'prefix' | 'includeYear' | 'digitCount' | 'startNumber' | 'resetYearly',
    value: any
  ) => {
    setProfile(prev => {
      const current = prev[type] || {
        prefix: type === 'invoiceNumbering' ? 'F' : type === 'advanceNumbering' ? 'Z' : 'N',
        includeYear: true,
        digitCount: 4,
        startNumber: 1,
        resetYearly: true
      };
      return {
        ...prev,
        [type]: {
          ...current,
          [field]: field === 'digitCount' || field === 'startNumber' ? Number(value) : value
        }
      };
    });
  };

  // Load company supplier data from Czech Republic custom server proxy bypass
  const fetchAresData = async () => {
    if (!profile.ico || !/^\d{8}$/.test(profile.ico.trim())) {
      setStatusMessage({ type: 'error', text: 'Zadejte prosím platné 8-místné IČO.' });
      return;
    }

    setAresLoading(true);
    setStatusMessage(null);

    try {
      const cleanIco = profile.ico.trim();
      const res = await fetch(`/api/ares/${cleanIco}`);
      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Nepodařilo se načíst data z registru ARES.');
      }

      setProfile(prev => ({
        ...prev,
        companyName: data.companyName || prev.companyName,
        street: data.street || prev.street,
        city: data.city || prev.city,
        zip: data.zip || prev.zip,
        dic: data.dic || prev.dic
      }));

      setStatusMessage({ type: 'success', text: `Údaje firmy "${data.companyName}" úspěšně načteny z registru ARES.` });
    } catch (err: any) {
      console.error(err);
      setStatusMessage({ type: 'error', text: err.message || 'Chyba při stahování dat z registru ARES.' });
    } finally {
      setAresLoading(false);
    }
  };

  // Manage Frequent Items
  const [newItemName, setNewItemName] = useState('');
  const [newItemUnit, setNewItemUnit] = useState('ks');
  const [newItemPrice, setNewItemPrice] = useState(0);

  const addFrequentItem = () => {
    if (!newItemName.trim()) return;
    const items = profile.frequentItems || [];
    const item: IFrequentItem = {
      id: crypto.randomUUID(),
      name: newItemName.trim(),
      unit: newItemUnit,
      price: newItemPrice
    };
    setProfile(prev => ({
      ...prev,
      frequentItems: [...items, item]
    }));
    setNewItemName('');
    setNewItemPrice(0);
  };

  const removeFrequentItem = (id: string) => {
    const items = profile.frequentItems || [];
    setProfile(prev => ({
      ...prev,
      frequentItems: items.filter(it => it.id !== id)
    }));
  };

  // Submit profile save
  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    setStatusMessage(null);

    try {
      const user = auth.currentUser;
      if (!user) throw new Error("Uživatel není přihlášen.");

      const updatedProfile = {
        ...profile,
        updatedAt: new Date().toISOString()
      };

      const userDocRef = doc(db, 'users', user.uid);
      await setDoc(userDocRef, sanitizeFirestoreData(updatedProfile));

      setProfile(updatedProfile);
      onSaved(updatedProfile);
      
      setStatusMessage({ type: 'success', text: 'Profil dodavatele a nastavení úspěšně uloženo.' });
      
      // Auto dismiss success toast
      setTimeout(() => setStatusMessage(null), 4000);
    } catch (err) {
      console.error(err);
      setStatusMessage({ type: 'error', text: 'Nepodařilo se uložit profil.' });
    } finally {
      setSaving(false);
    }
  };

  const colors = [
    { name: 'Modrá', value: '#2563eb' },
    { name: 'Smaragdová', value: '#10b981' },
    { name: 'Indigo', value: '#6366f1' },
    { name: 'Fialová', value: '#8b5cf6' },
    { name: 'Růžová', value: '#ec4899' },
    { name: 'Oranžová', value: '#f97316' },
    { name: 'Břidlicová', value: '#475569' }
  ];

  const saveAsNewSupplier = () => {
    if (!profile.companyName.trim()) {
      setStatusMessage({ type: 'error', text: 'Zadejte prosím nejprve název firmy k uložení.' });
      return;
    }
    const newSupp = {
      id: crypto.randomUUID(),
      companyName: profile.companyName.trim(),
      street: profile.street.trim(),
      city: profile.city.trim(),
      zip: profile.zip.trim(),
      ico: profile.ico.trim(),
      dic: (profile.dic || '').trim(),
      bankAccount: profile.bankAccount.trim(),
      bankCode: profile.bankCode.trim(),
      logoUrl: profile.logoUrl || '',
      phone: (profile.phone || '').trim()
    };
    const savedSuppliers = profile.suppliers || [];
    
    // Check if supplier with this ICO already exists
    if (savedSuppliers.some(s => s.ico === newSupp.ico)) {
      setStatusMessage({ type: 'error', text: `Profil s IČO ${newSupp.ico} již máte uložený.` });
      return;
    }

    setProfile(prev => ({
      ...prev,
      suppliers: [...savedSuppliers, newSupp],
      activeSupplierId: newSupp.id
    }));
    setStatusMessage({ type: 'success', text: `Profil "${newSupp.companyName}" byl přidán do rychlých voleb.` });
  };

  const activateSupplier = (supp: any) => {
    setProfile(prev => ({
      ...prev,
      companyName: supp.companyName,
      street: supp.street,
      city: supp.city,
      zip: supp.zip,
      ico: supp.ico,
      dic: supp.dic || '',
      bankAccount: supp.bankAccount,
      bankCode: supp.bankCode,
      logoUrl: supp.logoUrl || '',
      phone: supp.phone || '',
      activeSupplierId: supp.id
    }));
    setStatusMessage({ type: 'success', text: `Aktivován profil "${supp.companyName}".` });
  };

  const deleteSavedSupplier = (id: string, name: string) => {
    const savedSuppliers = profile.suppliers || [];
    setProfile(prev => ({
      ...prev,
      suppliers: savedSuppliers.filter(s => s.id !== id),
      activeSupplierId: profile.activeSupplierId === id ? '' : profile.activeSupplierId
    }));
    setStatusMessage({ type: 'success', text: `Profil "${name}" byl smazán.` });
  };

  const renderLayoutMiniature = () => {
    const color = profile.brandColor || '#2563eb';
    const layout = profile.invoiceLayout || 'classic';

    return (
      <div className="border border-slate-200 rounded-3xl p-4 bg-white shadow-2xs font-sans text-[8px] text-slate-700 space-y-2.5 max-w-full mx-auto select-none">
        <span className="text-[9px] font-extrabold text-slate-400 block uppercase tracking-wider mb-0.5">Živý grafický náhled vzhledu faktury</span>
        
        {layout === 'classic' && (
          <div className="space-y-2.5 border border-slate-100 p-3 rounded-2xl bg-white">
            <div className="flex justify-between items-center">
              <div className="flex items-center gap-1.5">
                <span className="w-4 h-4 rounded bg-slate-200 flex items-center justify-center font-bold text-[7px]" style={{ color }}>F</span>
                <span className="font-extrabold text-[8px]" style={{ color }}>Firma s.r.o.</span>
              </div>
              <span className="font-mono text-[8px] font-bold" style={{ color }}>FAKTURA 20260001</span>
            </div>
            
            <div className="grid grid-cols-2 gap-2 text-[6.5px]">
              <div className="p-1.5 border border-slate-100 rounded-lg bg-slate-50/50">
                <span className="font-bold uppercase text-[5.5px]" style={{ color }}>Dodavatel</span>
                <p className="font-semibold text-slate-800">Moje Firma s.r.o.</p>
                <p className="text-slate-400">Průmyslová 12, Praha</p>
                <p className="text-slate-400 font-mono">IČO: 12345678</p>
              </div>
              <div className="p-1.5 border border-slate-100 rounded-lg bg-slate-50/50">
                <span className="font-bold uppercase text-[5.5px]" style={{ color }}>Odběratel</span>
                <p className="font-semibold text-slate-800">ACME Corporation</p>
                <p className="text-slate-400">Václavské nám. 1, Praha</p>
              </div>
            </div>

            <div className="space-y-1">
              <div className="flex border-b text-[6px] font-bold pb-0.5" style={{ borderBottomColor: color }}>
                <span className="flex-1 text-left text-slate-400">Položka</span>
                <span className="w-10 text-right text-slate-400">Množství</span>
                <span className="w-14 text-right text-slate-400">Cena</span>
              </div>
              <div className="flex border-b border-slate-100 py-0.5 text-slate-800">
                <span className="flex-1 text-left">Konzultační služby</span>
                <span className="w-10 text-right">5 ks</span>
                <span className="w-14 text-right font-bold">5 000 Kč</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-1 border-t border-slate-150">
              <span className="text-slate-400 font-medium">Celkem k úhradě</span>
              <span className="font-black text-[10px]" style={{ color }}>5 000 Kč</span>
            </div>
          </div>
        )}

        {layout === 'modern' && (
          <div className="space-y-2.5 border border-slate-100 p-3 rounded-2xl bg-white">
            <div className="rounded-lg text-white p-2 flex justify-between items-center" style={{ backgroundColor: color }}>
              <div className="flex items-center gap-1">
                <div className="w-3.5 h-3.5 rounded bg-white/30 flex items-center justify-center font-black">F</div>
                <span className="font-black text-[8px] tracking-tight">Firma s.r.o.</span>
              </div>
              <span className="font-mono text-[8px] font-extrabold tracking-wider">FAKTURA #20260001</span>
            </div>
            
            <div className="grid grid-cols-2 gap-3 pt-0.5 text-[6.5px]">
              <div>
                <span className="font-bold tracking-wider uppercase text-[5px] text-slate-400" style={{ color }}>Zasílá:</span>
                <p className="font-bold text-slate-800">Moje Firma s.r.o.</p>
                <p className="text-slate-400 mt-0.5">Průmyslová 12, Praha</p>
                <p className="text-slate-400 font-mono">IČ: 12345678</p>
              </div>
              <div>
                <span className="font-bold tracking-wider uppercase text-[5px] text-slate-400" style={{ color }}>Příjemce:</span>
                <p className="font-bold text-slate-800">ACME Corporation</p>
                <p className="text-slate-400 mt-0.5">Václavské nám. 1, Praha</p>
              </div>
            </div>

            <div className="rounded-lg overflow-hidden border border-slate-100 bg-slate-50/40">
              <div className="flex text-[5.5px] font-bold p-1 bg-slate-100/60 text-slate-500">
                <span className="flex-1">Popis položky</span>
                <span className="w-10 text-right">Počet</span>
                <span className="w-14 text-right">Celkem</span>
              </div>
              <div className="flex py-1 px-1 border-t border-slate-100 text-slate-700">
                <span className="flex-1 font-medium">Grafické práce & UX design</span>
                <span className="w-10 text-right">10 hod</span>
                <span className="w-14 text-right font-bold" style={{ color }}>15 000 Kč</span>
              </div>
            </div>

            <div className="flex justify-end pt-0.5">
              <div className="bg-slate-50 border border-slate-100 p-1 rounded-lg flex items-center gap-3">
                <span className="text-[6px] uppercase font-bold text-slate-400">Částka celkem</span>
                <span className="font-black text-[9.5px]" style={{ color }}>15 000 Kč</span>
              </div>
            </div>
          </div>
        )}

        {layout === 'minimal' && (
          <div className="space-y-2.5 border border-slate-100 p-3 rounded-2xl bg-white">
            <div className="flex justify-between items-baseline border-b border-slate-100 pb-1.5">
              <div className="min-w-0">
                <span className="font-black text-[9px] tracking-tight text-slate-900 block">Moje Firma s.r.o.</span>
                <span className="text-[6px] text-slate-400 mt-0.5">IČO: 12345678 • Průmyslová 12, Praha</span>
              </div>
              <div className="text-right">
                <span className="font-bold text-[8px] block" style={{ color }}>FAKTURA</span>
                <span className="font-mono text-[7px] text-slate-400">2026-0001</span>
              </div>
            </div>

            <div className="text-[6.5px] p-0.5">
              <span className="font-semibold uppercase text-[5.5px] text-slate-400 block mb-0.5">Odběratel</span>
              <p className="font-bold text-slate-900">ACME Corporation</p>
              <p className="text-slate-500">Václavské nám. 1, Praha</p>
            </div>

            <div className="space-y-1.5 pt-1.5">
              <div className="flex justify-between font-bold border-b border-slate-200 pb-0.5 text-slate-400 text-[5.5px]">
                <span>Popis služby</span>
                <span>K úhradě</span>
              </div>
              <div className="flex justify-between text-slate-800">
                <span>Vývoj webové aplikace pro správu faktur</span>
                <span className="font-medium">42 000 Kč</span>
              </div>
            </div>

            <div className="flex justify-between items-center pt-2.5 border-t border-slate-200">
              <span className="text-slate-400 font-bold uppercase text-[5.5px]">Celková částka</span>
              <span className="font-bold text-[10px]" style={{ color }}>42 000 Kč</span>
            </div>
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-blue-500 animate-spin mb-3" />
        <p className="text-slate-400 text-sm">Načítám profil dodavatele...</p>
      </div>
    );
  }

  return (
    <div className="max-w-xl mx-auto pb-16 px-4">

      {/* MULTIPLE SUPPLIERS LIST & SWITCHER */}
      <div className="mb-4 rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden">
        <div 
          onClick={() => toggleSection('profiles')}
          className="p-5 flex items-start gap-3.5 cursor-pointer hover:bg-slate-50/60 transition select-none"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
            <Building2 className="w-5 h-5" />
          </div>
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">Moje profily dodavatelů</h3>
              <span className="text-[10px] font-mono font-bold bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded-full">
                {(profile.suppliers || []).length + 1}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Správa a rychlé přepínání mezi více vlastními firmami a profily dodavatelů.
            </p>
          </div>
          <div className="shrink-0 text-slate-400 mt-1">
            {expandedSections.profiles ? (
              <ChevronUp className="w-5 h-5" />
            ) : (
              <ChevronDown className="w-5 h-5" />
            )}
          </div>
        </div>

        {expandedSections.profiles && (
          <div className="p-5 border-t border-slate-100 bg-slate-50/20 space-y-4">
            <p className="text-xs text-slate-500 leading-relaxed">
              Zadejte údaje do formuláře níže a klikněte na tlačítko níže pro uložení firmy jako další volby. Pak mezi nimi můžete jednoduše překlikávat.
            </p>

            <div className="flex flex-col gap-2 pt-1.5">
              {/* Active profile card */}
              <div className="p-3.5 rounded-2xl bg-indigo-50/80 border border-indigo-200/65 flex justify-between items-center text-xs">
                <div className="min-w-0 pr-2">
                  <div className="flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full bg-indigo-600 animate-ping" />
                    <p className="font-extrabold text-slate-900 truncate">
                      {profile.companyName || 'Aktuální formulář (nevyplněno)'}
                    </p>
                  </div>
                  <p className="text-[10.5px] text-indigo-700/80 font-mono mt-0.5">
                    IČO: {profile.ico || '---'} • {profile.city || '---'}
                  </p>
                </div>
                <span className="text-[10px] shrink-0 font-bold bg-indigo-600 text-white px-2.5 py-1 rounded-xl">
                  AKTIVNÍ
                </span>
              </div>

              {/* Additional profiles */}
              {(profile.suppliers || []).map((supp) => {
                const isActive = profile.activeSupplierId === supp.id;
                return (
                  <div 
                    key={supp.id} 
                    className={`p-3.5 rounded-2xl border transition-all flex justify-between items-center text-xs ${
                      isActive 
                        ? 'bg-indigo-50/80 border-indigo-200/65' 
                        : 'bg-white border-slate-200 hover:border-slate-300'
                    }`}
                  >
                    <div className="min-w-0 pr-2 flex-1">
                      <p className="font-bold text-slate-800 truncate">{supp.companyName}</p>
                      <p className="text-[10px] text-slate-400 font-mono mt-0.5">
                        IČO: {supp.ico} • {supp.city}
                      </p>
                    </div>
                    <div className="flex items-center gap-2.5 shrink-0">
                      {!isActive && (
                        <button
                          type="button"
                          onClick={() => activateSupplier(supp)}
                          className="px-2.5 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-lg transition-colors cursor-pointer text-[10.5px] border border-slate-200"
                        >
                          Aktivovat
                        </button>
                      )}
                      <button
                        type="button"
                        onClick={() => deleteSavedSupplier(supp.id!, supp.companyName)}
                        className="p-1.5 hover:bg-red-50 text-slate-400 hover:text-red-500 rounded-lg transition-colors cursor-pointer"
                        title="Odstranit ze seznamu"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Save current form as profile button */}
            <div className="pt-2">
              <button
                type="button"
                onClick={saveAsNewSupplier}
                className="w-full inline-flex items-center justify-center gap-1.5 py-2.5 bg-white hover:bg-slate-50 border border-slate-200 text-indigo-600 rounded-xl text-xs font-bold transition cursor-pointer touch-manipulation shadow-2xs"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>Uložit aktuálně vyplněnou firmu jako nový profil</span>
              </button>
            </div>
          </div>
        )}
      </div>

      <form onSubmit={handleSaveProfile} className="space-y-6">

        {/* SECTION 1: Supplier Details */}
        <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden mb-4 animate-duration-200">
          <div 
            onClick={() => toggleSection('supplier')}
            className="p-5 flex items-start gap-3.5 cursor-pointer hover:bg-slate-50/60 transition select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
              <Building2 className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">Údaje o dodavateli (Moje Firma)</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Hlavní fakturační údaje Vaší firmy: IČO, DIČ, adresa a telefonní kontakt.
              </p>
            </div>
            <div className="shrink-0 text-slate-400 mt-1">
              {expandedSections.supplier ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </div>

          {expandedSections.supplier && (
            <div className="p-5 border-t border-slate-100 bg-slate-50/20 space-y-4">
              {/* IČO + ARES Loader */}
              <div className="space-y-1.5">
                <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">IČO</label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    name="ico"
                    value={profile.ico}
                    onChange={handleChange}
                    placeholder="Např. 12345678"
                    className="flex-1 bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                  <button
                    type="button"
                    onClick={fetchAresData}
                    disabled={aresLoading}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-slate-150 hover:bg-slate-200 border border-slate-200 text-slate-700 rounded-xl text-xs font-bold transition disabled:brightness-75 cursor-pointer touch-manipulation"
                  >
                    {aresLoading ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin text-indigo-600" />
                    ) : (
                      <Search className="w-3.5 h-3.5 text-indigo-600" />
                    )}
                    <span>Hledat v ARES</span>
                  </button>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Název firmy / Jméno</label>
                  <input
                    type="text"
                    name="companyName"
                    value={profile.companyName}
                    onChange={handleChange}
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">DIČ (nepovinné)</label>
                  <input
                    type="text"
                    name="dic"
                    value={profile.dic || ''}
                    onChange={handleChange}
                    placeholder="Např. CZ12345678"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Sazba DPH (výchozí)</label>
                  <select
                    name="dphRate"
                    value={profile.dphRate}
                    onChange={handleChange}
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-700 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  >
                    <option value={21}>Plátce DPH (Základní 21%)</option>
                    <option value={12}>Plátce DPH (Snížená 12%)</option>
                    <option value={0}>Neplátce DPH (0%)</option>
                  </select>
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Ulice a číslo popisné</label>
                  <input
                    type="text"
                    name="street"
                    value={profile.street}
                    onChange={handleChange}
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Město</label>
                  <input
                    type="text"
                    name="city"
                    value={profile.city}
                    onChange={handleChange}
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">PSČ</label>
                  <input
                    type="text"
                    name="zip"
                    value={profile.zip}
                    onChange={handleChange}
                    required
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                {/* Supplier Phone Field */}
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider flex items-center gap-1.5">
                    <Phone className="w-3.5 h-3.5 text-slate-400" />
                    <span>Telefonní číslo dodavatele (nepovinné)</span>
                  </label>
                  <input
                    type="text"
                    name="phone"
                    value={profile.phone || ''}
                    onChange={handleChange}
                    placeholder="Např. +420 123 456 789"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 2a: Bank Account */}
        <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden mb-4">
          <div 
            onClick={() => toggleSection('bankAccount')}
            className="p-5 flex items-start gap-3.5 cursor-pointer hover:bg-slate-50/60 transition select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
              <CreditCard className="w-4 h-4" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">Bankovní účet</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Číslo bankovního účtu a kód banky pro automatické QR platby na dokladech.
              </p>
            </div>
            <div className="shrink-0 text-slate-400 mt-1">
              {expandedSections.bankAccount ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </div>

          {expandedSections.bankAccount && (
            <div className="p-5 border-t border-slate-100 bg-slate-50/20 space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Číslo účtu (bez kódu banky)</label>
                  <input
                    type="text"
                    name="bankAccount"
                    value={profile.bankAccount}
                    onChange={handleChange}
                    required
                    placeholder="Např. 123456789"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Kód banky</label>
                  <input
                    type="text"
                    name="bankCode"
                    value={profile.bankCode || ''}
                    onChange={handleChange}
                    required
                    placeholder="Např. 0100"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 2b: Invoice Design */}
        <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden mb-4">
          <div 
            onClick={() => toggleSection('invoiceDesign')}
            className="p-5 flex items-start gap-3.5 cursor-pointer hover:bg-slate-50/60 transition select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
              <Palette className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">Design a vzhled faktury</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Vlastní logo dodavatele, grafické šablony vzhledu faktury a doplňkové motivové barvy.
              </p>
            </div>
            <div className="shrink-0 text-slate-400 mt-1">
              {expandedSections.invoiceDesign ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </div>

          {expandedSections.invoiceDesign && (
            <div className="p-5 border-t border-slate-100 bg-slate-50/20 space-y-4">
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Logo pro faktury</label>
                  <div className="flex items-center gap-4 bg-slate-50 p-3 rounded-2xl border border-slate-200">
                    {profile.logoUrl ? (
                      <div className="relative w-16 h-16 bg-white rounded-lg overflow-hidden flex items-center justify-center p-1 border border-slate-250">
                        <img src={profile.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain" referrerPolicy="no-referrer" />
                        <button
                          type="button"
                          onClick={() => setProfile(prev => ({ ...prev, logoUrl: undefined }))}
                          className="absolute top-0 right-0 bg-red-600/95 text-white rounded-bl-lg p-1 hover:bg-red-500 transition cursor-pointer"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ) : (
                      <div className="w-16 h-16 rounded-lg border-2 border-dashed border-slate-300 flex flex-col items-center justify-center text-slate-400 bg-white">
                        <Upload className="w-5 h-5 mb-0.5" />
                        <span className="text-[10px] font-medium">Žádné</span>
                      </div>
                    )}
                    <div className="flex-1">
                      <input
                        type="file"
                        id="logo-file"
                        accept="image/*"
                        onChange={handleLogoChange}
                        className="hidden"
                      />
                      <label
                        htmlFor="logo-file"
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-250 rounded-xl text-xs font-bold cursor-pointer transition shadow-2xs touch-manipulation"
                      >
                        <span>Vybrat soubor loga</span>
                      </label>
                      <p className="text-[10px] text-slate-400 mt-1">Doporučený formát PNG/JPG. Max 1.5MB.</p>
                    </div>
                  </div>
                </div>

                {/* Layout preference */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Grafické rozložení faktury</label>
                  <div className="grid grid-cols-3 gap-2">
                    {[
                      { id: 'classic', name: 'Klasický', icon: <Building2 className="w-3.5 h-3.5" /> },
                      { id: 'modern', name: 'Moderní', icon: <Smartphone className="w-3.5 h-3.5" /> },
                      { id: 'minimal', name: 'Minimal', icon: <Laptop className="w-3.5 h-3.5" /> }
                    ].map((lay) => (
                      <button
                        key={lay.id}
                        type="button"
                        onClick={() => setProfile(prev => ({ ...prev, invoiceLayout: lay.id }))}
                        className={`flex flex-col items-center justify-center p-3 rounded-xl border text-center transition cursor-pointer touch-manipulation ${
                          profile.invoiceLayout === lay.id 
                            ? 'bg-indigo-50 border-indigo-400 text-indigo-700 font-extrabold' 
                            : 'bg-slate-50 border-slate-200 text-slate-500 hover:text-slate-700 hover:bg-slate-100/50'
                        }`}
                      >
                        {lay.icon}
                        <span className="text-xs font-medium mt-1">{lay.name}</span>
                      </button>
                    ))}
                  </div>
                </div>

                {/* Brand Colors */}
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Hlavní motiv barvy faktury</label>
                  <div className="flex flex-wrap gap-2.5 p-3.5 bg-slate-50 rounded-2xl border border-slate-200">
                    {colors.map((col) => (
                      <button
                        key={col.value}
                        type="button"
                        onClick={() => setProfile(prev => ({ ...prev, brandColor: col.value }))}
                        style={{ backgroundColor: col.value }}
                        className="w-8 h-8 rounded-full flex items-center justify-center cursor-pointer relative shadow hover:scale-105 active:scale-95 transition"
                        title={col.name}
                      >
                        {profile.brandColor === col.value && (
                          <Check className="w-4 h-4 text-white drop-shadow" />
                        )}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Live Preview Miniature */}
                <div className="pt-3.5 border-t border-slate-100/80">
                  {renderLayoutMiniature()}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 2c: Document Numbering Format Settings */}
        <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden mb-4">
          <div 
            onClick={() => toggleSection('numbering')}
            className="p-5 flex items-start gap-3.5 cursor-pointer hover:bg-slate-50/60 transition select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">Číslování dokladů (Číselné řady)</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Nastavení předpon, formátů, počtu číslic a chování automatického číslování faktur, záloh a nabídek.
              </p>
            </div>
            <div className="shrink-0 text-slate-400 mt-1">
              {expandedSections.numbering ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </div>

          {expandedSections.numbering && (
            <div className="p-5 border-t border-slate-100 bg-slate-50/20 space-y-6">
              
              {/* 1. Invoices */}
              <div className="p-4 rounded-2xl bg-white border border-slate-150 space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-indigo-600 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-indigo-500" />
                  <span>Běžné faktury</span>
                </h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Předpona (Prefix)</label>
                    <input
                      type="text"
                      value={profile.invoiceNumbering?.prefix ?? 'F'}
                      onChange={(e) => handleNumberingChange('invoiceNumbering', 'prefix', e.target.value)}
                      placeholder="Např. F, FA, INV"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Počet číslic v řadě</label>
                    <input
                      type="number"
                      min={2}
                      max={8}
                      value={profile.invoiceNumbering?.digitCount ?? 4}
                      onChange={(e) => handleNumberingChange('invoiceNumbering', 'digitCount', e.target.value)}
                      placeholder="Např. 4 pro 0001"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Počáteční číslo řady</label>
                    <input
                      type="number"
                      min={1}
                      value={profile.invoiceNumbering?.startNumber ?? 1}
                      onChange={(e) => handleNumberingChange('invoiceNumbering', 'startNumber', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>

                  <div className="sm:col-span-2 pt-1 space-y-2">
                    <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={profile.invoiceNumbering?.includeYear ?? true}
                        onChange={(e) => handleNumberingChange('invoiceNumbering', 'includeYear', e.target.checked)}
                        className="w-3.5 h-3.5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 accent-indigo-500"
                      />
                      <span className="text-xs text-slate-600 font-medium">Vložit aktuální rok za předponu (např. F20260001)</span>
                    </label>

                    <label className="inline-flex items-center gap-2 cursor-pointer select-none block">
                      <input
                        type="checkbox"
                        checked={profile.invoiceNumbering?.resetYearly ?? true}
                        onChange={(e) => handleNumberingChange('invoiceNumbering', 'resetYearly', e.target.checked)}
                        className="w-3.5 h-3.5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 accent-indigo-500"
                      />
                      <span className="text-xs text-slate-600 font-medium">Resetovat číselnou řadu každý rok od počátečního čísla</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* 2. Advance Invoices */}
              <div className="p-4 rounded-2xl bg-white border border-slate-150 space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-emerald-650 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" />
                  <span>Zálohové faktury</span>
                </h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Předpona (Prefix)</label>
                    <input
                      type="text"
                      value={profile.advanceNumbering?.prefix ?? 'Z'}
                      onChange={(e) => handleNumberingChange('advanceNumbering', 'prefix', e.target.value)}
                      placeholder="Např. Z, ZA"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Počet číslic v řadě</label>
                    <input
                      type="number"
                      min={2}
                      max={8}
                      value={profile.advanceNumbering?.digitCount ?? 4}
                      onChange={(e) => handleNumberingChange('advanceNumbering', 'digitCount', e.target.value)}
                      placeholder="Např. 4 pro 0001"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Počáteční číslo řady</label>
                    <input
                      type="number"
                      min={1}
                      value={profile.advanceNumbering?.startNumber ?? 1}
                      onChange={(e) => handleNumberingChange('advanceNumbering', 'startNumber', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>

                  <div className="sm:col-span-2 pt-1 space-y-2">
                    <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={profile.advanceNumbering?.includeYear ?? true}
                        onChange={(e) => handleNumberingChange('advanceNumbering', 'includeYear', e.target.checked)}
                        className="w-3.5 h-3.5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 accent-indigo-500"
                      />
                      <span className="text-xs text-slate-600 font-medium">Vložit aktuální rok za předponu (např. Z20260001)</span>
                    </label>

                    <label className="inline-flex items-center gap-2 cursor-pointer select-none block">
                      <input
                        type="checkbox"
                        checked={profile.advanceNumbering?.resetYearly ?? true}
                        onChange={(e) => handleNumberingChange('advanceNumbering', 'resetYearly', e.target.checked)}
                        className="w-3.5 h-3.5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 accent-indigo-500"
                      />
                      <span className="text-xs text-slate-600 font-medium">Resetovat číselnou řadu každý rok od počátečního čísla</span>
                    </label>
                  </div>
                </div>
              </div>

              {/* 3. Quotes */}
              <div className="p-4 rounded-2xl bg-white border border-slate-150 space-y-3">
                <h4 className="font-bold text-xs uppercase tracking-wider text-purple-600 flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-500" />
                  <span>Cenové nabídky</span>
                </h4>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Předpona (Prefix)</label>
                    <input
                      type="text"
                      value={profile.quoteNumbering?.prefix ?? 'N'}
                      onChange={(e) => handleNumberingChange('quoteNumbering', 'prefix', e.target.value)}
                      placeholder="Např. N, CN, OFFER"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Počet číslic v řadě</label>
                    <input
                      type="number"
                      min={2}
                      max={8}
                      value={profile.quoteNumbering?.digitCount ?? 4}
                      onChange={(e) => handleNumberingChange('quoteNumbering', 'digitCount', e.target.value)}
                      placeholder="Např. 4 pro 0001"
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] font-bold text-slate-500 uppercase">Počáteční číslo řady</label>
                    <input
                      type="number"
                      min={1}
                      value={profile.quoteNumbering?.startNumber ?? 1}
                      onChange={(e) => handleNumberingChange('quoteNumbering', 'startNumber', e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500 transition"
                    />
                  </div>

                  <div className="sm:col-span-2 pt-1 space-y-2">
                    <label className="inline-flex items-center gap-2 cursor-pointer select-none">
                      <input
                        type="checkbox"
                        checked={profile.quoteNumbering?.includeYear ?? true}
                        onChange={(e) => handleNumberingChange('quoteNumbering', 'includeYear', e.target.checked)}
                        className="w-3.5 h-3.5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 accent-indigo-500"
                      />
                      <span className="text-xs text-slate-600 font-medium">Vložit aktuální rok za předponu (např. N20260001)</span>
                    </label>

                    <label className="inline-flex items-center gap-2 cursor-pointer select-none block">
                      <input
                        type="checkbox"
                        checked={profile.quoteNumbering?.resetYearly ?? true}
                        onChange={(e) => handleNumberingChange('quoteNumbering', 'resetYearly', e.target.checked)}
                        className="w-3.5 h-3.5 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 accent-indigo-500"
                      />
                      <span className="text-xs text-slate-600 font-medium">Resetovat číselnou řadu každý rok od počátečního čísla</span>
                    </label>
                  </div>
                </div>
              </div>

            </div>
          )}
        </div>

        {/* SECTION 3: SMTP Mail Server Client (Strict Full Stack support!) */}
        <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden mb-4">
          <div 
            onClick={() => toggleSection('smtp')}
            className="p-5 flex items-start gap-3.5 cursor-pointer hover:bg-slate-50/60 transition select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
              <Server className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">Odchozí e-mailový SMTP server</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Konfigurace vlastního SMTP serveru pro odesílání PDF faktur z Vaší schránky.
              </p>
            </div>
            <div className="shrink-0 text-slate-400 mt-1">
              {expandedSections.smtp ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </div>

          {expandedSections.smtp && (
            <div className="p-5 border-t border-slate-100 bg-slate-50/20 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Vyplňte pro přímé odesílání PDF faktur e-mailem Vašim klientům. Pokud SMTP nevyplníte, systém při odeslání vygeneruje odkaz pro testování (sandbox), nebo můžete vždy odeslat e-mail přes mobilní e-mailovou aplikaci tlačítkem.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">SMTP Server Host</label>
                  <input
                    type="text"
                    name="smtpHost"
                    value={profile.smtpHost || ''}
                    onChange={handleChange}
                    placeholder="Např. smtp.seznam.cz, smtp.gmail.com"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>
                
                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">SMTP Port</label>
                  <input
                    type="number"
                    name="smtpPort"
                    value={profile.smtpPort || ''}
                    onChange={handleChange}
                    placeholder="587, 465"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-2">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Přihlašovací jméno (e-mail)</label>
                  <input
                    type="text"
                    name="smtpUser"
                    value={profile.smtpUser || ''}
                    onChange={handleChange}
                    placeholder="Váš přihlašovací e-mail"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Heslo k SMTP</label>
                  <input
                    type="password"
                    name="smtpPass"
                    value={profile.smtpPass || ''}
                    onChange={handleChange}
                    placeholder="Heslo"
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>

                <div className="space-y-1.5 sm:col-span-3">
                  <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">Zobrazované jméno odesílatele</label>
                  <input
                    type="text"
                    name="emailSenderName"
                    value={profile.emailSenderName || ''}
                    onChange={handleChange}
                    placeholder="Jan Novák - Truhlářství, Firma s.r.o."
                    className="w-full bg-white border border-slate-200 rounded-xl px-3 py-2 text-sm text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500 shadow-2xs transition"
                  />
                </div>
              </div>
            </div>
          )}
        </div>

        {/* SECTION 4: Frequent Invoiced Items (Často fakturované položky) */}
        <div className="rounded-3xl bg-white border border-slate-200 shadow-sm overflow-hidden mb-6">
          <div 
            onClick={() => toggleSection('frequentItems')}
            className="p-5 flex items-start gap-3.5 cursor-pointer hover:bg-slate-50/60 transition select-none"
          >
            <div className="w-10 h-10 rounded-xl bg-indigo-50 flex items-center justify-center shrink-0 text-indigo-600">
              <RefreshCw className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="font-extrabold text-slate-800 font-display text-sm md:text-base">Často fakturované položky</h3>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                Opakující se položky prací a produktů pro bleskové vložení do nových dokladů.
              </p>
            </div>
            <div className="shrink-0 text-slate-400 mt-1">
              {expandedSections.frequentItems ? (
                <ChevronUp className="w-5 h-5" />
              ) : (
                <ChevronDown className="w-5 h-5" />
              )}
            </div>
          </div>

          {expandedSections.frequentItems && (
            <div className="p-5 border-t border-slate-100 bg-slate-50/20 space-y-4">
              <p className="text-xs text-slate-500 leading-relaxed">
                Zadejte práce či produkty, které fakturujete opakovaně. Při tvorbě nové faktury je pak přidáte na jedno kliknutí.
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 p-3.5 rounded-2xl border border-slate-200">
                <div className="space-y-1 sm:col-span-2">
                  <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Název položky</label>
                  <input
                    type="text"
                    value={newItemName || ''}
                    onChange={(e) => setNewItemName(e.target.value)}
                    placeholder="Např. Truhlářské práce"
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Jednotka</label>
                  <input
                    type="text"
                    value={newItemUnit || ''}
                    onChange={(e) => setNewItemUnit(e.target.value)}
                    placeholder="ks, hod, m2"
                    className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500"
                  />
                </div>

                <div className="space-y-1">
                  <label className="text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Cena/Jedn.</label>
                  <div className="flex gap-2">
                    <input
                      type="number"
                      value={newItemPrice || ''}
                      onChange={(e) => setNewItemPrice(Number(e.target.value))}
                      placeholder="Kč"
                      className="w-full bg-white border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none focus:border-indigo-500"
                    />
                    <button
                      type="button"
                      onClick={addFrequentItem}
                      className="bg-indigo-600 p-1.5 rounded-lg hover:bg-indigo-700 text-white cursor-pointer touch-manipulation flex items-center justify-center shrink-0 w-8 h-8 font-bold"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* List of saved items */}
              <div className="space-y-2 max-h-48 overflow-y-auto pr-1">
                {(profile.frequentItems || []).length === 0 ? (
                  <p className="text-xs text-slate-400 text-center py-4 italic bg-slate-50/50 rounded-xl border border-dashed border-slate-200">
                    Zatím žádné často fakturované položky.
                  </p>
                ) : (
                  (profile.frequentItems || []).map((item) => (
                    <div key={item.id} className="flex justify-between items-center p-3 rounded-xl bg-white border border-slate-200 text-xs hover:bg-slate-50/50 transition">
                      <div className="flex-1 min-w-0 pr-2">
                        <p className="font-bold text-slate-800 truncate">{item.name}</p>
                        <p className="text-[10px] text-slate-500 font-medium">{item.price.toLocaleString('cs-CZ')} Kč / {item.unit}</p>
                      </div>
                      <button
                        type="button"
                        onClick={() => removeFrequentItem(item.id)}
                        className="p-1.5 text-slate-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition cursor-pointer"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}
        </div>

        {/* STATUS DISPLAYS */}
        {statusMessage && (
          <div className={`p-4 rounded-2xl text-xs font-semibold ${
            statusMessage.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-250' : 'bg-red-50 text-red-700 border border-red-250'
          }`}>
            {statusMessage.text}
          </div>
        )}

        {/* PROFILE ACTIONS */}
        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={saving}
            className="flex-1 inline-flex items-center justify-center gap-2 px-5 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold shadow-xs transition cursor-pointer disabled:brightness-75 touch-manipulation uppercase tracking-wider"
          >
            {saving ? (
              <Loader2 className="w-4 h-4 animate-spin text-white" />
            ) : (
              <Save className="w-4 h-4 text-white" />
            )}
            <span>Uložit profil dodavatele</span>
          </button>

          <button
            type="button"
            onClick={logOut}
            className="inline-flex items-center justify-center gap-2 px-4 py-3 bg-red-50 hover:bg-red-100 text-red-600 border border-red-150 rounded-xl text-xs font-bold transition cursor-pointer touch-manipulation uppercase tracking-wider"
          >
            <LogOut className="w-4 h-4" />
            <span className="hidden sm:inline">Odhlásit</span>
          </button>
        </div>

      </form>
    </div>
  );
}
