import React, { useState, useEffect } from 'react';
import { db, auth, handleFirestoreError, OperationType, sanitizeFirestoreData } from '../lib/firebase';
import { collection, query, where, onSnapshot, doc, setDoc, deleteDoc, orderBy } from 'firebase/firestore';
import { ICashFlowRecord, IInvoice } from '../types';
import { 
  Plus, Trash2, ArrowUpRight, ArrowDownLeft, Wallet, Calendar, Tag, FileText, Loader2, Sparkles, AlertCircle, TrendingUp
} from 'lucide-react';

export default function CashFlowView() {
  const [records, setRecords] = useState<ICashFlowRecord[]>([]);
  const [invoices, setInvoices] = useState<IInvoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // New Record Form State
  const [type, setType] = useState<'income' | 'expense'>('expense');
  const [amount, setAmount] = useState<string>('');
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [category, setCategory] = useState<string>('Služby');
  const [description, setDescription] = useState<string>('');
  const [statusMessage, setStatusMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  // Categories helper
  const expenseCategories = ['Služby', 'Materiál', 'Nábytek/Vybavení', 'Nájem a energie', 'Cestovné/Doprava', 'Webhosting/Software', 'Daně/Pojištění', 'Ostatní výdaje'];
  const incomeCategories = ['Prodej služeb', 'Prodej zboží', 'Konzultace', 'Ostatní příjmy'];

  // Sync state based on type
  useEffect(() => {
    if (type === 'income') {
      setCategory('Prodej služeb');
    } else {
      setCategory('Služby');
    }
  }, [type]);

  // Load cashflow records and invoices reactively
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    // Listen to manual cashflow collection
    const qCf = query(
      collection(db, 'cashflow'),
      where('ownerId', '==', user.uid),
      orderBy('date', 'desc')
    );

    const unsubscribeCf = onSnapshot(qCf, (snapshot) => {
      const recordsList: ICashFlowRecord[] = [];
      snapshot.forEach((doc) => {
        recordsList.push(doc.data() as ICashFlowRecord);
      });
      setRecords(recordsList);
      setLoading(false);
    }, (error) => {
      console.error("Failed to load cashflow:", error);
      setLoading(false);
    });

    // Listen to invoices to automatically display paid ones
    const qInv = query(
      collection(db, 'invoices'),
      where('ownerId', '==', user.uid),
      orderBy('createdAt', 'desc')
    );

    const unsubscribeInv = onSnapshot(qInv, (snapshot) => {
      const docsList: IInvoice[] = [];
      snapshot.forEach((doc) => {
        docsList.push(doc.data() as IInvoice);
      });
      setInvoices(docsList);
    }, (error) => {
      console.warn("Snapshot subscription failed for invoices inside cashflow view.", error);
    });

    return () => {
      unsubscribeCf();
      unsubscribeInv();
    };
  }, []);

  // Compute merged list of cash flow entries (manual + paid invoices)
  const getMergedRecords = () => {
    const merged: {
      id: string;
      type: 'income' | 'expense';
      amount: number;
      date: string;
      category: string;
      description: string;
      isInvoice?: boolean;
      invoiceNumber?: string;
    }[] = [];

    // Add manual ones
    records.forEach(r => {
      merged.push({
        id: r.id,
        type: r.type,
        amount: r.amount,
        date: r.date,
        category: r.category,
        description: r.description,
        isInvoice: false
      });
    });

    // Add paid invoices as automatic Income
    invoices.forEach(inv => {
      if (inv.type !== 'quote' && inv.status === 'paid') {
        merged.push({
          id: `inv-${inv.id}`,
          type: 'income',
          amount: inv.totalAmount,
          date: inv.issuedDate, // use issue date or paid date representation
          category: 'Fakturace',
          description: `Úhrada dokladu č. ${inv.documentNumber} (${inv.customer.companyName})`,
          isInvoice: true,
          invoiceNumber: inv.documentNumber
        });
      }
    });

    // Sort by date desc
    return merged.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  };

  const mergedList = getMergedRecords();

  // Aggregate totals
  const totalIncomes = mergedList
    .filter(r => r.type === 'income')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const totalExpenses = mergedList
    .filter(r => r.type === 'expense')
    .reduce((acc, curr) => acc + curr.amount, 0);

  const netProfit = totalIncomes - totalExpenses;

  // Form handle submit
  const handleAddRecord = async (e: React.FormEvent) => {
    e.preventDefault();
    const parsedAmount = parseFloat(amount);
    if (isNaN(parsedAmount) || parsedAmount <= 0) {
      setStatusMessage({ type: 'error', text: 'Zadejte prosím platnou kladnou částku.' });
      return;
    }

    setSaving(true);
    setStatusMessage(null);

    try {
      const user = auth.currentUser;
      if (!user) throw new Error("Chyba ověření uživatele.");

      const recordId = crypto.randomUUID();
      const newRecord: ICashFlowRecord = {
        id: recordId,
        ownerId: user.uid,
        type,
        amount: parsedAmount,
        date,
        category,
        description: description.trim() || `${type === 'income' ? 'Příjem' : 'Výdej'} - ${category}`,
        createdAt: new Date().toISOString()
      };

      const docRef = doc(db, 'cashflow', recordId);
      await setDoc(docRef, sanitizeFirestoreData(newRecord));

      // Reset form fields
      setAmount('');
      setDescription('');
      setStatusMessage({ type: 'success', text: 'Záznam byl úspěšně zaevidován.' });
      setTimeout(() => setStatusMessage(null), 3500);
    } catch (err) {
      console.error(err);
      setStatusMessage({ type: 'error', text: 'Chyba při ukládání záznamu.' });
    } finally {
      setSaving(false);
    }
  };

  // Delete manual record
  const handleDeleteRecord = async (id: string, desc: string) => {
    if (!confirm(`Opravdu si přejete smazat záznam "${desc}"?`)) return;

    try {
      await deleteDoc(doc(db, 'cashflow', id));
    } catch (err) {
      console.error(err);
      alert('Smazání se nezdařilo.');
    }
  };

  if (loading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-3" />
        <p className="text-slate-600 text-sm">Načítám evidenci příjmů a výdajů...</p>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-20 px-1">
      
      {/* HEADER BANNER */}
      <div className="bg-white p-5 rounded-3xl border border-slate-200 shadow-3xs flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <div>
          <h2 className="text-xl font-black font-display text-slate-950 flex items-center gap-2">
            <Wallet className="w-5 h-5 text-indigo-600" />
            <span>Jednoduchá evidence příjmů a výdajů</span>
          </h2>
          <p className="text-xs text-slate-500 mt-1">
            Zapisujte provozní výdaje a nechte systém automaticky sloučit příjmy z uhrazených dokladů.
          </p>
        </div>
        <span className="text-[10px] font-mono bg-slate-100 border border-slate-200 text-slate-600 px-2.5 py-1 rounded-xl font-semibold">
          Kniha příjmů a výdajů
        </span>
      </div>

      {/* KPI METRICS ROW */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        {/* Total Incomes */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-3xs relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider">Celkové příjmy</span>
              <div className="w-7 h-7 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center border border-emerald-100">
                <ArrowUpRight className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-extrabold font-mono text-emerald-600 mt-2">
              {Math.round(totalIncomes).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-400">Kč</span>
            </p>
          </div>
          <p className="text-[10px] text-slate-400 mt-2.5 pt-2 border-t border-slate-50">
            Zahrnuje manual příjmy a uhrazené faktury.
          </p>
        </div>

        {/* Total Expenses */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-3xs relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-slate-400">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider">Provozní výdaje</span>
              <div className="w-7 h-7 rounded-lg bg-rose-50 text-rose-600 flex items-center justify-center border border-rose-105">
                <ArrowDownLeft className="w-4 h-4" />
              </div>
            </div>
            <p className="text-2xl font-extrabold font-mono text-rose-600 mt-2">
              {Math.round(totalExpenses).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-slate-400">Kč</span>
            </p>
          </div>
          <p className="text-[10px] text-slate-400 mt-2.5 pt-2 border-t border-slate-50">
            Manuálně zaevidované výdaje a nákupy.
          </p>
        </div>

        {/* Dynamic Margin/Profit */}
        <div className="bg-indigo-950 text-white rounded-3xl p-5 shadow-md relative overflow-hidden flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between text-indigo-300">
              <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-indigo-200">Provozní Výsledek / Zisk</span>
              <div className="w-7 h-7 rounded-lg bg-indigo-900 border border-indigo-800 text-indigo-300 flex items-center justify-center">
                <TrendingUp className="w-4 h-4" />
              </div>
            </div>
            <p className={`text-2xl font-black font-mono mt-2 ${netProfit >= 0 ? 'text-emerald-400' : 'text-rose-400'}`}>
              {Math.round(netProfit).toLocaleString('cs-CZ')} <span className="text-xs font-sans font-medium text-indigo-200">Kč</span>
            </p>
          </div>
          <p className="text-[10px] text-indigo-300 mt-2.5 pt-2 border-t border-indigo-900">
            Hrubý zisk po odečtení provozních nákladů.
          </p>
        </div>
      </div>

      {/* RENDER GRID FORM + VIEW ENTRIES */}
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-start">
        
        {/* NEW RECORD CREATION SHELF (col-span-4) */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-3xs md:col-span-5 space-y-4">
          <div className="flex items-center gap-1.5 border-b border-slate-100 pb-3">
            <Sparkles className="w-4 h-4 text-indigo-600 animate-pulse" />
            <h3 className="font-extrabold text-slate-900 font-display text-sm">Záznam transakce</h3>
          </div>

          <form onSubmit={handleAddRecord} className="space-y-3">
            
            {/* TYPE CHANGE SWITCHER */}
            <div className="grid grid-cols-2 gap-1.5 bg-slate-100 p-1 rounded-xl mb-1 select-none">
              <button
                type="button"
                onClick={() => setType('expense')}
                className={`py-1.5 rounded-lg text-xs font-bold text-center cursor-pointer transition ${
                  type === 'expense' 
                    ? 'bg-rose-500 text-white shadow-3xs' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Výdaj / Nákup
              </button>
              <button
                type="button"
                onClick={() => setType('income')}
                className={`py-1.5 rounded-lg text-xs font-bold text-center cursor-pointer transition ${
                  type === 'income' 
                    ? 'bg-emerald-500 text-white shadow-3xs' 
                    : 'text-slate-500 hover:text-slate-700'
                }`}
              >
                Mimořádný příjem
              </button>
            </div>

            {/* AMOUNT INPUT */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Částka v Kč</label>
              <input
                type="number"
                step="any"
                required
                value={amount}
                onChange={(e) => setAmount(e.target.value)}
                placeholder="0.00"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {/* DATE INPUT */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Datum transakce</label>
              <input
                type="date"
                required
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 focus:outline-none"
              />
            </div>

            {/* CATEGORY SELECT */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Kategorie</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-700 focus:outline-none"
              >
                {type === 'expense' 
                  ? expenseCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)
                  : incomeCategories.map(cat => <option key={cat} value={cat}>{cat}</option>)
                }
              </select>
            </div>

            {/* DESCRIPTION INPUT */}
            <div className="space-y-1">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-wider block">Popis / Specifikace</label>
              <input
                type="text"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Např. Kancelářská křesla IKEA"
                className="w-full bg-slate-50 border border-slate-200 rounded-lg px-2.5 py-1.5 text-xs text-slate-800 placeholder-slate-400 focus:outline-none focus:border-indigo-500"
              />
            </div>

            {statusMessage && (
              <div className={`p-2.5 rounded-xl text-[11px] font-semibold ${
                statusMessage.type === 'success' ? 'bg-emerald-50 text-emerald-700 border border-emerald-100' : 'bg-red-50 text-red-700 border border-red-100'
              }`}>
                {statusMessage.text}
              </div>
            )}

            {/* SUBMIT BUTTON */}
            <div className="pt-2">
              <button
                type="submit"
                disabled={saving}
                className="w-full py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-bold transition cursor-pointer flex items-center justify-center gap-1 shadow-sm"
              >
                {saving && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                <Plus className="w-4 h-4" />
                <span>Zaevidovat záznam</span>
              </button>
            </div>

          </form>
        </div>

        {/* LOG ENTRIES VIEW LIST (col-span-8) */}
        <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-3xs md:col-span-7 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-100 pb-3">
            <h3 className="font-extrabold text-slate-900 font-display text-sm">Přehled transakcí ({mergedList.length})</h3>
            <span className="text-[10px] text-slate-400 font-medium">Seřazeno od nejnovějších</span>
          </div>

          <div className="space-y-2.5 max-h-[460px] overflow-y-auto pr-1">
            {mergedList.length === 0 ? (
              <div className="p-8 text-center bg-slate-50/50 rounded-2xl border border-dashed border-slate-200">
                <p className="text-xs text-slate-400 italic">Zatím nebyly zaevidovány žádné příjmy ani výdaje.</p>
              </div>
            ) : (
              mergedList.map((rec) => {
                const isInc = rec.type === 'income';
                return (
                  <div key={rec.id} className="p-3 bg-slate-50/40 rounded-xl border border-slate-200/60 flex items-center justify-between text-xs transition hover:bg-slate-50/85">
                    <div className="flex items-start gap-2.5 pr-2 min-w-0">
                      {/* Icon */}
                      <div className={`w-8 h-8 rounded-lg shrink-0 flex items-center justify-center border ${
                        isInc 
                          ? 'bg-emerald-50 text-emerald-600 border-emerald-100' 
                          : 'bg-rose-50 text-rose-600 border-rose-100'
                      }`}>
                        {isInc ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownLeft className="w-4 h-4" />}
                      </div>

                      {/* Content details */}
                      <div className="min-w-0">
                        <p className="font-extrabold text-slate-800 truncate" title={rec.description}>
                          {rec.description}
                        </p>
                        <div className="flex flex-wrap items-center gap-x-2 gap-y-0.5 text-[10px] text-slate-400 mt-0.5">
                          <span className="font-semibold text-slate-500 font-mono">
                            {new Date(rec.date).toLocaleDateString('cs-CZ')}
                          </span>
                          <span>•</span>
                          <span className="bg-slate-100 text-slate-500 px-1.5 py-0.2 rounded font-medium">
                            {rec.category}
                          </span>
                          {rec.isInvoice && (
                            <>
                              <span>•</span>
                              <span className="text-blue-500 font-bold bg-blue-50 border border-blue-100 px-1 py-0.2 rounded flex items-center gap-0.5 text-[9px]">
                                <FileText className="w-2.5 h-2.5" />
                                {rec.invoiceNumber}
                              </span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Amount & Actions */}
                    <div className="flex items-center gap-2.5 shrink-0 pl-1">
                      <span className={`font-mono font-bold text-right ${isInc ? 'text-emerald-600' : 'text-rose-600'}`}>
                        {isInc ? '+' : '-'}{rec.amount.toLocaleString('cs-CZ')} Kč
                      </span>

                      {/* Manual entries can be deleted, invoice incomes are locked! */}
                      {!rec.isInvoice ? (
                        <button
                          type="button"
                          onClick={() => handleDeleteRecord(rec.id, rec.description)}
                          className="p-1 text-slate-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition cursor-pointer"
                          title="Smazat záznam"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      ) : (
                        <div className="w-6" /> // spacer to keep row dimensions stable
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>

      </div>

    </div>
  );
}
