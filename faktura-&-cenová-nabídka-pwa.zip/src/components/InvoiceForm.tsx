import React, { useState, useEffect } from 'react';
import { db, auth, handleFirestoreError, OperationType, sanitizeFirestoreData } from '../lib/firebase';
import { collection, doc, setDoc, getDocs, query, orderBy, limit, where } from 'firebase/firestore';
import { IInvoice, IInvoiceItem, IDocumentType, IDocumentStatus, IUserProfile, ISupplier, ICustomer, ICustomerContact } from '../types';
import { 
  FileText, Calendar, Plus, Trash2, Save, User, ArrowLeft, Loader2, Search, Sparkles, Users
} from 'lucide-react';

interface InvoiceFormProps {
  supplierProfile: IUserProfile;
  editingInvoice: IInvoice | null;
  onSaved: () => void;
  onCancel: () => void;
}

export default function InvoiceForm({ supplierProfile, editingInvoice, onSaved, onCancel }: InvoiceFormProps) {
  const [loadingCode, setLoadingCode] = useState(false);
  const [aresLoading, setAresLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Odběratelé (contacts) list and selection state
  const [contacts, setContacts] = useState<ICustomerContact[]>([]);
  const [saveToContacts, setSaveToContacts] = useState(false);
  const [selectedContactId, setSelectedContactId] = useState('');

  // Form Fields State
  const [docType, setDocType] = useState<IDocumentType>('invoice');
  const [docNumber, setDocNumber] = useState('');
  const [issuedDate, setIssuedDate] = useState('');
  const [dueDate, setDueDate] = useState('');
  const [validUntil, setValidUntil] = useState('');
  const [vs, setVs] = useState('');
  const [note, setNote] = useState('Děkujeme za Vaši přízeň.');
  
  // Sibling states
  const [customer, setCustomer] = useState<ICustomer>({
    companyName: '',
    email: '',
    street: '',
    city: '',
    zip: '',
    ico: '',
    dic: '',
    phone: ''
  });

  const [selectedSupplier, setSelectedSupplier] = useState<ISupplier>({
    companyName: supplierProfile.companyName || '',
    street: supplierProfile.street || '',
    city: supplierProfile.city || '',
    zip: supplierProfile.zip || '',
    ico: supplierProfile.ico || '',
    dic: supplierProfile.dic || '',
    bankAccount: supplierProfile.bankAccount || '',
    bankCode: supplierProfile.bankCode || '0100',
    logoUrl: supplierProfile.logoUrl || '',
    phone: supplierProfile.phone || ''
  });

  const [items, setItems] = useState<IInvoiceItem[]>([
    { id: '1', name: '', unit: 'ks', count: 1, pricePerUnit: 0, vatRate: supplierProfile.dphRate }
  ]);

  // Load draft on mount or original invoice if editing
  useEffect(() => {
    if (!editingInvoice) {
      try {
        const draftStr = localStorage.getItem('faktnu_invoice_form_draft');
        if (draftStr) {
          const draft = JSON.parse(draftStr);
          if (draft.docType) setDocType(draft.docType);
          if (draft.docNumber) setDocNumber(draft.docNumber);
          if (draft.issuedDate) setIssuedDate(draft.issuedDate);
          if (draft.dueDate) setDueDate(draft.dueDate);
          if (draft.validUntil) setValidUntil(draft.validUntil);
          if (draft.vs) setVs(draft.vs);
          if (draft.note !== undefined) setNote(draft.note);
          if (draft.customer) setCustomer(draft.customer);
          if (draft.selectedSupplier) setSelectedSupplier(draft.selectedSupplier);
          if (draft.items) setItems(draft.items);
          console.log("Draft loaded successfully from local storage!");
        } else {
          // No draft exists, generate standard default dates and order numbers
          const today = new Date().toISOString().split('T')[0];
          const due = new Date();
          due.setDate(due.getDate() + 14);
          const dueStr = due.toISOString().split('T')[0];
          
          setIssuedDate(today);
          setDueDate(dueStr);
          generateNextDocumentNumber(today);
        }
      } catch (err) {
        console.warn("Could not load local draft:", err);
      }
    } else {
      // Editing mode - load original invoice details directly
      setDocType(editingInvoice.type);
      setDocNumber(editingInvoice.documentNumber);
      setIssuedDate(editingInvoice.issuedDate);
      setDueDate(editingInvoice.dueDate);
      setValidUntil(editingInvoice.validUntil || '');
      setVs(editingInvoice.variableSymbol);
      setNote(editingInvoice.note || '');
      setCustomer(editingInvoice.customer);
      setItems(editingInvoice.items);
      if (editingInvoice.supplier) {
        setSelectedSupplier(editingInvoice.supplier);
      }
    }
  }, [editingInvoice]);

  // Fetch customer contacts on mount for dropdown list
  useEffect(() => {
    const user = auth.currentUser;
    if (!user) return;

    const q = query(
      collection(db, 'customers'),
      where('ownerId', '==', user.uid),
      orderBy('companyName', 'asc')
    );

    getDocs(q).then((snapshot) => {
      const list: ICustomerContact[] = [];
      snapshot.forEach((doc) => {
        list.push({ id: doc.id, ...doc.data() } as ICustomerContact);
      });
      setContacts(list);
    }).catch((err) => {
      console.warn("Chyba při načítání adresáře pro rychlý výběr:", err);
    });
  }, []);

  const handleSelectContactChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setSelectedContactId(val);
    if (!val) return;
    
    const contact = contacts.find(c => c.id === val);
    if (contact) {
      setCustomer({
        companyName: contact.companyName,
        email: contact.email,
        street: contact.street,
        city: contact.city,
        zip: contact.zip,
        ico: contact.ico,
        dic: contact.dic || '',
        phone: contact.phone || ''
      });
    }
  };

  // Automatically save draft on edits (only in creation mode)
  useEffect(() => {
    if (!editingInvoice && docNumber) {
      const draft = {
        docType,
        docNumber,
        issuedDate,
        dueDate,
        validUntil,
        vs,
        note,
        customer,
        selectedSupplier,
        items
      };
      localStorage.setItem('faktnu_invoice_form_draft', JSON.stringify(draft));
    }
  }, [docType, docNumber, issuedDate, dueDate, validUntil, vs, note, customer, selectedSupplier, items, editingInvoice]);

  const generateNextDocumentNumber = async (todayStr: string) => {
    setLoadingCode(true);
    try {
      const year = todayStr.split('-')[0]; // e.g. 2026
      
      // Default configurations for fallback/initial profiles
      let settings = {
        prefix: docType === 'invoice' ? 'F' : docType === 'advance' ? 'Z' : 'N',
        includeYear: true,
        digitCount: 4,
        startNumber: 1,
        resetYearly: true
      };

      // Load matching settings from supplierProfile if saved
      if (docType === 'invoice' && supplierProfile?.invoiceNumbering) {
        settings = { ...settings, ...supplierProfile.invoiceNumbering };
      } else if (docType === 'advance' && supplierProfile?.advanceNumbering) {
        settings = { ...settings, ...supplierProfile.advanceNumbering };
      } else if (docType === 'quote' && supplierProfile?.quoteNumbering) {
        settings = { ...settings, ...supplierProfile.quoteNumbering };
      }

      const user = auth.currentUser;
      if (!user) return;

      const invoicesRef = collection(db, 'invoices');
      const q = query(
        invoicesRef,
        where('ownerId', '==', user.uid),
        where('type', '==', docType)
      );
      const querySnapshot = await getDocs(q);
      const typedInvoices = querySnapshot.docs.map(doc => doc.data() as IInvoice);

      let nextSeq = settings.startNumber;

      // Filter invoices for yearly reset check
      let eligibleInvoices = typedInvoices;
      if (settings.resetYearly) {
        eligibleInvoices = typedInvoices.filter(inv => {
          const invYear = (inv.issuedDate || inv.createdAt || '').split('-')[0];
          return invYear === year;
        });
      }

      if (eligibleInvoices.length > 0) {
        // Retrieve the highest index tail of digitCount length
        const numbers = eligibleInvoices.map(inv => {
          const numStr = inv.documentNumber;
          const tail = numStr.slice(-settings.digitCount);
          const parsed = parseInt(tail, 10);
          return isNaN(parsed) ? 0 : parsed;
        });
        const maxNum = Math.max(...numbers, 0);
        if (maxNum >= settings.startNumber) {
          nextSeq = maxNum + 1;
        }
      }

      const prefixPart = (settings.prefix || '').trim();
      const yearPart = settings.includeYear ? year : '';
      const seqStr = String(nextSeq).padStart(settings.digitCount, '0');
      
      const finalNum = prefixPart + yearPart + seqStr;
      setDocNumber(finalNum);
      
      // Variable symbol Czech standard (usually matches digits of the code)
      const digitsOnly = finalNum.replace(/\D/g, ''); 
      setVs(digitsOnly);

    } catch (e) {
      console.error("Error generating invoice number:", e);
      // Clean fallback if error occurs
      const rand = Math.floor(1000 + Math.random() * 9000);
      setDocNumber((docType === 'invoice' ? 'F' : docType === 'advance' ? 'Z' : 'N') + rand);
    } finally {
      setLoadingCode(false);
    }
  };

  // Synchronize dynamic dates to keep invoice variable synchronised
  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const isDate = e.target.value;
    setIssuedDate(isDate);
    
    // Auto shift due date by +14 days
    const d = new Date(isDate);
    if (!isNaN(d.getTime())) {
      d.setDate(d.getDate() + 14);
      setDueDate(d.toISOString().split('T')[0]);
    }
  };

  // Load customer data from ARES API proxy
  const loadCustomerFromAres = async () => {
    const cleanIco = customer.ico.replace(/\s/g, '').replace(/^[A-Z]{2}/i, '');
    if (!cleanIco || !/^\d{8}$/.test(cleanIco)) {
      alert('Zadejte prosím platné 8-místné IČO odběratele (např. 27074358). Spoustu chyb vyřešíte očištěním od mezer nebo písmen.');
      return;
    }

    setAresLoading(true);
    try {
      const res = await fetch(`/api/ares/${cleanIco}`);
      if (!res.ok) {
        const errData = await res.json();
        throw new Error(errData.error || 'IČO nebylo v registru ARES nalezeno.');
      }
      const data = await res.json();
      setCustomer(prev => ({
        ...prev,
        companyName: data.companyName,
        street: data.street,
        city: data.city,
        zip: data.zip,
        dic: data.dic || ''
      }));
    } catch (e: any) {
      alert(e.message || 'Chyba při stahování dat z registru ARES.');
    } finally {
      setAresLoading(false);
    }
  };

  // Items table state manipulations
  const handleAddItem = () => {
    setItems([
      ...items,
      {
        id: crypto.randomUUID(),
        name: '',
        unit: 'ks',
        count: 1,
        pricePerUnit: 0,
        vatRate: supplierProfile.dphRate
      }
    ]);
  };

  const handleRemoveItem = (id: string) => {
    if (items.length === 1) {
      // Keep at least one row
      setItems([{ id: '1', name: '', unit: 'ks', count: 1, pricePerUnit: 0, vatRate: supplierProfile.dphRate }]);
    } else {
      setItems(items.filter(it => it.id !== id));
    }
  };

  const handleItemValueChange = (id: string, field: keyof IInvoiceItem, value: any) => {
    setItems(items.map(it => {
      if (it.id === id) {
        return {
          ...it,
          [field]: field === 'count' || field === 'pricePerUnit' || field === 'vatRate' ? Number(value) : value
        };
      }
      return it;
    }));
  };

  // Fast-insert of frequently invoiced items
  const handleInsertFrequentItem = (frequent: any) => {
    // Replace the first item if empty, or append a new item
    const firstItem = items[0];
    const isFirstEmpty = items.length === 1 && !firstItem.name && firstItem.pricePerUnit === 0;

    const newItem: IInvoiceItem = {
      id: crypto.randomUUID(),
      name: frequent.name,
      unit: frequent.unit,
      count: 1,
      pricePerUnit: frequent.price,
      vatRate: supplierProfile.dphRate
    };

    if (isFirstEmpty) {
      setItems([newItem]);
    } else {
      setItems([...items, newItem]);
    }
  };

  // Sum amounts (including subtotal depending on DPH rates of respective rows)
  const calculateTotals = () => {
    let subtotal = 0;
    let totalTax = 0;
    let totalAll = 0;

    items.forEach(it => {
      const lineTotalRaw = it.count * it.pricePerUnit;
      const taxAmount = (lineTotalRaw * (it.vatRate / 100));
      const lineTotalAll = lineTotalRaw + (supplierProfile.dphRate > 0 ? taxAmount : 0);
      
      subtotal += lineTotalRaw;
      totalTax += supplierProfile.dphRate > 0 ? taxAmount : 0;
      totalAll += lineTotalAll;
    });

    return {
      subtotal: Math.round(subtotal * 100) / 100,
      tax: Math.round(totalTax * 100) / 100,
      total: Math.round(totalAll * 100) / 100
    };
  };

  const { subtotal, tax, total } = calculateTotals();

  // Save submit
  const handleSubmitInvoice = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validations
    if (!supplierProfile.companyName) {
      alert("Před vystavením dokladu prosím vyplňte a uložte svůj profil dodavatele!");
      return;
    }
    
    if (items.some(it => !it.name.trim())) {
      alert("Vyplňte prosím názvy u všech položek dokladu.");
      return;
    }

    setSaving(true);
    try {
      const user = auth.currentUser;
      if (!user) throw new Error("Chyba ověření uživatele.");

      const isCreateMode = !editingInvoice;
      const invoiceId = isCreateMode ? crypto.randomUUID().replace(/-/g, '') : editingInvoice.id;

      // Extract a snapshot of current supplier details into the invoice document
      // This protects dynamic edits later on Profile doc from corrupting legacy documents!
      const supplierSnapshot: ISupplier = {
        companyName: selectedSupplier.companyName,
        street: selectedSupplier.street,
        city: selectedSupplier.city,
        zip: selectedSupplier.zip,
        ico: selectedSupplier.ico,
        dic: selectedSupplier.dic || '',
        bankAccount: selectedSupplier.bankAccount,
        bankCode: selectedSupplier.bankCode,
        logoUrl: selectedSupplier.logoUrl || '',
        phone: selectedSupplier.phone || ''
      };

      const finalInvoice: IInvoice = {
        id: invoiceId,
        ownerId: user.uid,
        type: docType,
        documentNumber: docNumber,
        issuedDate,
        dueDate,
        validUntil: docType === 'quote' ? (validUntil || null) : null,
        variableSymbol: vs,
        supplier: supplierSnapshot,
        customer,
        items,
        totalAmount: total,
        note,
        status: editingInvoice ? editingInvoice.status : 'draft',
        createdAt: editingInvoice?.createdAt || new Date().toISOString(),
        updatedAt: new Date().toISOString()
      };

      const docRef = doc(db, 'invoices', invoiceId);
      await setDoc(docRef, sanitizeFirestoreData(finalInvoice));

      // Save customer to contacts directory if requested
      if (saveToContacts) {
        try {
          const contactId = crypto.randomUUID().replace(/-/g, '');
          const newContact: ICustomerContact = {
            id: contactId,
            ownerId: user.uid,
            companyName: customer.companyName.trim(),
            ico: customer.ico.trim(),
            dic: (customer.dic || '').trim(),
            street: customer.street.trim(),
            city: customer.city.trim(),
            zip: customer.zip.trim(),
            country: 'Česká republika',
            email: customer.email.trim(),
            phone: (customer.phone || '').trim(),
            note: 'Uloženo automaticky z fakturačního formuláře',
            createdAt: new Date().toISOString()
          };
          const contactRef = doc(db, 'customers', contactId);
          await setDoc(contactRef, sanitizeFirestoreData(newContact));
        } catch (contactErr) {
          console.warn("Chyba při automatickém zápisu odběratele do adresáře:", contactErr);
        }
      }
      
      // Clear draft on successful submission
      localStorage.removeItem('faktnu_invoice_form_draft');
      
      onSaved();
    } catch (err) {
      console.error(err);
      alert("Nepodařilo se uložit fakturu. Zkontrolujte připojení k internetu.");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 pb-16">
      <div className="flex items-center gap-3 mb-6 no-print">
        <button
          onClick={onCancel}
          className="p-2 hover:bg-slate-800 rounded-xl transition text-slate-400 hover:text-slate-100 cursor-pointer"
        >
          <ArrowLeft className="w-5 h-5" />
        </button>
        <h2 className="text-xl font-bold font-display text-slate-100">
          {editingInvoice ? 'Upravit vystavený doklad' : 'Vystavit nový doklad'}
        </h2>
      </div>

      <form onSubmit={handleSubmitInvoice} className="space-y-6">

        {/* SECTION 1: Document Settings, Type and Number */}
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700/40 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Choose Supplier Details Selector */}
            {((supplierProfile.suppliers && supplierProfile.suppliers.length > 0) || supplierProfile.companyName) && (
              <div className="space-y-1.5 sm:col-span-2 border-b border-slate-700/40 pb-3.5 mb-1">
                <label className="text-xs font-semibold text-slate-400 block">Zvolit profil dodavatele pro tento doklad</label>
                <select
                  onChange={(e) => {
                    const val = e.target.value;
                    if (val === 'primary') {
                      setSelectedSupplier({
                        companyName: supplierProfile.companyName,
                        street: supplierProfile.street,
                        city: supplierProfile.city,
                        zip: supplierProfile.zip,
                        ico: supplierProfile.ico,
                        dic: supplierProfile.dic || '',
                        bankAccount: supplierProfile.bankAccount,
                        bankCode: supplierProfile.bankCode,
                        logoUrl: supplierProfile.logoUrl || '',
                        phone: supplierProfile.phone || ''
                      });
                    } else {
                      const found = (supplierProfile.suppliers || []).find(s => s.id === val);
                      if (found) {
                        setSelectedSupplier(found);
                      }
                    }
                  }}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition cursor-pointer"
                >
                  <option value="primary">Výchozí profil: {supplierProfile.companyName || 'Bez názvu'} (IČO: {supplierProfile.ico || '---'})</option>
                  {(supplierProfile.suppliers || []).map(s => (
                    <option key={s.id} value={s.id}>
                      Alternativní: {s.companyName} (IČO: {s.ico})
                    </option>
                  ))}
                </select>
                <p className="text-[10px] text-slate-400 mt-1.5 leading-relaxed">
                  Použijí se firemní údaje dodavatele: <strong className="text-blue-400">{selectedSupplier.companyName || '---'}</strong> (IČO: {selectedSupplier.ico || '---'}, BÚ: {selectedSupplier.bankAccount}/{selectedSupplier.bankCode}){selectedSupplier.phone ? ` s tel: ${selectedSupplier.phone}` : ''}.
                </p>
              </div>
            )}
            
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Typ dokladu</label>
              <select
                value={docType}
                onChange={(e) => setDocType(e.target.value as IDocumentType)}
                disabled={!!editingInvoice}
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition"
              >
                <option value="invoice">Běžná faktura (Faktura)</option>
                <option value="advance">Zálohová faktura</option>
                <option value="quote">Cenová nabídka</option>
              </select>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Číslo dokladu</label>
              <div className="relative">
                <input
                  type="text"
                  value={docNumber}
                  onChange={(e) => setDocNumber(e.target.value)}
                  required
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-3 pr-10 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition font-mono"
                />
                {loadingCode && (
                  <Loader2 className="w-4 h-4 text-blue-500 animate-spin absolute right-3 top-2.5" />
                )}
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Datum vystavení (Issued Date)</label>
              <div className="relative">
                <input
                  type="date"
                  value={issuedDate}
                  onChange={handleDateChange}
                  required
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none! focus:border-blue-500 transition"
                />
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Datum splatnosti (Due Date)</label>
              <input
                type="date"
                value={dueDate}
                onChange={(e) => setDueDate(e.target.value)}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition mb-1"
              />
              <div className="flex gap-1">
                {[
                  { offset: 7, label: '+7 dní' },
                  { offset: 14, label: '+14 dní' },
                  { offset: 21, label: '+21 dní' },
                  { offset: 30, label: '+30 dní' }
                ].map(pres => (
                  <button
                    key={pres.offset}
                    type="button"
                    onClick={() => {
                      const baseDate = issuedDate ? new Date(issuedDate) : new Date();
                      baseDate.setDate(baseDate.getDate() + pres.offset);
                      setDueDate(baseDate.toISOString().split('T')[0]);
                    }}
                    className="text-[10px] px-1.5 py-0.5 bg-slate-800 hover:bg-slate-700 rounded text-slate-300 font-semibold transition cursor-pointer border border-slate-700/50"
                  >
                    {pres.label}
                  </button>
                ))}
              </div>
            </div>

            {docType === 'quote' && (
              <div className="space-y-1.5 sm:col-span-2">
                <label className="text-xs font-medium text-amber-400 block font-semibold">Platnost cenové nabídky do (Valid Until)</label>
                <input
                  type="date"
                  value={validUntil}
                  onChange={(e) => setValidUntil(e.target.value)}
                  required
                  className="w-full bg-slate-900 border border-amber-600/65 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-amber-500 transition"
                />
                <p className="text-[10px] text-slate-500">Zvolte datum, do kdy je tato vizuální cenová nabídka platná.</p>
              </div>
            )}

            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-medium text-slate-400">Variabilní symbol (Přednastavený)</label>
              <input
                type="text"
                value={vs}
                onChange={(e) => setVs(e.target.value)}
                pattern="\d*"
                placeholder="Platba VS"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition font-mono"
              />
            </div>

          </div>
        </div>

        {/* SECTION 2: Customer details */}
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700/40 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2.5 border-b border-slate-700/60 pb-3">
            <div className="flex items-center gap-2">
              <User className="w-5 h-5 text-blue-400" />
              <h3 className="font-bold text-slate-100 font-display text-base">Klient / Odběratel</h3>
            </div>
            {contacts.length > 0 && (
              <div className="flex items-center gap-1.5 shrink-0 max-w-full">
                <Users className="w-3.5 h-3.5 text-blue-400 shrink-0" />
                <select
                  value={selectedContactId}
                  onChange={handleSelectContactChange}
                  className="bg-slate-900 border border-slate-700 rounded-xl px-2 py-1 text-xs text-slate-200 focus:outline-none focus:border-blue-500 transition cursor-pointer max-w-[200px]"
                >
                  <option value="">-- Rychlý výběr odběratele --</option>
                  {contacts.map((c) => (
                    <option key={c.id} value={c.id}>{c.companyName}</option>
                  ))}
                </select>
              </div>
            )}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* Customer IČO index search */}
            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-medium text-slate-400">IČO Odběratele (Načte adresu automaticky)</label>
              <div className="flex gap-2">
                <input
                  type="text"
                  value={customer.ico}
                  onChange={(e) => setCustomer({ ...customer, ico: e.target.value })}
                  placeholder="Zadejte IČO pro načtení z ARES"
                  className="flex-1 bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition"
                />
                <button
                  type="button"
                  onClick={loadCustomerFromAres}
                  disabled={aresLoading}
                  className="inline-flex items-center gap-1.5 px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded-xl text-xs font-medium transition cursor-pointer disabled:opacity-50"
                >
                  {aresLoading ? (
                    <Loader2 className="w-4 h-4 animate-spin text-blue-400" />
                  ) : (
                    <Search className="w-4 h-4 text-blue-400" />
                  )}
                  <span>ARES</span>
                </button>
              </div>
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-medium text-slate-400">Firma / Jméno odběratele</label>
              <input
                type="text"
                value={customer.companyName}
                onChange={(e) => setCustomer({ ...customer, companyName: e.target.value })}
                required
                placeholder="Název firmy nebo Jméno klienta"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition"
              />
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-medium text-slate-400">E-mail pro zaslání PDF</label>
              <input
                type="email"
                value={customer.email}
                onChange={(e) => setCustomer({ ...customer, email: e.target.value })}
                placeholder="klient@e-mail.cz"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition"
              />
            </div>

            <div className="space-y-1.5 sm:col-span-2">
              <label className="text-xs font-medium text-slate-400">Telefon odběratele (nepovinné)</label>
              <input
                type="text"
                value={customer.phone || ''}
                onChange={(e) => setCustomer({ ...customer, phone: e.target.value })}
                placeholder="+420 123 456 789"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">DIČ (nepovinné)</label>
              <input
                type="text"
                value={customer.dic || ''}
                onChange={(e) => setCustomer({ ...customer, dic: e.target.value })}
                placeholder="CZ12345678"
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none focus:border-blue-500 transition"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">PSČ</label>
              <input
                type="text"
                value={customer.zip}
                onChange={(e) => setCustomer({ ...customer, zip: e.target.value })}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Ulice a č.p.</label>
              <input
                type="text"
                value={customer.street}
                onChange={(e) => setCustomer({ ...customer, street: e.target.value })}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-400">Město</label>
              <input
                type="text"
                value={customer.city}
                onChange={(e) => setCustomer({ ...customer, city: e.target.value })}
                required
                className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none"
              />
            </div>

            {!editingInvoice && (
              <div className="sm:col-span-2 pt-3 border-t border-slate-700/30 flex items-center gap-2.5 font-sans select-none">
                <input
                  type="checkbox"
                  id="save-to-contacts-checkbox"
                  checked={saveToContacts}
                  onChange={(e) => setSaveToContacts(e.target.checked)}
                  className="w-4 h-4 text-indigo-600 bg-slate-900 border-slate-700 rounded focus:ring-blue-500 cursor-pointer accent-blue-500"
                />
                <label htmlFor="save-to-contacts-checkbox" className="text-xs text-slate-300 font-medium cursor-pointer">
                  Uložit tohoto odběratele do mého adresáře pro příští rychlé vyplnění
                </label>
              </div>
            )}

          </div>
        </div>

        {/* SECTION 3: Frequently invoiced items Quick Picker */}
        {supplierProfile.frequentItems && supplierProfile.frequentItems.length > 0 && (
          <div className="p-4 rounded-xl bg-slate-800/35 border border-slate-700/30">
            <div className="flex items-center gap-1.5 mb-2.5">
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span className="text-xs font-semibold text-slate-300">Rychlé vložení často fakturované položky:</span>
            </div>
            <div className="flex flex-wrap gap-2">
              {supplierProfile.frequentItems.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => handleInsertFrequentItem(item)}
                  className="px-2.5 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-lg text-xs font-medium transition max-w-xs truncate cursor-pointer touch-manipulation border border-slate-700/80"
                >
                  + {item.name} ({item.price} Kč)
                </button>
              ))}
            </div>
          </div>
        )}

        {/* SECTION 4: Invoiced Items Table */}
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700/40 space-y-4">
          <div className="flex justify-between items-center border-b border-slate-700/60 pb-3">
            <h3 className="font-bold text-slate-100 font-display text-base">Položky dokladu</h3>
            <button
              type="button"
              onClick={handleAddItem}
              className="inline-flex items-center gap-1 text-xs font-bold text-blue-400 hover:text-blue-300 transition cursor-pointer touch-manipulation"
            >
              <Plus className="w-4 h-4" />
              <span>Přidat položku</span>
            </button>
          </div>

          <div className="space-y-4">
            {items.map((item, index) => (
              <div key={item.id} className="relative p-4 rounded-xl bg-slate-900/60 border border-slate-700/80 space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-[10px] font-bold text-slate-500 uppercase font-mono">Položka {index + 1}</span>
                  <button
                    type="button"
                    onClick={() => handleRemoveItem(item.id)}
                    className="p-1 text-slate-500 hover:text-red-400 transition cursor-pointer"
                    title="Odebrat položku"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>

                <div className="space-y-1.5">
                  <label className="text-[10px] text-slate-400">Název popisu služby či zboží</label>
                  <input
                    type="text"
                    value={item.name}
                    onChange={(e) => handleItemValueChange(item.id, 'name', e.target.value)}
                    required
                    placeholder="Např. Truhlářská montáž, Router ASUS AX3000..."
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400">Jednotka</label>
                    <input
                      type="text"
                      value={item.unit}
                      onChange={(e) => handleItemValueChange(item.id, 'unit', e.target.value)}
                      placeholder="ks, hod, m"
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400">Množství</label>
                    <input
                      type="number"
                      step="any"
                      value={item.count || ''}
                      onChange={(e) => handleItemValueChange(item.id, 'count', e.target.value)}
                      required
                      min={0.01}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>

                  <div className="space-y-1.5">
                    <label className="text-[10px] text-slate-400">Cena za jedn. bez DPH (CZK)</label>
                    <input
                      type="number"
                      step="any"
                      value={item.pricePerUnit || ''}
                      onChange={(e) => handleItemValueChange(item.id, 'pricePerUnit', e.target.value)}
                      required
                      min={0}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-2.5 py-1.5 text-xs text-slate-200 focus:outline-none"
                    />
                  </div>
                </div>

                {supplierProfile.dphRate > 0 && (
                  <div className="text-[11px] text-slate-400 flex justify-between items-center bg-slate-900/40 px-2 py-1 rounded">
                    <span>DPH sazba položky:</span>
                    <select
                      value={item.vatRate}
                      onChange={(e) => handleItemValueChange(item.id, 'vatRate', e.target.value)}
                      className="bg-transparent border-0 text-amber-400 font-bold focus:outline-none"
                    >
                      <option value={21}>21%</option>
                      <option value={12}>12%</option>
                      <option value={0}>0%</option>
                    </select>
                  </div>
                )}
              </div>
            ))}
          </div>

          {/* REAL TIME TOTALS */}
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-700 flex flex-col items-end space-y-1 text-right mt-4">
            <span className="text-xs text-slate-500">Cena celkem bez DPH: {subtotal.toLocaleString('cs-CZ')} Kč</span>
            {supplierProfile.dphRate > 0 && (
              <span className="text-xs text-slate-400">Celková výše DPH: {tax.toLocaleString('cs-CZ')} Kč</span>
            )}
            <span className="text-base font-bold text-emerald-400 pt-1">
              CELKEM K ÚHRADĚ: {total.toLocaleString('cs-CZ')} Kč
            </span>
          </div>
        </div>

        {/* SECTION 5: Footer Note */}
        <div className="p-5 rounded-2xl bg-slate-800/50 border border-slate-700/40 space-y-1.5">
          <label className="text-xs font-medium text-slate-400">Poznámka v patičce (Textový doprovod)</label>
          <input
            type="text"
            value={note}
            onChange={(e) => setNote(e.target.value)}
            placeholder="Např. Děkujeme za spolupráci. Nejsme plátci DPH."
            className="w-full bg-slate-900 border border-slate-700 rounded-xl px-3 py-2 text-sm text-slate-100 focus:outline-none"
          />
        </div>

        {/* SUBMIT ACTIONS */}
        <div className="flex gap-3">
          <button
            type="submit"
            disabled={saving}
            className="flex-1 inline-flex items-center justify-center gap-2 py-3.5 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-sm font-semibold shadow-lg transition cursor-pointer disabled:opacity-50 touch-manipulation"
          >
            {saving ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <Save className="w-5 h-5" />
            )}
            <span>{editingInvoice ? 'Uložit provedené změny' : 'Vystavit a uložit doklad'}</span>
          </button>
          
          <button
            type="button"
            onClick={onCancel}
            className="px-5 py-3.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl text-sm font-semibold transition cursor-pointer touch-manipulation"
          >
            Zrušit
          </button>
        </div>

      </form>
    </div>
  );
}
